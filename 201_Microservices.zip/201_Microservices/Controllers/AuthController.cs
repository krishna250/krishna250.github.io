﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using krishna_M1043200_OrderMyFood.Models;
using krishna_M1043200_OrderMyFood.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;


namespace krishna_M1043200_OrderMyFood.Controllers
{
    [Route("api/[controller]/[action]/")]
    [Route("auth")]
    public class AuthController : Controller
    {
        private readonly IUserService userService;
        private IConfiguration _config;

        /// <summary>
        /// Constructor to invokes your interfaces
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="config"></param>
        public AuthController(IUserService userService, IConfiguration config)
        {
            this.userService = userService;
            _config = config;
        }


        /// <summary>
        /// Login router
        /// </summary>
        /// <returns></returns>
        [Route("login")]
        public IActionResult LogIn()
        {
            return View(new LogInModel());
        }


        /// <summary>
        /// Validate user details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Route("login")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult LogIn(LogInModel model)
        {
            IActionResult response = Unauthorized();
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = userService.Authenticate(model.Email, model.Password);
            if (user == null)
            {
                ModelState.AddModelError("InvalidCredentials", "Could not validate your credentials");
                return View(model);
            }
            else
            {
                var tokenString = GenerateJSONWebToken(user);
                response = Ok(new { token = tokenString });

                if (tokenString.Equals("Microsoft.AspNetCore.Mvc.UnauthorizedResult"))
                {
                    return response;
                }
                else
                {
                    return SignInUser(user);
                }
            }
        }


        [Route("register")]
        public IActionResult Register()
        {
            return View();
        }


        /// <summary>
        /// Register external user
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Route("register")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult Register(RegisterModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = userService.Add(model.Name, model.Email, model.Password);

            return SignInUser(user);
        }


        [Route("accessdenied")]
        public IActionResult AccessDenied()
        {
            return View();
        }


        [Route("logout")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> LogOut()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }


        [Route("loginexternal/{id}")]
        public Task LogInExternal(string id)
        {
            return HttpContext.ChallengeAsync(id, new AuthenticationProperties { RedirectUri = "/auth/registerexternal" });
        }


        /// <summary>
        /// Register external user
        /// </summary>
        /// <param name="authprovider"></param>
        /// <returns>Result of registration</returns>
        [Route("registerexternal")]
        public IActionResult RegisterExternal(string authprovider)
        {
            var authResult = HttpContext.AuthenticateAsync("TempCookie");
            if (!authResult.IsCompletedSuccessfully)
            {
                return RedirectToAction("Index", "Home");
            }

            var user = userService.AuthenticateExternal(authResult.Result.Principal.FindFirstValue(ClaimTypes.NameIdentifier));
            if (user != null)
            {
                return SignInExternal(user);
            }

            RegisterExternalModel obj = new RegisterExternalModel
            {
                Name = authResult.Result.Principal.FindFirstValue(ClaimTypes.Name),
                Email = authResult.Result.Principal.FindFirstValue(ClaimTypes.Email)
            };

            var resUser = userService.AddExternal(authResult.Result.Principal.FindFirstValue(ClaimTypes.NameIdentifier), obj.Name, obj.Email);

            return SignInExternal(resUser);
        }

        [Route("registerexternal1")]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult RegisterExternal1(string id, [FromBody]RegisterExternalModel model)
        {
            var authResult = HttpContext.AuthenticateAsync("TempCookie");
            if (!authResult.IsCompletedSuccessfully)
            {
                return RedirectToAction("Index", "Home");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = userService.AddExternal(authResult.Result.Principal.FindFirstValue(ClaimTypes.NameIdentifier), model.Name, model.Email);

            return SignInExternal(user);
        }

        /// <summary>
        /// External user login
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        private IActionResult SignInExternal(User user)
        {
            HttpContext.SignOutAsync("TempCookie");
            return SignInUser(user);
        }

        /// <summary>
        /// Signs your user to application
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [Authorize]
        private IActionResult SignInUser(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Email),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Email, user.Email),
            };
            var identity = new ClaimsIdentity(claims);
            var principal = new ClaimsPrincipal(identity);

            HttpContext.SignInAsync(principal);

            return RedirectToAction("InputView", "OrderMyFood");
        }


        /// <summary>
        /// Generates JWT token
        /// </summary>
        /// <param name="userInfo"></param>
        /// <returns></returns>
        private string GenerateJSONWebToken(User userInfo)
        {
            if (userInfo.Username == "Kiran")
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                  _config["Jwt:Issuer"],
                  claims: new List<Claim>(),
                  expires: DateTime.Now.AddMinutes(30),
                  signingCredentials: credentials);

                return new JwtSecurityTokenHandler().WriteToken(token);
            }
            else
            {
                return Unauthorized().ToString();
            }
        }
    }
}