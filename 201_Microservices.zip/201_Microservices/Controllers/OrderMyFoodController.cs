﻿using System;
using System.Collections.Generic;
using krishna_M1043200_OrderMyFood.Models;
using Microsoft.AspNetCore.Mvc;


namespace krishna_M1043200_OrderMyFood.Controllers
{
    [Route("api/[controller]/[action]/")]
    [ApiController]
    public class OrderMyFoodController : Controller
    {
        private readonly Services.RestaurantSearchService _RestaurantService;
        private readonly Services.OrderManagementService _RestaurantOrderService;

        /// <summary>
        /// Invokes Service
        /// </summary>
        /// <param name="resService">RestaurantSearchService</param>
        public OrderMyFoodController(Services.RestaurantSearchService resService, Services.OrderManagementService resOrderService)
        {
            _RestaurantService = resService;
            _RestaurantOrderService = resOrderService;
        }


        /// <summary>
        /// Gets input values to display output as view
        /// </summary>
        /// <param name="obj">RestaurantMapper</param>
        /// <returns>GetInputValues view</returns>
        [HttpGet]
        public ActionResult<List<RestaurantMapper>> GetInputValues([FromQuery]RestaurantMapper obj)
        {
            if (!ModelState.IsValid)
            {
                return View(obj);
            }
            obj.Loc = String.IsNullOrEmpty(obj.Loc) ? " " : obj.Loc;
            obj.Cuisine = String.IsNullOrEmpty(obj.Cuisine) ? " " : obj.Cuisine;
            obj.Dis = String.IsNullOrEmpty(obj.Dis) ? " " : obj.Dis;
            obj.Res_Name = String.IsNullOrEmpty(obj.Res_Name) ? " " : obj.Res_Name;
            obj.Ratings = String.IsNullOrEmpty(obj.Ratings) ? " " : obj.Ratings;
            obj.Budget = String.IsNullOrEmpty(obj.Budget) ? " " : obj.Budget;

            List<RestaurantMapper> res = _RestaurantService.CaptureInputData(obj);

            return View(res);

        }

        /// <summary>
        /// Placing order method
        /// </summary>
        /// <param name="obj">RestaurantMapper</param>
        /// <returns>GetInputValues view</returns>
        [HttpGet]
        public ActionResult PlaceOrder(string res_Name)
        {
            RestaurantMapper obj = new RestaurantMapper { Res_Name = res_Name };
            return View(obj);
        }

        /// <summary>
        /// Order Saving to repository
        /// </summary>
        /// <param name="obj">RestaurantMapper</param>
        /// <returns>GetInputValues view</returns>
        [HttpGet]
        public ActionResult ConfirmOrder([FromQuery]RestaurantMapper obj)
        {
            IActionResult response = Unauthorized();
            if (!ModelState.IsValid)
            {
                return View(obj);
            }
            OrderSaver getOrderSaved = _RestaurantOrderService.ConfirmingYourOrder(obj);

            return View(getOrderSaved);
        }

        /// <summary>
        /// Landing page view
        /// </summary>
        /// <returns>Input View</returns>
        public ActionResult InputView()
        {
            return View();
        }
    }
}