﻿using Microsoft.AspNetCore.Mvc;
using krishna_M1043200_OrderMyFood.Models;
using Stripe;


namespace krishna_M1043200_OrderMyFood.Controllers
{
    [Route("api/[controller]/[action]/")]
    [ApiController]
    public class PaymentController : Controller
    {
        private int amount = 100;
        private readonly Services.OrderManagementService _RestaurantOrderService;
        private readonly Services.ReviewManagementService _ReviewService;


        /// <summary>
        /// Invokes Service
        /// </summary>
        /// <param name="resService">RestaurantSearchService</param>
        public PaymentController(Services.OrderManagementService resOrderService, Services.ReviewManagementService reviewService)
        {
            _RestaurantOrderService = resOrderService;
            _ReviewService = reviewService;
        }


        /// <summary>
        /// Index view page to convert amount to valid format conversion rates
        /// </summary>
        /// <returns>Index view</returns>
        public IActionResult Index()
        {
            ViewBag.AmountToBePaid = amount;
            return View();
        }


        /// <summary>
        /// Payment gateway processing 
        /// </summary>
        /// <param name="stripeToken"></param>
        /// <param name="stripeTokenType"></param>
        /// <param name="stripeEmail"></param>
        /// <param name="obj"></param>
        /// <returns>Payment saved details result</returns>
        [HttpGet]
        public IActionResult Processing(string stripeToken, string stripeTokenType, string stripeEmail, [FromQuery]OrderSaver obj)
        {
            var options = new ChargeCreateOptions
            {
                Amount = amount,
                Currency = "USD",
                Description = "Placing order of:" + "\t" + obj.Quantity + "\t" + obj.MenuOrdered,
                Source = stripeToken,
                ReceiptEmail = stripeEmail
            };

            var service = new ChargeService();
            Charge charge = service.Create(options);

            obj.CardLast4Digits = charge.PaymentMethodDetails.Card.Last4;
            obj.CardTypeUsed = charge.PaymentMethodDetails.Card.Brand;
            obj.CreatedDate = charge.Created.Date.ToLocalTime().ToString();
            obj.User = charge.BillingDetails.Name;

            return RedirectToAction("SuccessfulOrder", "Payment", obj);
        }


        /// <summary>
        /// To Succesfully save your order
        /// </summary>
        /// <param name="obj">OrderSaver</param>
        /// <returns>Ordered result</returns>
        [HttpGet]
        public ActionResult SuccessfulOrder([FromQuery]OrderSaver obj)
        {
            if (!ModelState.IsValid)
            {
                return View(obj);
            }
            if (string.IsNullOrEmpty(obj.Res_Name).Equals(false))
            {
                var res = _RestaurantOrderService.SavingOrder(obj);
                return View();
            }
            else
            {
                return View();
            }
        }


        /// <summary>
        /// Updates your order
        /// </summary>
        /// <param name="obj">OrderSaver</param>
        /// <returns>Returns updated order</returns>
        [HttpGet]
        public ActionResult<OrderSaver> UpdateOrder([FromQuery]OrderSaver obj)
        {
            if (!ModelState.IsValid)
            {
                return View(obj);
            }
            if (string.IsNullOrEmpty(obj.Res_Name).Equals(false))
            {
                var res = _RestaurantOrderService.UpdateOrder(obj);
                return View(res);
            }

            return View();
        }


        /// <summary>
        /// Views your Order
        /// </summary>
        /// <param name="input">OrderSaver</param>
        /// <returns>Displays placed order</returns>
        [HttpGet]
        public ActionResult<OrderSaver> ViewOrder([FromQuery]OrderSaver input)
        {
            if (!ModelState.IsValid)
            {
                return View(input);
            }
            if (string.IsNullOrEmpty(input.Res_Name).Equals(false))
            {
                OrderSaver obj = new OrderSaver { Res_Name = input.Res_Name, User = input.User };
                var res = _RestaurantOrderService.ViewOrder(obj);
                return View(res);
            }
            else
            {
                return View();
            }
        }


        /// <summary>
        /// Deletes your order
        /// </summary>
        /// <param name="input">OrderSaver</param>
        /// <returns>Drops user order</returns>
        [HttpGet]
        public string DeleteOrder([FromQuery]OrderSaver input)
        {
            if (!ModelState.IsValid)
            {
                return null;
            }
            if (string.IsNullOrEmpty(input.Res_Name).Equals(false))
            {
                OrderSaver obj = new OrderSaver { Res_Name = input.Res_Name, User = input.User };
                var res = _RestaurantOrderService.CancelOrder(obj);

                return "Order deletion was succesful for customer:" + obj.User;
            }
            else
            {
                return "The user order has already been deleted ";
            }
        }


        /// <summary>
        /// Provides review comments
        /// </summary>
        /// <param name="input">OrderSaver</param>
        /// <returns>Drops user order</returns>
        [HttpGet]
        public string UpdateReview([FromQuery]OrderSaver input)
        {
            if (string.IsNullOrEmpty(input.Res_Name).Equals(false))
            {
                OrderSaver obj = new OrderSaver { Res_Name = input.Res_Name, User = input.User, Reviews = input.Reviews };
                var res = _ReviewService.UpdateReview(obj);

                return "Review updated successfully";
            }
            else
            {
                return "Review is not present for the user";
            }
        }


        /// <summary>
        /// Retrieve the content from the query string and return it
        /// </summary>
        /// <param name="previewContent"></param>
        /// <returns>Return order success message popup</returns>
        public string OpenPreview(string previewContent)
        {
            return previewContent;
        }
    }
}