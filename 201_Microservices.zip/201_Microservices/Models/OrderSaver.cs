﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;


namespace krishna_M1043200_OrderMyFood.Models
{
    /// <summary>
    /// Mapper to save - retrieve order details
    /// </summary>
    public class OrderSaver
    {
        public ObjectId Id { get; set; }

        [BsonElement("Res_Name")]
        public string Res_Name { get; set; }

        [Required(ErrorMessage = "Please choose quantity...")]
        [BsonElement("Quantity")]
        public string Quantity { get; set; }

        [BsonElement("Cuisine")]
        [Required(ErrorMessage = "Please choose cuisine...")]
        public string Cuisine { get; set; }

        [Required(ErrorMessage = "Please choose menu...")]
        public string MenuOrdered { get; set; }

        [BsonElement("AmountPaid")]
        public string AmountPaid { get; set; }

        [BsonElement("User")]
        public string User { get; set; }

        [BsonElement("CardLast4Digits")]
        public string CardLast4Digits { get; set; }

        [BsonElement("CardTypeUsed")]
        public string CardTypeUsed { get; set; }

        [BsonElement("CreatedDate")]
        public string CreatedDate { get; set; }

        public string Reviews { get; set; }
    }
}