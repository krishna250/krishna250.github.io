﻿using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;


namespace krishna_M1043200_OrderMyFood.Models
{
    /// <summary>
    /// Restaurant mapper class
    /// </summary>
    public class RestaurantMapper
    {
        public ObjectId Id { get; set; }

        /// <summary>
        /// Resturant name
        /// </summary>
        [BsonElement("Res_Name")]
        public string Res_Name { get; set; }

        /// <summary>
        /// Location
        /// </summary>
        [BsonElement("Loc")]
        public string Loc { get; set; }

        /// <summary>
        /// Distance
        /// </summary>
        [BsonElement("Dis")]
        public string Dis { get; set; }

        /// <summary>
        /// Cuisine
        /// </summary>
        [BsonElement("Cuisine")]
        [Required(ErrorMessage = "Please choose cuisine...")]
        public string Cuisine { get; set; }

        /// <summary>
        /// Budget
        /// </summary>
        [BsonElement("Budget")]
        public string Budget { get; set; }

        /// <summary>
        /// Ratings
        /// </summary>
        [BsonElement("Ratings")]
        public string Ratings { get; set; }

        /// <summary>
        /// Menu
        /// </summary>
        [BsonElement("Menu")]
        public object Menu { get; set; }

        /// <summary>
        /// Menu
        /// </summary>
        [BsonElement("ItemsToDisplay")]
        public string ItemsToDisplay { get; set; }

        public string InputMenu { get; set; }

        ///// <summary>
        ///// Reviews
        ///// </summary>
        [BsonElement("Reviews")]
        public string Reviews { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [BsonElement("Quantity")]
        public string Quantity { get; set; }

        /// <summary>
        /// Menu
        /// </summary>
        [BsonElement("Price")]
        public object Price { get; set; }

        public string MenuOrdered { get; set; }

        public string AmountPaid { get; set; }

        public string User { get; set; }

        public string CardLast4Digits { get; set; }

        public string CardTypeUsed { get; set; }

        public string CreatedDate { get; set; }
    }
}