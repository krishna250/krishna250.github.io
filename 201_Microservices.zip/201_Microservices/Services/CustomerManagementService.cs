﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;


namespace krishna_M1043200_OrderMyFood.Services
{
    public class CustomerManagementService : IUserService
    {
        private IDictionary<string, (User User, string Password)> _users = new Dictionary<string, (User User, string Password)>();
        private IDictionary<string, User> _externalUsers = new Dictionary<string, User>();

        /// <summary>
        /// Constructor call
        /// </summary>
        public CustomerManagementService()
        {
            InitializeStorage();
        }

        /// <summary>
        /// Adds the user to json file
        /// </summary>
        /// <param name="name"></param>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns>Added user</returns>
        public User Add(string name, string email, string password)
        {
            if (_users.ContainsKey(email.ToLower()))
            {
                throw new InvalidOperationException("Email already in use");
            }

            var user = new User(name, email);
            _users.Add(email.ToLower(), (User: user, Password: HashString(password)));
            PersistData();

            return user;
        }


        /// <summary>
        /// Authenticate user for credentials
        /// </summary>
        /// <param name="name"></param>
        /// <param name="password"></param>
        /// <returns>User auth details</returns>
        public User Authenticate(string name, string password)
        {
            if (_users.ContainsKey(name.ToLower()))
            {
                if (_users[name.ToLower()].Password.Equals(password) || _users[name.ToLower()].Password == HashString(password))
                {
                    return (_users[name.ToLower()].User);
                }
            }

            return null;
        }


        /// <summary>
        /// Adds external user
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="email"></param>
        /// <returns>Returns user details</returns>
        public User AddExternal(string id, string name, string email)
        {
            if (_users.ContainsKey(id))
            {
                throw new InvalidOperationException("Id already in use");
            }

            var user = new User(name, email);
            _externalUsers.Add(id, user);
            PersistData();

            return (user);
        }


        /// <summary>
        /// Authenticate external users
        /// </summary>
        /// <param name="id"></param>
        /// <returns>External user auth</returns>
        public User AuthenticateExternal(string id)
        {
            if (_externalUsers.ContainsKey(id))
            {
                return (_externalUsers[id]);
            }

            return (null);
        }

        /// <summary>
        /// Stores json data to a file
        /// </summary>
        private void InitializeStorage()
        {
            string pwd = null;
            if (File.Exists("storage.json"))
            {
                var str = File.ReadAllText("storage.json");
                var data = JObject.Parse(str);
                dynamic albums = data;
                foreach (dynamic album in albums.users)
                {
                    User obj = new User(Convert.ToString(album.First.Item1.Username), Convert.ToString(album.First.Item1.Email));
                    pwd = album.First.Item2;
                    _users.Add(obj.Email, (obj, Password: pwd));
                }
            }
        }


        /// <summary>
        /// Writes it in specified format
        /// </summary>
        private void PersistData()
        {
            var data = new { users = _users, externalUsers = _externalUsers };
            var str = JsonConvert.SerializeObject(data);
            File.WriteAllText("storage.json", str);
        }


        /// <summary>
        /// Hashes the password in specific standard
        /// </summary>
        /// <param name="str"></param>
        /// <returns>Hash password value</returns>
        private string HashString(string str)
        {
            var message = Encoding.Unicode.GetBytes(str);
            var hash = new SHA256Managed();
            
            var hashValue = hash.ComputeHash(message);

            return Encoding.Unicode.GetString(hashValue);
        }
    }
}