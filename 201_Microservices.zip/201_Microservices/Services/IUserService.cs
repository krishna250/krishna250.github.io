﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace krishna_M1043200_OrderMyFood.Services
{
    public interface IUserService
    {
        User Authenticate(string email, string password);
        User Add(string name, string email, string password);

        User AuthenticateExternal(string id);
        User AddExternal(string id, string name, string email);
    }
}