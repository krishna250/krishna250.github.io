﻿using MongoDB.Driver;
using MongoDB.Bson;
using Kiran_M1047905_OrderMyFood.Models;
using System;
using Microsoft.Extensions.Configuration;


namespace krishna_M1043200_OrderMyFood.Services
{
    public class OrderManagementService
    {
        private readonly IMongoCollection<RestaurantMapper> _restaurants;
        private readonly IMongoCollection<OrderSaver> _orderSave;
        private IConfiguration _config;


        /// <summary>
        /// Invokes Service
        /// </summary>
        /// <param name="settings">IOrderMyFoodDatabaseSettings</param>
        /// <param name="config">IConfiguration</param>
        public OrderManagementService(IOrderMyFoodDatabaseSettings settings, IConfiguration config)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _restaurants = database.GetCollection<RestaurantMapper>(settings.CollectionName);
            _orderSave = database.GetCollection<OrderSaver>(settings.CollectionName);
            _config = config;
        }


        /// <summary>
        /// Confirms your order to DB
        /// </summary>
        /// <param name="obj">RestaurantMapper</param>
        /// <returns>OrderSaver Model</returns>
        public OrderSaver ConfirmingYourOrder(RestaurantMapper obj)
        {
            OrderSaver saveOrder = new OrderSaver();
            var availableCount = "";
            var getPrice = "";
            int count = 0;
            var client = new MongoClient(_config["OrderMyFoodDatabaseSettings:ConnectionString"]);
            var database = client.GetDatabase(_config["OrderMyFoodDatabaseSettings:DatabaseName"]);
            var collection = database.GetCollection<BsonDocument>(_config["OrderMyFoodDatabaseSettings:CollectionName"]);
            var list = collection.Find(new BsonDocument()).ToList();

            foreach (var dox in list)
            {
                if (dox.GetElement("Res_Name").Value.Equals(obj.Res_Name) && dox.Elements.ToJson().Contains("Menu"))
                {
                    if (count < 1)
                    {
                        availableCount = Convert.ToInt32(dox.GetElement("Menu").Value.ToBsonDocument().GetElement(obj.Cuisine).Value.ToBsonDocument()
                                                        .GetElement(obj.InputMenu).Value).ToString();

                        getPrice = Convert.ToInt32(
                                                   dox.GetElement("Price").Value.ToBsonDocument().GetElement(obj.InputMenu).Value).ToString();

                        count++;
                    }
                }
                
            }

            int updatedQuantityCount = Convert.ToInt32(availableCount) - Convert.ToInt32(obj.Quantity);
            int amountToBePaid = Convert.ToInt32(obj.Quantity) * Convert.ToInt32(getPrice);

            var update = Builders<RestaurantMapper>.Update.Set("Menu." + obj.Cuisine + "." + obj.InputMenu + "", updatedQuantityCount);
            var filter = Builders<RestaurantMapper>.Filter.And(Builders<RestaurantMapper>.Filter.Eq(x => x.Res_Name, obj.Res_Name));
            var result = _restaurants.UpdateOne(filter, update);

            saveOrder.AmountPaid = amountToBePaid.ToString();
            saveOrder.MenuOrdered = obj.InputMenu;
            saveOrder.Quantity = obj.Quantity;
            saveOrder.Res_Name = obj.Res_Name;

            return saveOrder;
        }


        /// <summary>
        /// Saves your order to repository
        /// </summary>
        /// <param name="obj">OrderSaver</param>
        /// <returns>says if the result is working as expected</returns>
        public string SavingOrder(OrderSaver obj)
        {
            _orderSave.InsertOne(obj);

            return "ok";
        }


        /// <summary>
        /// Cancels your order
        /// </summary>
        /// <param name="obj">OrderSaver</param>
        /// <returns>says if the result is working as expected</returns>
        public string CancelOrder(OrderSaver obj)
        {
            var filter = Builders<OrderSaver>.Filter.And(Builders<OrderSaver>.Filter.Eq(x => x.Res_Name, obj.Res_Name),
                         Builders<OrderSaver>.Filter.Eq(x => x.User, obj.User));

            _orderSave.DeleteOne(filter);

            return "ok";
        }


        /// <summary>
        /// Updates your order
        /// </summary>
        /// <param name="obj">OrderSaver</param>
        /// <returns>says if the result is working as expected</returns>
        public OrderSaver UpdateOrder(OrderSaver obj)
        {
            var availableCount = "";
            var getPrice = "";
            int count = 0;
            var client = new MongoClient(_config["OrderMyFoodDatabaseSettings:ConnectionString"]);
            var database = client.GetDatabase(_config["OrderMyFoodDatabaseSettings:DatabaseName"]);
            var collection = database.GetCollection<BsonDocument>(_config["OrderMyFoodDatabaseSettings:CollectionName"]);
            var list = collection.Find(new BsonDocument()).ToList();

            foreach (var dox in list)
            {
                if (dox.GetElement("Res_Name").Value.Equals(obj.Res_Name) && dox.Elements.ToJson().Contains("Menu"))
                {
                    if (count < 1)
                    {
                        availableCount = Convert.ToInt32(dox.GetElement("Menu").Value.ToBsonDocument().GetElement(obj.Cuisine).Value.ToBsonDocument()
                                                        .GetElement(obj.MenuOrdered).Value).ToString();

                        getPrice = Convert.ToInt32(dox.GetElement("Price").Value.ToBsonDocument().GetElement(obj.MenuOrdered).Value).ToString();

                        count++;
                    }
                }
            }

            int updatedQuantityCount = Convert.ToInt32(availableCount) - Convert.ToInt32(obj.Quantity);
            int amountToBePaid = Convert.ToInt32(obj.Quantity) * Convert.ToInt32(getPrice);

            var update = Builders<RestaurantMapper>.Update.Set("Menu." + obj.Cuisine + "." + obj.MenuOrdered + "", updatedQuantityCount);
            var filter = Builders<RestaurantMapper>.Filter.And(Builders<RestaurantMapper>.Filter.Eq(x => x.Res_Name, obj.Res_Name));
            var result = _restaurants.UpdateOne(filter, update);

            var orderUpdate = Builders<OrderSaver>.Update.Combine(Builders<OrderSaver>.Update.Set("MenuOrdered", obj.MenuOrdered),
            Builders<OrderSaver>.Update.Set("Quantity", obj.Quantity),Builders<OrderSaver>.Update.Set("Cuisine", obj.Cuisine),
            Builders<OrderSaver>.Update.Set("AmountPaid", amountToBePaid));

            var orderFilter = Builders<OrderSaver>.Filter.And(Builders<OrderSaver>.Filter.Eq(x => x.Res_Name, obj.Res_Name),
                              Builders<OrderSaver>.Filter.Eq(x => x.User, obj.User));

            var orderResult = _orderSave.UpdateOne(orderFilter, orderUpdate);

            return ViewOrder(obj);
        }


        /// <summary>
        /// Allows user to view the order
        /// </summary>
        /// <param name="obj">OrderSaver</param>
        /// <returns>Model to show in view</returns>
        public OrderSaver ViewOrder(OrderSaver obj)
        {
            var filter = Builders<OrderSaver>.Filter.And(Builders<OrderSaver>.Filter.Eq(x => x.Res_Name, obj.Res_Name),
                         Builders<OrderSaver>.Filter.Eq(x => x.User, obj.User));

            OrderSaver resultSet = _orderSave.Find(filter).First();

            return resultSet;
        }
    }
}