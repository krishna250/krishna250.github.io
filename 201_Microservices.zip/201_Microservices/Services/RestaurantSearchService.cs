﻿using System.Collections.Generic;
using System.Linq;
using MongoDB.Driver;
using Kiran_M1047905_OrderMyFood.Models;
using Newtonsoft.Json;
using System;
using MongoDB.Bson.Serialization;


namespace krishna_M1043200_OrderMyFood.Services
{
    public class RestaurantSearchService
    {
        private readonly IMongoCollection<RestaurantMapper> _restaurants;

        /// <summary>
        /// Constructor to get your DB values
        /// </summary>
        /// <param name="settings"></param>
        public RestaurantSearchService(IOrderMyFoodDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _restaurants = database.GetCollection<RestaurantMapper>(settings.CollectionName);
        }

        /// <summary>
        /// Gets your input data
        /// </summary>
        /// <param name="id">RestaurantMapper</param>
        /// <returns>Multiple user restaurant result</returns>
        public List<RestaurantMapper> CaptureInputData(RestaurantMapper id)
        {
            var filter = Builders<RestaurantMapper>.Filter.Or(
                         Builders<RestaurantMapper>.Filter.Eq(x => x.Res_Name, id.Res_Name),
                         Builders<RestaurantMapper>.Filter.Eq(x => x.Loc, id.Loc),
                         Builders<RestaurantMapper>.Filter.Eq(x => x.Dis, id.Dis),
                         Builders<RestaurantMapper>.Filter.Eq(x => x.Cuisine, id.Cuisine),
                         Builders<RestaurantMapper>.Filter.Eq(x => x.Ratings, id.Ratings),
                         Builders<RestaurantMapper>.Filter.Eq(x => x.Budget, id.Budget));

                List<RestaurantMapper> obj = _restaurants.Find(filter).ToList();

            return obj;
        }
    }
}