﻿using MongoDB.Bson;
using MongoDB.Driver;
using Kiran_M1047905_OrderMyFood.Models;
using Microsoft.Extensions.Configuration;


namespace krishna_M1043200_OrderMyFood.Services
{
    public class ReviewManagementService
    {
        private readonly IMongoCollection<RestaurantMapper> _restaurants;
        private readonly IMongoCollection<OrderSaver> _orderSave;
        private IConfiguration _config;


        /// <summary>
        /// Invokes Service
        /// </summary>
        /// <param name="settings">IOrderMyFoodDatabaseSettings</param>
        /// <param name="config">IConfiguration</param>
        public ReviewManagementService(IOrderMyFoodDatabaseSettings settings, IConfiguration config)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _restaurants = database.GetCollection<RestaurantMapper>(settings.CollectionName);
            _orderSave = database.GetCollection<OrderSaver>(settings.CollectionName);
            _config = config;
        }


        /// <summary>
        /// Updates user review
        /// </summary>
        /// <param name="oS"></param>
        /// <returns></returns>
        public string UpdateReview(OrderSaver oS)
        {
            RestaurantMapper rM = new RestaurantMapper();

            var client = new MongoClient(_config["OrderMyFoodDatabaseSettings:ConnectionString"]);
            var database = client.GetDatabase(_config["OrderMyFoodDatabaseSettings:DatabaseName"]);
            var collection = database.GetCollection<BsonDocument>(_config["OrderMyFoodDatabaseSettings:CollectionName"]);

            var filter = Builders<RestaurantMapper>.Filter.Eq("Res_Name", oS.Res_Name);
            var update = Builders<RestaurantMapper>.Update.Set("Reviews", oS.User + ":" + oS.Reviews);
            var result = _restaurants.UpdateOne(filter, update);

            return "ok";
        }
    }
}