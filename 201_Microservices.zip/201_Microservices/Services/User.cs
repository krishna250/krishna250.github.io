﻿
namespace krishna_M1043200_OrderMyFood.Services
{
    public class User
    {
        public User(string username, string email)
        {
            Username = username;
            Email = email;
        }

        public string Username { get; }
        public string Email { get; }
    }
}