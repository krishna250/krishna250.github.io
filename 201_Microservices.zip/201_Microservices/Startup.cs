﻿using System.Text;
using krishna_M1043200_OrderMyFood.Models;
using krishna_M1043200_OrderMyFood.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Stripe;


namespace krishna_M1043200_OrderMyFood
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<OrderMyFoodDatabaseSettings>(Configuration.GetSection(nameof(OrderMyFoodDatabaseSettings)));

            services.AddSingleton<IOrderMyFoodDatabaseSettings>(sp => sp.GetRequiredService<IOptions<OrderMyFoodDatabaseSettings>>().Value);

            services.AddSingleton<IUserService, CustomerManagementService>();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = Configuration["Jwt:Issuer"],
                        ValidAudience = Configuration["Jwt:Issuer"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                    };
                });

            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.LoginPath = "/auth/login";
                    options.AccessDeniedPath = "/auth/accessdenied";
                })
                .AddFacebook(options =>
                {
                    options.AppId = "591195774618768";
                    options.AppSecret = "1700018f3016ee68d503d6bdbf558ed6";
                    options.SignInScheme = "TempCookie";
                }).AddCookie("TempCookie");

            services.AddSingleton<RestaurantSearchService>();

            services.AddSingleton<OrderManagementService>();

            services.AddSingleton<ReviewManagementService>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            StripeConfiguration.ApiKey = "sk_test_0eCjOPdmSUUX4HE8k6orE9wW009uXwuPQL";

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseMvc();
        }
    }
}