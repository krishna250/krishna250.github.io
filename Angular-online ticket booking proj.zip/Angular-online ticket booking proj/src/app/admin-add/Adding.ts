export interface Adding{
    CustomerName: string,
    EmailId: string,
    PhoneNumber:number,
    Password:string,
    IsAdmin:boolean
}