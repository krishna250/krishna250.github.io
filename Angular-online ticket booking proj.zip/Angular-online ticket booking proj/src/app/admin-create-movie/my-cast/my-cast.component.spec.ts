import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCastComponent } from './my-cast.component';

describe('MyCastComponent', () => {
  let component: MyCastComponent;
  let fixture: ComponentFixture<MyCastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyCastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyCastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
