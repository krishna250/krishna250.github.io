import { Component, OnInit } from '@angular/core';
import {MoviesService} from './movies.service';
import {Observable} from 'rxjs'

@Component({
  selector: 'app-my-cast',
  templateUrl: './my-cast.component.html',
  styleUrls: ['./my-cast.component.css'],
  providers:[MoviesService]
})
export class MyCastComponent implements OnInit {

  constructor(private ser:MoviesService) { }
   info1={ 
  CastType :  "",
  CastPhoto : "",
  Name : ""   
 };


  ngOnInit() {
  }
  getMovie(event:any){
  console.log(event.target.value);
this.info1.Name=event.target.value;
console.log(this.info1.Name);

  }
    getvideo(event:any){
this.info1.CastPhoto=event.target.value;
  }
     getRating(event:any){
this.info1.CastType=event.target.value;

  }
  Savesubmit():void 
{
 if  (this.info1.Name != ""  &&  this.info1.CastPhoto  != ""  &&( this.info1.CastType == "Actor" || this.info1.CastType == "Actress" || this.info1.CastType == "Artist" || this.info1.CastType == "Director" ))
 {
this.ser.AddMovieInfo(this.info1).subscribe();

 }
 else 
 {
   alert("error");
 }

}
}




 




