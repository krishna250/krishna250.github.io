import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCreatePlayComponent } from './admin-create-play.component';

describe('AdminCreatePlayComponent', () => {
  let component: AdminCreatePlayComponent;
  let fixture: ComponentFixture<AdminCreatePlayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCreatePlayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCreatePlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
