import { Component, OnInit } from '@angular/core';
import  { Router } from '@angular/router';
import { AdminMainPageService } from './admin-main-page.service';

@Component({
  selector: 'app-admin-main-page',
  templateUrl: './admin-main-page.component.html',
  styleUrls: ['./admin-main-page.component.css']
})
export class AdminMainPageComponent implements OnInit {

  constructor(private router:Router,private service:AdminMainPageService) { }
Movies:any[]=[];
Play:any[]=[];
MovieCount:Number[]=[];
PlayCount:Number[]=[];
CastCount:Number[]=[];
AdminCount:Number[]=[];



 ngOnInit()
  { 
    // this.service.getMovieCount(this.detailsToBePassed.MovieId)
    // .subscribe(
    //   data =>{
    //     this.Movies=data;
    //    console.log(data);
    //   })     
    this.service.getMovieCount()
    .subscribe(
      data =>{
        this.Movies=data;
        this.MovieCount[0]=this.Movies.length;
        console.log(this.MovieCount[0]);
      }
    )
        this.service.getPlayCount()
    .subscribe(
      data =>{
        this.Play=data;
        this.PlayCount[0]=this.Play.length;
        console.log(this.PlayCount[0]);
      }
    )
           this.service.getCastCount()
    .subscribe(
      data =>{
        //this.Cast=data;
        this.CastCount[0]=data.length;
        console.log(this.CastCount[0]);
      }
    )
     this.service.getAdminCount()
    .subscribe(
      data =>{
        //this.Cast=data;
        this.AdminCount[0]=data;
        console.log(this.AdminCount[0]);
      }
    )
  //  console.log(this.Movies);
    
  }
redirect() : void {
         
this.router.navigate(['/Admin/CreateMovie']);
} 
redirect1() : void {
         
this.router.navigate(['/Admin/CreatePlay']);
} 
redirectAddAdmin():void{
this.router.navigate(['/Admin/AddAdmin']);
  
}
redirectPlayUpdate():void{
this.router.navigate(['/Admin/Play/Delete']);
  
}
redirectMovieUpdate():void{
this.router.navigate(['/Admin/Movie/Delete']);
  
}
redirectMovieUpdate1():void{
this.router.navigate(['/all']);
  
}
}
