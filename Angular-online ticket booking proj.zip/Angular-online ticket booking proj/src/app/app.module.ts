import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MovieTheatreDetailsComponent } from './movie-theatre-details/movie-theatre-details.component';
import { DebitCardComponent } from './debit-card/debit-card.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { AlertModule } from 'ngx-bootstrap';
import { Component, OnInit } from '@angular/core';
import { MovieTheatreDetailsService } from './movie-theatre-details/MovieTheatreDetails.service';
import { BankoptionsComponent } from './bankoptions/bankoptions.component';
import { NetBankingFormComponent } from './net-banking-form/net-banking-form.component';
import { paymentserService } from './payemntdetails/paymentser.service';
import { HttpClientModule } from '@angular/common/http';
import { MatButtonModule, MatCheckboxModule } from '@angular/material';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MoviesComponent } from './movies/movies.component';
import { PlaysComponent } from './plays/plays.component';
import { MusicComponent } from './music/music.component';
import { SportsComponent } from './sports/sports.component';
import { ArtfestComponent } from './artfest/artfest.component';
import { ComicComponent } from './comic/comic.component';
import { RouterModule, Routes } from '@angular/router';
import { OffersComponent } from './offers/offers.component';
import { DetailsComponent } from './details/details.component';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule, MatIconModule } from '@angular/material';
import { SeatComponent } from './seat/seat.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SignupComponent } from './signup/signup.component';
import { BookComponent } from './book/book.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';

import { PaymentPageComponent } from './payment-page/payment-page.component';
import { PayemntdetailsComponent } from './payemntdetails/payemntdetails.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { LocalUserService } from "./LocalUserService.service";
import { DataService } from './data.service';
import { PlayService } from "./plays/play.service";
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { BookingHistoryService } from './booking-history/booking-history.service';
import { MovieEditComponent } from './movie-edit/movie-edit.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
import { AdminComponent } from './admin/admin.component';
import { AddadminComponent } from './addadmin/addadmin.component';
import { AdminCreateMovieComponent } from './admin-create-movie/admin-create-movie.component';
import { AdminCreatePlayComponent } from './admin-create-play/admin-create-play.component';
import { AdminMainPageService } from './admin-main-page/admin-main-page.service';
import { AdminAddComponent } from './admin-add/admin-add.component';
import { AddAdminService } from './admin-add/admin-add.service';
// import { MovieEditComponent } from './movie-edit/movie-edit.component';
import { MovieService } from './movie-edit/movie.service';
import { PlayEditComponent } from './play-edit/play-edit.component';
import { MovieUpdateComponent } from './movie-update/movie-update.component';
import { MovieUpdateService } from './movie-update/movie-update.service';
import { PlayUpdateComponent } from './play-update/play-update.component';
import { MoviesService } from './admin-create-movie/movies.service';
import  {  UpdateprofileComponent  }  from  './updateprofile/updateprofile.component';
import  {  UpdateprofileService  }  from  './updateprofile/updateprofileservice';
import { AuthGuard } from './auth.guard';
import { MyCastComponent } from './my-cast/my-cast.component';
// import { PlayService } from "./admin-create-play/play.service";

//import{MatButtonModule} from '@angular/material'; 
const appRoutes: Routes = [
  { path: 'net-banking-form/:bank', component: NetBankingFormComponent },
  // { path: '',redirectTo:'/debitcard',pathMatch:'full' },
  { path: 'debitcard', component: DebitCardComponent },
  { path: 'home', component: HomeComponent },
  { path: 'movies', component: MoviesComponent },
  { path: 'plays', component: PlaysComponent },
  { path: 'music', component: MusicComponent },
  { path: 'sports', component: SportsComponent },
  { path: 'artfest', component: ArtfestComponent },
  { path: 'comic', component: ComicComponent },
  { path: 'paymentpage', component: PaymentPageComponent },
  { path: 'offers', component: OffersComponent },
  { path: 'movie-theatre-details', component: MovieTheatreDetailsComponent },
  { path: 'details', component: DetailsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'seat', component: SeatComponent },
  { path: 'book', component: BookComponent },
  { path: 'pay', component: PaymentPageComponent },
  { path: 'option', component: BankoptionsComponent },
  { path: 'paymentdetails', component: PayemntdetailsComponent },
  { path: 'bookinghistory', canActivate: [AuthGuard], component: BookingHistoryComponent },
  { path: 'Admin/CreateMovie', canActivate: [AuthGuard], component: AdminCreateMovieComponent },
  { path: 'Admin/CreatePlay', canActivate: [AuthGuard], component: AdminCreatePlayComponent },
  { path: 'Admin/AddAdmin', canActivate: [AuthGuard], component: AdminAddComponent },
  { path: 'Admin/Movie/Delete',canActivate: [AuthGuard],component: MovieEditComponent },
  { path: 'Admin/Play/Delete',canActivate: [AuthGuard],component: PlayEditComponent },
  { path: 'Admin/Movie/Update/:id', canActivate: [AuthGuard], component: MovieUpdateComponent },
  { path: 'Admin/Play/Update/:id', canActivate: [AuthGuard], component: PlayUpdateComponent },
  { path: 'Admin', canActivate: [AuthGuard], component: AdminMainPageComponent },
  { path: 'updateprofile', canActivate: [AuthGuard], component: UpdateprofileComponent },
  {path:'all',component:MyCastComponent },






  { path: '**', redirectTo: '/home', pathMatch: 'full' }
]

@NgModule({
  declarations: [
    // MovieEditComponent,
    PlayEditComponent,
    MovieUpdateComponent,
    PlayUpdateComponent,
    DebitCardComponent,
    AppComponent,
    HomeComponent,
    MoviesComponent,
    PlaysComponent,
    MusicComponent,
    SportsComponent,
    ArtfestComponent,
    ComicComponent,
    OffersComponent,
    BookingHistoryComponent,
    SeatComponent,
    MovieTheatreDetailsComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    SignupComponent,
    DetailsComponent,
    BookComponent,
    PaymentPageComponent,
    BankoptionsComponent,
    PayemntdetailsComponent,
    NetBankingFormComponent,
    MovieEditComponent,
    AdminMainPageComponent,
    AdminComponent,
    AddadminComponent,
    AdminCreatePlayComponent,
    AdminCreateMovieComponent,
    AdminAddComponent,
    UpdateprofileComponent,
    MyCastComponent

  ],
  imports: [
    BrowserModule, HttpClientModule,
    RouterModule.forRoot(appRoutes, { useHash: true }),
    MatCheckboxModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule, MatInputModule, MatIconModule,
    MatCardModule,
    NoopAnimationsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatMenuModule,
    MatButtonModule
    //  AlertModule.forRoot(),

  ],
  providers: [MovieTheatreDetailsService,
    AdminMainPageService,
    AddAdminService,
    MovieUpdateService,
    MovieService,
    AuthGuard,
    MoviesService, DataService, LocalUserService, paymentserService, PlayService, BookingHistoryService, UpdateprofileService],
  bootstrap: [AppComponent]
})
export class AppModule implements OnInit {
  private user: string = '';
  isUserLoggedIn = false;

  constructor() { }

  getUserName(): void {
    //calling loginservice and setting he user
  }

  ngOnInit(): void {
    this.getUserName();
  }

  /*  onSubmitted(loggenIn: boolean) {
      this.isUserLoggedIn = true;
    }
  */


}
