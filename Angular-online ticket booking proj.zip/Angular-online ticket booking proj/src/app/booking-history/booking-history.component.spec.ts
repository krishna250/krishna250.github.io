import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BookingHistoryService} from './booking-history.service';
import {HttpClient,HttpResponse} from '@angular/common/http'
import { BookingHistoryComponent } from './booking-history.component';

fdescribe('BookingHistoryComponent', () => {
  let component: BookingHistoryComponent;
  let fixture: ComponentFixture<BookingHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
