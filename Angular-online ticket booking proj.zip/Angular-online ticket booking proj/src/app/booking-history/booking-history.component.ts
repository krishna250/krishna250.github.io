import { Component, OnInit } from '@angular/core';
import {BookingHistoryService} from './booking-history.service';
import { HttpClientModule } from '@angular/common/http';
import{LoginComponent} from '../login/login.component';
import {CancelBooking} from './CancelBooking';
import {HttpClient,HttpResponse} from '@angular/common/http';
@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css'],
  providers:[BookingHistoryService,HttpClient]
})
export class BookingHistoryComponent implements OnInit {
book:any[]=[];
id=LoginComponent.abc;
public CancelObj:CancelBooking;

result:any;
  constructor(private ser:BookingHistoryService) {
    this.CancelObj=new CancelBooking();
   }
  
  ngOnInit() {
     this.ser.getMethod(this.id).subscribe(
   
      data => {
          
        this.book = data;
       // alert(this.id);
        
      }

    )
  }
  func(ReservationId:number,SeatBooked:string)
  {
   this.CancelObj.ReservationId=ReservationId;
  this.CancelObj.SeatBooked=SeatBooked;
    //alert("Inside");
    this.ser.deleteMethod(this.CancelObj).subscribe(
      data=>{
        this.result=data;
        //alert(this.result);
        //window.location.reload();
  }
    )

}
}
