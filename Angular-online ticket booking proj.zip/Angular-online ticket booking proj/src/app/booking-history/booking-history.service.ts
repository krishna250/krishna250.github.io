import { Injectable } from '@angular/core';
import {HttpClient,HttpResponse} from '@angular/common/http'
import {Observable} from 'rxjs';
//import {CancelBooking} from './CancelBooking';
@Injectable()
export class BookingHistoryService {
    //CancelObj:CancelBooking;
constructor(private http:HttpClient){

}
private url= "https://ticketshereapidotnetnov2017.azurewebsites.net/api/BookingHistory";
getMethod(id:number):Observable<any>{
    console.log(id);
    const url:string = `${this.url}/${id}`;
return this.http.get(url);
}
private url1="https://ticketshereapidotnetnov2017.azurewebsites.net/api/CancelTickets";


deleteMethod(CancelObj):Observable<any>{


   //return this.http.post(this.url1,this.CancelObj);
   
return this.http.post(this.url1,CancelObj);
}
}