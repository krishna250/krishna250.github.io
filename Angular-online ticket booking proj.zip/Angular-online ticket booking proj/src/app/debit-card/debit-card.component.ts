import { Component, OnInit } from '@angular/core';
import { payment } from '../payment';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';


@Component({
  selector: 'app-debit-card',
  templateUrl: './debit-card.component.html',
  styleUrls: ['./debit-card.component.css']
})
export class DebitCardComponent implements OnInit {

  isVisa = false;
  isMastero = false;
  

  constructor(private router : Router) { }
  payment_list: payment[] = [];
  form: FormGroup;

  
   
  toPay(form){
    this.payment_list.push(this.form.value);
    
  }

  checkCard(str:string){
    if(str.length > 1){
        return;
    }
    else if(str.length == 0){
      this.isVisa = false;
      this.isMastero = false;
    }
    
    if(str == "4"){
      this.isVisa = true;
    }
    else if(str == "5" || str == "6"){
      this.isMastero = true;
    }
    else{
      this.isVisa = false;
      this.isMastero = false;
    }
  }

  ngOnInit() {
    this.form = new FormGroup({
      card_number: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.maxLength(16), Validators.minLength(16)]),
      name_on_the_card: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+')]),
      exp_month: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.min(1), Validators.max(12), Validators.maxLength(2), Validators.maxLength(2)]),
      exp_year: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.min(2018), Validators.max(2030), Validators.maxLength(4), Validators.maxLength(4)]),
      cvv: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.maxLength(3), Validators.minLength(3)])
    })
  }

redirect() : void {
console.log ("ishan");
this.router.navigate(['/paymentdetails']);
} 
}
