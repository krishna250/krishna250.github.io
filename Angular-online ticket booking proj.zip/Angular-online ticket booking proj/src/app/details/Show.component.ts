export interface info
{

 PlayName:string;
TimeDuration:string;
Poster:string;
StartDate:string;
Description:string;
Language:string;
EndDate:string;
Genre:string;
CityName:string; 
}