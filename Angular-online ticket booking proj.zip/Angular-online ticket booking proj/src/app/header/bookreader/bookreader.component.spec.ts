import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookreaderComponent } from './bookreader.component';

describe('BookreaderComponent', () => {
  let component: BookreaderComponent;
  let fixture: ComponentFixture<BookreaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookreaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookreaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
