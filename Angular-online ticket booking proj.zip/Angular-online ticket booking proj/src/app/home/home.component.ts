import { Component, OnInit } from '@angular/core';
import { HomeService } from '../home/homeservice';
import { LocalUserService, LocalUserObject } from '../LocalUserService.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[HomeService]
})
export class HomeComponent implements OnInit {

  constructor(private ser :HomeService, private local :LocalUserService) { }
  moviesList: any;

   searchObj: LocalUserObject = {
    PlayId: 0,
    MovieId: 0,
    Name: "",
    SeatNumber: "A1",
    TotalCost: 0,
    BankName: "HDFC",
    PaymentType: "Card",
    ReservationTypeId: 123,
    TicketCost: 100,
    MovieDetailsId: 0,
    TotalBookedSeats: 0,
    CustomerId: 0,
    ScreeningId: 0,
    type: "Movie",
    AudiId: 0,
    ScreeningTime: "time"
  };
  ngOnInit() {
      this.ser.getAllMovies().subscribe
      (
      MovieData => {
        // console.log("abc");
        // console.log(MovieData);
        this.moviesList = MovieData;
        console.log(this.moviesList.length);
      }
      )
  }
   setMovieId(target):void {
 


     this.searchObj=this.local.getLocalUserObject();
      this.searchObj.MovieId=target;

    // alert(target.id);
   // this.searchObj.MovieId = target.id;
//alert(this.searchObj);
    this.local.setLocalUserObject(this.searchObj);


  }

}
