import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import{LoginService} from './loginservice';
import {NgForm} from '@angular/forms';
import{Login} from './login';
import { Router } from '@angular/router';
import {  LocalUserService,  LocalUserObject  }  from  '../LocalUserService.service';
import {DataService} from '../data.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
   providers:[LoginService,LocalUserService,DataService]

})
export class LoginComponent implements OnInit {
  static abc : number = 0;
  hide=true;
 
   constructor(private ser:LoginService,private router:Router,private Loc: LocalUserService,private ser1:DataService) { 
   
   }
ngOnInit() {
  
}
 mobile_number = new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.maxLength(10), Validators.minLength(10)]);
    password= new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]*'), Validators.minLength(6)]);
    email = new FormControl('', [Validators.required, Validators.email]);
  getErrorMessage() {
    return this.email.hasError('required') ? 'please enter valid Phone Number' :
        this.email.hasError('email') ? 'Not a valid mobile number' :
            '';
  }
   getErrorMessage2() {
    return this.mobile_number.hasError('required') ? 'please enter valid mobile number' :
        this.mobile_number.hasError('mobile_number') ? 'Not a valid mobile number' :
            '';
  }
  mobile:any;
  password1:any;
  a:number;
  res:string;
  result:any[]=[];
  as:String;
  getmobilenum(event:any){
this.mobile=event.target.value;

  }
  getpassword(event:any){
    this.password1=event.target.value;
   
  }
  value:Login;
  value2:Login;

  public errorMessage = '';
getInfo()
{
  
  this.value=this.mobile;
 
  this.value2=this.password1;
 
this.ser.getCustomerId(this.value+"("+this.value2).subscribe(data =>{

LoginComponent.abc=data;
console.log(data);
console.log(LoginComponent.abc);
if(data==="None"){
this.errorMessage = 'Invalid Mobile Number or Password'; 
}
else{
this.as=data;
var isad=this.as.length-1;
var isa=this.as.length;
var iscu=this.as.substring(0,isad);
console.log("HI"+iscu);
LoginComponent.abc= parseInt(iscu);
console.log(LoginComponent.abc)
this.res=this.as.substring(isad, (isa));
console.log("HIIIIIIIIIII"+this.res);
if(this.res==="C")
{
  this.updatehistory();
}
else if(this.res=="A"){
 // alert("Admin");
   this.router.navigate(['/Admin']);
}  

}

});
  
}

redirect(){
  this.router.navigate(['/home']);
}
updatehistory(){
  this.router.navigate(["/header"]);

}
  
}