
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

import{Login} from './login';


@Injectable()
export class LoginService {
play:Login[]=[];

  constructor(private http: HttpClient) { }

private Url = 'https://ticketshereapidotnetnov2017.azurewebsites.net/api/Login?input=';

getCustomerId(str:string ):Observable <any> {
    console.log(str);
 const url = `${this.Url}${str}`;
return this.http.get(url);


  }
}