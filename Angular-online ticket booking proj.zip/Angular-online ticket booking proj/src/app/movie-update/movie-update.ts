export class MovieInfo {
  PlayId:Number;
  Description:string;
  Language:string;
  TimeDuration:string;
  Poster:string;
  VideoUrl:string;
  Price:Number;
  ModifiedDate=new Date();
  CityId:Number;
  Rating:string;
  StartDate=new Date();
  EndDate=new Date();
  Genre:string;
  MovieId:Number;
  ReleaseDate=new Date();
  Name:string;
  UpdatedBy:number;
  Isdeleted:Boolean;
}