export interface movie
{
Name:string;
 Genre:string;
 Rating:number;
 Language:string;
 
}