export interface User{
    UserId: String;
    Password: String;
}
