import { Component, OnInit, OnDestroy } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Params,Router } from '@angular/router';
import { paymentserService } from './paymentser.service';
import { DataService } from '../data.service';
import { Custom } from './pay';
import { LocalUserService, LocalUserObject } from '../LocalUserService.service';
import { LoginComponent } from '../login/login.component';
@Component({
  selector: 'app-payemntdetails',
  templateUrl: './payemntdetails.component.html',
  styleUrls: ['./payemntdetails.component.css']
})


export class PayemntdetailsComponent implements OnInit, OnDestroy {
  public obj: LocalUserObject;
  values: any[] = [];
  abc: any;
  type: string;
  private route$: Subscription;
  bank: string;

  comment: string;
  valcomment(event) {
    this.comment = (event.target.value);

  }

  bo = {
    PlayId: 0,
    PlayName: "",
    MovieId: 0,
    MovieName: "",
    SeatNumber: "",
    TotalCost: 0,
    BankName: "",
    PaymentType: "",
    ReservationTypeId: 1,
    MovieDetailsId: 0,
    TotalBookedSeat: 0,
    Date: "2018-01-17T14:12:07.555Z",
    CustomerId: 17,
    ReservationId: 0,
    TransactionId: 0,
    Comments: "",
    ScreeningId: 0
  };

  constructor(private route: ActivatedRoute, private ser: paymentserService, private ser1: DataService, private ser3: LocalUserService,private router:Router) {
    this.obj = this.ser3.getLocalUserObject();
    //console.log(this.obj.TotalCost);
    this.bo.TotalCost = this.obj.TotalCost;
    //console.log(this.obj.TotalCost); 
    this.bo.TotalBookedSeat = this.obj.TotalBookedSeats;
    this.bo.SeatNumber = this.obj.SeatNumber;
    //console.log(this.bo.TotalBookedSeat);
    this.bo.PlayId = this.obj.PlayId;
    this.bo.MovieId = this.obj.MovieId;
    if (LoginComponent.abc == 0) 
    {
      this.bo.CustomerId = 17
        ;
    }
    else
  
      this.bo.CustomerId = LoginComponent.abc;
    
    this.bo.ScreeningId = this.obj.ScreeningId;
    this.bo.MovieDetailsId = this.obj.MovieDetailsId;
    console.log(this.obj.ScreeningId);
  }

  postprofile() {
    this.bo.Comments = this.comment;
    console.log(this.comment)
    this.ser.postmethod(this.bo).subscribe(); {
    }
  }
  redirect1(){
    this.router.navigate(['/pay']);
  }
   redirect(){
    this.router.navigate(['/home']);
  }
  ngOnInit() {
    this.bank = this.ser1.bank;
    this.bo.BankName = this.bank;
    this.type = this.ser1.type;
    console.log(this.type);
    this.bo.PaymentType = this.type;
  }
  ngOnDestroy() {
  }

}
