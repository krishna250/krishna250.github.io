import { Component, OnInit } from '@angular/core';
import {DataService} from '../data.service';
import  { Router } from '@angular/router';
@Component({
  selector: 'app-payment-page',
  templateUrl: './payment-page.component.html',
  styleUrls: ['./payment-page.component.css']
})
export class PaymentPageComponent implements OnInit {
  static   a: string = "<app-debit-card></app-debit-card>" ;
banktype:string;
val2:string;
  constructor(private router: Router,private ser:DataService) { }

  ngOnInit() {
  }
  abc (): void 
  {
   
 PaymentPageComponent. a  = "<app-bankoptions></app-bankoptions>";
  
  }
  direct() :void{
this.banktype="Debit Card/Credit Card";
  localStorage.setItem('val1',JSON.stringify(this.banktype));
 var val1=JSON.parse(localStorage.getItem('val1'));
    console.log(val1);
this.val2=val1;
this.router.navigate(['/debitcard']);

  }
    redirect() :void{
this.banktype="Net-Banking";
  localStorage.setItem('val1',JSON.stringify(this.banktype));
 var val1=JSON.parse(localStorage.getItem('val1'));
    console.log(val1);
this.val2=val1;
this.router.navigate(['/option']);

  }
 ngOnDestroy(){
    this.ser.type=this.val2;
   // console.log(this.val2);
  }

}
