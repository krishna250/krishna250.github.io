import { Component, OnInit } from '@angular/core';
import { PlayService } from "./play.service";
import{InfoShow} from "./play";
import  { Router } from '@angular/router';

@Component({
  selector: 'app-play-edit',
  templateUrl: './play-edit.component.html',
  styleUrls: ['./play-edit.component.css'],
  providers:[PlayService]
})
export class PlayEditComponent implements OnInit {
 play : any [] =[];
 public Id:InfoShow;
 abc:any;
 
  constructor(private show:PlayService,private router:Router) {
    this.Id=new InfoShow();

   }

  ngOnInit() {
    this.show.getPlayInfo().subscribe(data=>{
    console.log(data);
this.play=data });
  }

  
playDelete(MovieId:number,PlayId:number)
{
  this.Id.movieId= MovieId;
  this.Id.PlayId=PlayId;

  this.show.deletePlayInfo(this.Id).subscribe(data=>{
    console.log(data);
this.abc=data }); 
  alert("Deleted successfully");
   this.router.navigate(['/Admin']);
}
redirect(id:number) : void {
     console.log("Qwe");    
this.router.navigate(['/Admin/Play/Update',id]);
} 
  direct(){
this.router.navigate(['/Admin']);
} 

 

}

