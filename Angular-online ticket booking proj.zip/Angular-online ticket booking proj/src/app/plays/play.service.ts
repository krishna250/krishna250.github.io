import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response} from '@angular/http';
import { Observable } from 'rxjs';

import 'rxjs/add/operator/map';

@Injectable()
export class PlayService {

  Url:string;
  constructor(private http: HttpClient) 
  { 
    this.Url = "https://ticketshereapidotnetnov2017.azurewebsites.net/api/PlaySearch";
  }
  
  getPlayInfos(name:string ):Observable<any> {
const url = `${this.Url}/${name}`;
return this.http.get(url);
  }


getAllPlays( ):Observable<any> {
const url = `${this.Url}`;
return this.http.get(url);

} 
}



