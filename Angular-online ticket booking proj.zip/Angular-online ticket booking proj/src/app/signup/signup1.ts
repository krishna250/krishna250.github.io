export class signup1
{
    public  CustomerName:string;
public PhoneNumber:string;

public EmailId:string;
public Password:number
   
  
//public City:string;
// constructor(Name,Mobile_Number,Email,password){
//     this.Name=this.Name;
//     this.Email=this.Email;
//     this.password=this.password;
//     this.Mobile_Number=this.Mobile_Number;

// }
}