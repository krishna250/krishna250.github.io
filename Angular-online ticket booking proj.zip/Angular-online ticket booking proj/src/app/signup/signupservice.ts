import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import{Response} from '@angular/http';
import {Observable} from 'rxjs';
import {signup1} from './signup1';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';


@Injectable()
export class SignupService {
  play:signup1[]=[];

  constructor(private http: HttpClient) { }



private Url = 'https://ticketshereapidotnetnov2017.azurewebsites.net/api/Registration';

//private Url='http://localhost:52654/api/CustomerRegistration';
//private Url1='http://localhost:52654/api/CustomerRegistration';


 getPlayInfo(str:signup1):Observable <any> {
 const url = `${this.Url}`;
 return this.http.post(url,str)


 //console.log(str);
//  .map(this.extractData)
            // .catch(this. handleErrorObservable);
            }
            
}
// }
//   private extractData(res:Response) {
//         let body = res.json();
//         return body || [];
//     }   
  //    private handleErrorObservable (error: Response | any) {
	// console.error(error.message || error);
	// return Observable.throw(error.message || error);
  //   }


