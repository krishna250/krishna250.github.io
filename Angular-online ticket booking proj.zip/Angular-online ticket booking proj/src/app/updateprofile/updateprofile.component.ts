import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { updateprofilevar } from './updateprofilevar';
import { UpdateprofileService } from './updateprofileservice';
declare const $;
import { LocalUserService, LocalUserObject } from '../LocalUserService.service';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {

  hide = true;
  id = LoginComponent.abc;


  play: updateprofilevar[] = [];
  register: updateprofilevar


  selected: string[] = [];
  public obj: LocalUserObject;
  newcontact: updateprofilevar;
  Localobj: LocalUserObject;

  constructor(private LocalService: LocalUserService, private ser: UpdateprofileService, private router: Router) { }

  myForm = new FormGroup(
    {
      name_on_the_card: new FormControl('', [Validators.required,Validators.pattern('[a-zA-Z][a-zA-Z ]+')]),
      mobile_number: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[6-9][0-9]{9}$')]),
      email: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9._%+-]+@[a-z0-9.-]+[.][a-z]{2,3}$')]),
      password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(15)])
    }
  )

  get name_on_the_card() {
    return this.myForm.get('name_on_the_card');
  }
  get mobile_number() {
    return this.myForm.get('mobile_number');
  }
  get email() {
    return this.myForm.get('email');
  }
  get password() {
    return this.myForm.get('password');
  }

  ngOnInit() {
  }

  getinfo() {
console.log('In info');
    if (this.myForm.valid) {

      let profile = new updateprofilevar();
      profile.CustomerId = this.id;
        //alert(this.id);
      profile.CustomerName = this.name_on_the_card.value;
          profile.PhoneNumber = this.mobile_number.value;
      profile.EmailId = this.email.value;
      profile.Password = this.password.value;
  

      console.log(profile);

      this.ser.getPlayInfo(profile).subscribe((data) => {
        console.log(data);
      });

      alert('Your profile has been updated successfully')

      this.router.navigate(['/booking-history']);
    }
    else {
      //  $(document).ready(function(){
      //     $(".loccat").click(function(){
      //       alert("hi")
      //         $("#myModal").show();
      //     });

      // });


      alert("Please provide the valid inputs");
      //}
    }
    //console.log(SignupComponent.abc);

    // this.abc ="modal";
  }

  getErrorMessage() {
    return this.email.hasError('required') ? 'Please enter a valid email id' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }
  getErrorMessage2() {
    return this.mobile_number.hasError('required') ? 'Please enter a valid mobile number' :
      this.mobile_number.hasError('mobile_number') ? 'Not a valid mobile number' :
        '';
  }
  getErrorMessage1() {
    return this.name_on_the_card.hasError('required') ? 'Please enter a valid name' :
      this.name_on_the_card.hasError('name_on_the_card') ? 'Not a valid Name' :
        '';
  }










  // addPost(Name, Mobile_Number, city, password, Email) {

  //   //  this.Name=post.Name;
  //   //  this.Mobile_Number=post.mobile_number;
  //   //  this.Email=post.Email;
  //   //  this.Password=post.Password;
  //   //  this.city=post.city;
  // }

}
