import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {updateprofilevar} from './updateprofilevar';

@Injectable()
export class UpdateprofileService {
  play:updateprofilevar[]=[];

  constructor(private http: HttpClient) { }



//private Url = 'https://ticketshereapidotnetnov2017.azurewebsites.net/api/MyProfileUpdateController';
//private Url = "http://localhost:52654/api/MovieSearch";

//     private Url = "http://localhost:52654/api/MyProfileUpdate";


//  getPlayInfo(str:updateprofilevar):Observable <any> {
//  const url = `${this.Url}`;
//  console.log(str);
//  return this.http.post(url,str);
// // //.catch(this.handleError);
// // }
// // getPlayInfos(id:number ):Observable <any> {
// // const url = `${this.Url}/${id}`;
// // return this.http.post(url)
// // //.catch(this.handleError);
//   }
     //private Url ='http://localhost:52654/api/MyProfileUpdate';
      private Url ='https://ticketshereapidotnetnov2017.azurewebsites.net/api/MyProfileUpdate';
 
getPlayInfo(str:updateprofilevar):Observable <any> {
    
 ////const url:string = `${this.Url}/${str}`;
// console.log(url);
console.log(this.Url);
//let options = new RequestOptions({ headers: this.headers });
return this.http.put(this.Url,str);//, { headers: this.headers });
//.catch(this.handleError);
}
}