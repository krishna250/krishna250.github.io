import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ProductModule} from './book/book.module'
import {PreloadAllModules} from '@angular/router'; //for preloadings
import { WelcomeComponent } from './home/welcome.component';
import {AdminComponent} from './admin/admin.component'
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found.component';
import { AuthGuard } from './user/auth.guard';
import { SelectiveStrategy } from './selective-strategy.service';
import { UserProductListComponent } from './book/user-book-list.component';
import { ProductDetailComponent } from './book/book-detail.component';
import { ProductListComponent } from './book/book-list.component';
import { ProductAssignComponent } from './book/book-edit/book-assing.component';
import{ProductAssignViewComponent} from  './book/assinged-book.component';
import { BookComponent } from './book/book.component';

const routes: Routes = [];

@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: 'welcome', component: WelcomeComponent },
      { path: 'home', component: HomeComponent },
      { path: 'book', component: ProductListComponent},
      { path: 'admin', component: AdminComponent},
      { path: 'assign', component: BookComponent},
   
     {
       path: 'products',
      canActivate: [ AuthGuard ],
       //canload: [ AuthGuard ], //for lazy load or use pre load
    data: { preload: false }, //for preloading make preload true
        loadChildren: './book/book.module#ProductModule'//lazy loding adding product module here instead of app.module.ts
        //loadChildren: () => ProductModule,
      },
  
     
   
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: '**', component: PageNotFoundComponent }
    //], { enableTracing: true, preloadingStrategy: preloadAllModules }) canload: [ AuthGuard ], for lazy load or use pre load
   ], { enableTracing: true, preloadingStrategy: SelectiveStrategy }) //  canload: [ AuthGuard ], for customer preloading
  
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
