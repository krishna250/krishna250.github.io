import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import bootstrap from "bootstrap";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { LocalUserService } from "./book/localstorage.service";
import {MatMenuModule} from '@angular/material/menu'; 
//{MatMenuModule} from '@angular/material/menu'; 
import{MatButtonModule,MatInputModule} from '@angular/material'; 

// Imports for loading & configuring the in-memory web api
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { ProductData } from './book/book-data';
import { ProductData1 } from './book/book1-data';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { PageNotFoundComponent } from './page-not-found.component';
/* Feature Modules */
import { UserModule } from './user/user.module';
import { MessageComponent } from './messages/messages.component';
import { MessageModule } from './messages/message.module';
import { SharedComponent } from './shared/shared.component';
import { BookComponent } from './book/book.component';
import { ProductEditComponent } from './book/book-edit/book-edit.component';
import { ProductDetailComponent } from './book/book-detail.component';
import { ProductListComponent } from './book/book-list.component';
import { ProductModule } from './book/book.module';
import { HomeComponent } from './home/home.component';
import {AdminComponent} from './admin/admin.component'
import {MatSelectModule} from '@angular/material/select';
import { UserProductListComponent } from './book/user-book-list.component';
import { ProductAssignComponent } from './book/book-edit/book-assing.component';
import{ProductAssignViewComponent} from  './book/assinged-book.component';
 


@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    
    FormsModule,
    InMemoryWebApiModule.forRoot(ProductData, { delay: 1000 }), 
  //  InMemoryWebApiModule.forRoot(ProductData1, { delay: 1000 }), 
    UserModule,
    MessageModule,
    AppRoutingModule,
    
  ],
  declarations: [
    AppComponent,
    WelcomeComponent,
    PageNotFoundComponent,
    BookComponent,
    ProductListComponent,
    HomeComponent,AdminComponent,

   
  ],
  providers: [LocalUserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
