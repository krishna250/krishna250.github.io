import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MessageService } from './../messages/messages.service';
import { Product, ProductResolved } from './book';
import {ProductAssignComponent} from '../book/book-edit/book-assing.component'
import { ProductService } from './book.service';
@Component({
  templateUrl: './assigned-book.component.html',

})
export class ProductAssignViewComponent implements OnInit {
  pageTitle = 'Product Detail';
  product: Product;
  errorMessage: string;
  private id :number;
  private count =0;
  private dataIsValid: { [key: string]: boolean } = {};
  private currentProduct: Product;
  private originalProduct: Product;
  hideme=[]

  constructor(private route: ActivatedRoute,private productService: ProductService, private messageService: MessageService,) { }

  ngOnInit(): void {
    const resolvedData: ProductResolved =
      this.route.snapshot.data['resolvedData'];
    this.errorMessage = resolvedData.error;
    this.onProductRetrieved(resolvedData.product);
  }

  onProductRetrieved(product: Product): void {
    this.product = product;

    if (this.product) {
      this.pageTitle = `Product Detail: ${this.product.productName}`;
    } else {
      this.pageTitle = 'No product found';
    }
  }

  onClick(item) {
    Object.keys(this.hideme).forEach(h => {
      this.hideme[h] = false;
    });
    this.hideme[item.id] = true;
  }

  // get deleteProduct(): number {
  //   return this.id;
  //   console.log(this.id)
  //   console.log(this.deleteProduct)
  // }

  
 // set deleteProduct():number {
  //  this.id=this.id;
    // Clone the object to retain a copy
    
 
 
 // }

 deleteProduct(): void {
  if (this.product.id === 0) {
    // Don't delete, it was never saved.
    this.onSaveComplete(`${this.product.productName} was deleted`);
  } else {
    if (confirm(`Really want to return this book: ${this.product.productName}?`)) {
      this.productService.deleteProduct(this.product.id)
        .subscribe(
          () => this.onSaveComplete(`${this.product.productName} was returned`),
          (error: any) => this.errorMessage = <any>error
        );
    }
  }
}

onSaveComplete(message?: string): void {
  if (message) {
    this.messageService.addMessage(message);
  }
  this.reset(); // to not to get save yr changes after saving

  // Navigate back to the product list
  //this.router.navigate(['/products']);
}
reset(): void {
  this.dataIsValid = null;
  this.currentProduct = null;
  this.originalProduct = null;
}


}
