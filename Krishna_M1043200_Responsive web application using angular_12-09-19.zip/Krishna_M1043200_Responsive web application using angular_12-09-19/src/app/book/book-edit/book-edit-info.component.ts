import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { ProductService } from '../book.service';
import { Product } from '../book';
import { Router } from '@angular/router';
@Component({
  templateUrl: './book-edit-info.component.html',
  styleUrls: ['./book-edit-inf.component.css']
})
export class ProductEditInfoComponent implements OnInit {
  @ViewChild(NgForm) productForm: NgForm;

  errorMessage: string;
  product: Product;
  info1={ 
    id: '',
    productName: '',
    productCode: '',
    category: '',
    releaseDate: '',
    price: '',
    description: '',
    starRating: 0,
    imageUrl: ''
    
  };
  constructor(private route: ActivatedRoute,public ser:ProductService,public router:Router) { }

  ngOnInit(): void {
    this.route.parent.data.subscribe(data => {
      if (this.productForm) {
        this.productForm.reset();
      }

      this.product = data['resolvedData'].product;
    });
  }

  getbook(event:any){
    console.log(event.target.value);
  this.info1.productName=event.target.value;
  console.log(this.info1.productName);
  
    }
     getGenere (event:any){
  this.info1.category=event.target.value;
  
    }
  
         getRating(event:any){
  this.info1.starRating =event.target.value;
  console.log (this.info1.starRating);
  
    }
     getdate(event:any){
  this.info1.releaseDate =event.target.value;
  
    }
    getImageUrl(event:any){
  this.info1.imageUrl =event.target.value;
  
    }
     getproductcode(event:any){
  this.info1.productCode =event.target.value;
  //console.log(this.info.Language );
    }
    getvideo(event:any){
  this.info1.id =event.target.value;
  console.log(this.info1.id)
    }
    getDesc(event:any)
    {   
  this.info1.description=event.target.value;
    }

  getPRICE(event:any){
  this.info1.price=event.target.value;
  console.log(this.info1.price)
    }
    Savesubmit():void 
    {
    //  if  (this.info1.category!="" && this.info1.description!="" && this.info1.starRating !=0 && this.info1.id!="" &&this.info1.productName != "" &&this.info1.price!=""&&  this.info1.releaseDate!="")
    //  {
    this.ser.AddMovieInfo(this.info1).subscribe();
     alert("Added Sucessfully !!");
     this.router.navigate(['/products']);
    //}
    // else 
     //{
      //     alert("Missed Some Field !!")
     //}
    
    }

}
