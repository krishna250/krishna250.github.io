import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { MessageService } from '../../messages/messages.service';

import { Product, ProductResolved } from '../book';
import { ProductService } from '../book.service';

@Component({
  templateUrl: './book-edit.component.html',
  styleUrls: ['./book-edit.component.css']
})
export class ProductEditComponent implements OnInit {
  pageTitle = 'book Edit';
  errorMessage: string;

  info1={ 
    id: '',
    productName: '',
    productCode: '',
    category: '',
    releaseDate: '',
    price: '',
    description: '',
    starRating: 0,
    imageUrl: ''
    
  };

  private currentProduct: Product;
  private originalProduct: Product;

  private dataIsValid: { [key: string]: boolean } = {};

  get isDirty(): boolean {
    return JSON.stringify(this.originalProduct) !== JSON.stringify(this.currentProduct);
  }

 

  get product(): Product {
    return this.currentProduct;
  }
  set product(value: Product) {
    this.currentProduct = value;
    // Clone the object to retain a copy
    this.originalProduct = value ? { ...value } : null;
  }

  constructor(private productService: ProductService,
              private messageService: MessageService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.route.data.subscribe(data => {
      const resolvedData: ProductResolved = data['resolvedData'];
      this.errorMessage = resolvedData.error;
      this.onProductRetrieved(resolvedData.product);
    });
  }

  onProductRetrieved(product: Product): void {
    this.product = product;

    if (!this.product) {
      this.pageTitle = 'No product found';
    } else {
      if (this.product.id === 0) {
        this.pageTitle = 'Add Product';
      } else {
        this.pageTitle = `Edit Product: ${this.product.productName}`;
      }
    }
  }

  deleteProduct(): void {
    if (this.product.id === 0) {
      // Don't delete, it was never saved.
      this.onSaveComplete(`${this.product.productName} was deleted`);
    } else {
      if (confirm(`Really delete the book: ${this.product.productName}?`)) {
        this.productService.deleteProduct(this.product.id)
          .subscribe(
            () => this.onSaveComplete(`${this.product.productName} was deleted`),
            (error: any) => this.errorMessage = <any>error
          );
      }
    }
  }

  isValid(path?: string): boolean {
    this.validate();
    if (path) {
      return this.dataIsValid[path];
    }
    return (this.dataIsValid &&
      Object.keys(this.dataIsValid).every(d => this.dataIsValid[d] === true));
  }

  reset(): void {
    this.dataIsValid = null;
    this.currentProduct = null;
    this.originalProduct = null;
  }
// to not to get save yr changes after saving
  saveProduct(): void {
    if (this.isValid()) {
      if (this.product.id === 0) {
        console.log(this.product)
        this.productService.createProduct(this.product)
          .subscribe(
            () => this.onSaveComplete(`The new ${this.product.productName} was saved`),
            (error: any) => this.errorMessage = <any>error
          );
      } else {
        this.productService.updateProduct(this.product)
          .subscribe(
            () => this.onSaveComplete(`The updated ${this.product.productName} was saved`),
            (error: any) => this.errorMessage = <any>error
          );
      }
    } else {
      this.errorMessage = 'Please correct the validation errors.';
    }
  }

  onSaveComplete(message?: string): void {
    if (message) {
      this.messageService.addMessage(message);
    }
    this.reset(); // to not to get save yr changes after saving

    // Navigate back to the product list
    this.router.navigate(['/book']);
  }
  
  Savesubmit():void 
  {
  //  if  (this.info1.category!="" && this.info1.description!="" && this.info1.starRating !=0 && this.info1.id!="" &&this.info1.productName != "" &&this.info1.price!=""&&  this.info1.releaseDate!="")
  //  {
  this.productService.AddMovieInfo(this.info1).subscribe();
   alert("Added Sucessfully !!");
 
  //}
  // else 
   //{
    //     alert("Missed Some Field !!")
   //}
  
  }

  getbook(event:any){
    console.log(event.target.value);
  this.info1.productName=event.target.value;
  console.log(this.info1.productName);
  
    }
     getGenere (event:any){
  this.info1.category=event.target.value;
  
    }
  
         getRating(event:any){
  this.info1.starRating =event.target.value;
  console.log (this.info1.starRating);
  
    }
     getTime(event:any){
  this.info1.releaseDate =event.target.value;
  
    }
    getImageUrl(event:any){
  this.info1.imageUrl =event.target.value;
  
    }
     getproductcode(event:any){
  this.info1.productCode =event.target.value;
  //console.log(this.info.Language );
    }
    getvideo(event:any){
  this.info1.id =event.target.value;
  console.log(this.info1.id)
    }
    getDesc(event:any)
    {   
  this.info1.description=event.target.value;
    }

  getPRICE(event:any){
  this.info1.price=event.target.value;
  console.log(this.info1.price)
    }
  

  validate(): void {
    // Clear the validation object
    this.dataIsValid = {};

    // 'info' tab
    if (this.product.productName &&
      this.product.productName.length >= 3 &&
      this.product.productCode || this.product.price ) {
      this.dataIsValid['info'] = true;
    } else {
      this.dataIsValid['info'] = false;
    }

    // 'tags' tab
    if (this.product.category &&
      this.product.category.length >= 3) {
      this.dataIsValid['tags'] = true;
    } else {
      this.dataIsValid['tags'] = false;
    }
  }

}
