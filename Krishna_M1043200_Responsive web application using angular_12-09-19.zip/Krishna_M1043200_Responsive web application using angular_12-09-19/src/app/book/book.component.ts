import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,Router} from '@angular/router';
import {ProductAssignComponent} from '../book/book-edit/book-assing.component'
import { Product, ProductResolved } from './book';
import { LocalUserService, LocalUserObject } from './localstorage.service';
@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.scss']
})
export class BookComponent implements OnInit {
  pageTitle = 'Product Detail';
  product: Product;
  errorMessage: string;
  showImage = true;


 private id1:number;
 public MovieObj:LocalUserObject;
  produ:ProductAssignComponent;
  constructor(private route: ActivatedRoute, local: LocalUserService,private LocalService: LocalUserService,
             
    private router: Router) { 
      this.MovieObj= this.LocalService.getLocalUserObject()
    }
  

ngOnInit(){}
 
   Added(): void {
   // return this.id;
    console.log(this.MovieObj.id);
    //console.log(this.deleteProduct)
    //this.id=this.produ.pass;
    console.log(this.MovieObj.id);
this.id1=this.MovieObj.id;
    //if (this.MovieObj.id !=0){
    //this.router.navigate(['/products/${id1}/assignview']);
   // }
    //else
    //alert (this.id1);
  }
  toggleImage(): void {
    this.showImage = !this.showImage;
  }

 // this.id=this.produ.deleteProduct;
}

