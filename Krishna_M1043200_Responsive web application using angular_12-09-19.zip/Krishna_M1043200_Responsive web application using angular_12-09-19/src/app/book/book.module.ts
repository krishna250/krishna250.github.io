import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { ProductAssignComponent } from './book-edit/book-assing.component';

import { ProductDetailComponent } from './book-detail.component';
import { ProductEditComponent } from './book-edit/book-edit.component';
import { ProductEditInfoComponent } from './book-edit/book-edit-info.component';
import { ProductEditTagsComponent } from './book-edit/book-edit-tag.component';
import{ProductAssignViewComponent} from  '../book/assinged-book.component';

import { ProductResolver } from './book-resolver.service';
import { ProductEditGuard } from './book-edit/book-edit.guard';

import { SharedModule } from '../shared/shared.module';

import {UserProductListComponent} from './user-book-list.component'

@NgModule({
  imports: [
    SharedModule,
  
    RouterModule.forChild([

      {
        path: '',
        component: UserProductListComponent,
    
      },

   
      {
        path: ':id',
        component: ProductDetailComponent,
        resolve: { resolvedData: ProductResolver }
      },

      {
        path: ':id/assign',
        component: ProductAssignComponent,
        canDeactivate: [ProductEditGuard],
        resolve: { resolvedData: ProductResolver },
        children: [
          { path: '', redirectTo: 'info', pathMatch: 'full' },
          { path: 'info', component: ProductEditInfoComponent },
          { path: 'tags', component: ProductEditTagsComponent }
        ]
      },

      {
        path: ':id/assignview',
        component: ProductAssignViewComponent,
        canDeactivate: [ProductEditGuard],
        resolve: { resolvedData: ProductResolver },
        children: [
          { path: '', redirectTo: 'info', pathMatch: 'full' },
          { path: 'info', component: ProductEditInfoComponent },
          { path: 'tags', component: ProductEditTagsComponent }
        ]
      },

      {
        path: ':id/edit',
        component: ProductEditComponent,
        canDeactivate: [ProductEditGuard],
        resolve: { resolvedData: ProductResolver },
        children: [
          { path: '', redirectTo: 'info', pathMatch: 'full' },
          { path: 'info', component: ProductEditInfoComponent },
          { path: 'tags', component: ProductEditTagsComponent }
        ]
      }
    ])
  ],
  declarations: [
    UserProductListComponent,
    ProductDetailComponent,
    ProductEditComponent,
    ProductEditInfoComponent,
    ProductEditTagsComponent, 
    ProductAssignComponent,
    ProductAssignViewComponent
  ]
})
export class ProductModule { }
