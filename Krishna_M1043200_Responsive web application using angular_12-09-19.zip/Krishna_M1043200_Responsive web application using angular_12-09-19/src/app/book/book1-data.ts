import { InMemoryDbService } from 'angular-in-memory-web-api';

import { Product1 } from './book1';

export class ProductData1 implements InMemoryDbService {

  createDb() {
    const products1: Product1[] = [
  
    {
      'id': 2,
      'productName': 'DAN BROWN',
      'productCode': 'GDN-0023',
      'releaseDate': 'March 18, 2018',
      'description': '15 gallon capacity rolling garden cart',
      'price': 32.99,
      'starRating': 4.2,
      'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/51Zutc5AWcL._SX319_BO1,204,203,200_.jpg',
      'category': 'Garden'
    },
    {
      'id': 5,
      'productName': 'Percy Jackson',
      'productCode': 'TBX-0048',
      'releaseDate': 'May 21, 2018',
      'description': 'Curved claw steel hammer',
      'price': 8.9,
      'starRating': 4.8,
      'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/51YZ1YekEqL._SX324_BO1,204,203,200_.jpg',
      'category': 'Toolbox',
      'tags': ['tools', 'hammer', 'construction']
    },
    {
      'id': 8,
      'productName': 'Homo Dues',
      'productCode': 'TBX-0022',
      'releaseDate': 'May 15, 2018',
      'description': '15-inch steel blade hand saw',
      'price': 11.55,
      'starRating': 3.7,
      'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/41x9l0H2UGL._SX324_BO1,204,203,200_.jpg',
      'category': 'Toolbox'
    },
    {
      'id': 10,
      'productName': 'Cracking the Coding Interview',
      'productCode': 'GMG-0042',
      'releaseDate': 'October 15, 2018',
      'description': 'Standard two-button video game controller',
      'price': 35.95,
      'starRating': 4.6,
      'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/51l5XzLln%2BL._SX348_BO1,204,203,200_.jpg',
      'category': 'Gaming'
    },

    {
      'id': 3,
      'productName': 'Data structure',
      'productCode': 'GDN-0011',
      'releaseDate': 'March 19, 2018',
      'description': 'Leaf rake with 48-inch wooden handle',
      'price': 19.95,
      'starRating': 3.2,
      'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/41gdI5uQ%2BHL._SX385_BO1,204,203,200_.jpg',
      'category': 'Garden',
      'tags': ['rake', 'leaf', 'yard', 'home']
    },
    {
      'id': 4,
      'productName': 'Electrical technology',
      'productCode': 'GDN-0023',
      'releaseDate': 'March 18, 2018',
      'description': '15 gallon capacity rolling garden cart',
      'price': 32.99,
      'starRating': 4.2,
      'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/51FgCANr74L._SX352_BO1,204,203,200_.jpg',
      'category': 'Garden'
    },
      {
        'id': 15,
        'productName': 'Fluid Mechanics ',
        'productCode': 'GDN-0023',
        'releaseDate': 'March 18, 2018',
        'description': '15 gallon capacity rolling garden cart',
        'price': 32.99,
        'starRating': 4.2,
        'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/511V5YzvY1L._SX389_BO1,204,203,200_.jpg',
        'category': 'Garden'
      },
      {
        'id': 16,
        'productName': 'Engineering Mechanics',
        'productCode': 'TBX-0048',
        'releaseDate': 'May 21, 2018',
        'description': 'Curved claw steel hammer',
        'price': 8.9,
        'starRating': 4.8,
        'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/411l7dNaW-L._SX294_BO1,204,203,200_.jpg',
        'category': 'Toolbox',
        'tags': ['tools', 'hammer', 'construction']
      },
      {
        'id': 17,
        'productName': 'Java',
        'productCode': 'TBX-0022',
        'releaseDate': 'May 15, 2018',
        'description': '15-inch steel blade hand saw',
        'price': 11.55,
        'starRating': 3.7,
        'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/51k5NgL%2BB%2BL._SX398_BO1,204,203,200_.jpg',
        'category': 'Toolbox'
      },
      {
        'id': 18,
        'productName': 'English Conversation Practice',
        'productCode': 'GMG-0042',
        'releaseDate': 'October 15, 2018',
        'description': 'Standard two-button video game controller',
        'price': 35.95,
        'starRating': 4.6,
        'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/41BWpmfxNrL._SX321_BO1,204,203,200_.jpg',
        'category': 'Gaming'
      },
      {
        'id': 19,
        'productName': '7 Prices for 7 Vice',
        'productCode': 'GDN-0011',
        'releaseDate': 'March 19, 2018',
        'description': 'Leaf rake with 48-inch wooden handle',
        'price': 19.95,
        'starRating': 3.2,
        'imageUrl': 'https://images-na.ssl-images-amazon.com/images/I/41gawPS526L._SX311_BO1,204,203,200_.jpg',
        'category': 'Garden',
        'tags': ['rake', 'leaf', 'yard', 'home']
      },
      
     
    ];
    return { products1 };
  }
  Product: { 
      id: '',
      productName: '',
      productCode: '',
      category: '',
      
      releaseDate: '',
      price: '',
      description: '',
      starRating: 0,
      imageUrl: ''
      
    };
 
}
