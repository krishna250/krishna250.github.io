/* Defines the product entity */
export interface Product1 {
    id: number;
    productName: string;
    productCode: string;
    category: string;
    tags?: string[];
    releaseDate: string;
    price: number;
    description: string;
    starRating: number;
    imageUrl: string;
  }
  
  export interface ProductResolved {
    product: Product1;
    error?: any;
  }
  