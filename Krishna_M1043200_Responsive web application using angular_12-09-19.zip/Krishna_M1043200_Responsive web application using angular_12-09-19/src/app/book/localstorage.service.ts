import { Injectable } from '@angular/core';

// Import Observable Dependencies
import { Observable } from 'rxjs';

export interface LocalUserObject {
    id: number;
    // productName: string;
    // productCode: string;
    // category: string;
    // tags?: string[];
    // releaseDate: string;
    // price: number;
    // description: string;
    // starRating: number;
    // imageUrl: string;
}

@Injectable()
export class LocalUserService {

    constructor() { 

    }

    // Get Local User Object from Local Storage
    getLocalUserObject(): LocalUserObject {
        return JSON.parse(localStorage.getItem('KEY_MOVIEID') || null);
    }

    // Set Local User Object using the given value.
    setLocalUserObject(localUserObject: LocalUserObject) {
    
        localStorage.setItem('KEY_MOVIEID', JSON.stringify(localUserObject));
    }
}