import { Component } from '@angular/core';

@Component({
  templateUrl: './welcome.component.html',
 styleUrls: ['./welcome.component.scss'],
 

})
export class WelcomeComponent {
  public pagetitle = 'Welcome';
}