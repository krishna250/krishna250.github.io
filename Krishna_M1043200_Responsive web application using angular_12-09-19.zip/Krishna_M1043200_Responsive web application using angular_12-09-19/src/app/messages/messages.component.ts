import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { MessageService } from './messages.service';
import { AuthService } from '../user/auth.service';
@Component({
  templateUrl: './messages.component.html',
  styles: [
    '.message-row { margin-bottom: 10px }'
  ]
})
export class MessageComponent {
  get messages() {
    return this.messageService.messages;
  }
  get isAdmin() {
    return this.authService.currentUser ;
}

  constructor(private messageService: MessageService,private authService:AuthService,
              private router: Router) { }

  close(): void {
    // Close the popup.
    this.router.navigate([{ outlets: { popup: null } }]);
    this.messageService.isDisplayed = false;
  }
}
