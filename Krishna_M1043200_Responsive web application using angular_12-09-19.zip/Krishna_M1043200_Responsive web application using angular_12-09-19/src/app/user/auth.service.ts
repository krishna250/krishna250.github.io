import { Injectable } from '@angular/core';
import  { Router } from '@angular/router';
import { User1 } from './user';
import { Role } from './role';
import { MessageService } from '../messages/messages.service';
import { RouterLink } from '@angular/router/src/directives/router_link';
import { notEqual } from 'assert';



@Injectable({
  providedIn: 'root'
})
export class AuthService {
  currentUser: User1;
  password:string;
  redirectUrl: string;
  //user: User;

  

  get isLoggedIn(): boolean {
    return !!this.currentUser;
  }
get isAdmin():string
{
  if(this.currentUser.userName === 'admin')
{
  return;
}
}

get isuser():string
{
  if(this.currentUser.userName === 'krishna' || this.currentUser.userName === 'admin' &&  this.currentUser.password==='Avis')
{
  return;
}
}
  constructor(private messageService: MessageService,private router:Router) {
    // this.afAuth.authState.subscribe(user => {
    //   if (user) {
    //     this.user = user;
    //     localStorage.setItem('user', JSON.stringify(this.user));
    //   } else {
    //     localStorage.setItem('user', null);
    //   }
    // })
   }
  //  async  login(email:  string, password:  string) {

  //   try {
  //       await  this.afAuth.auth.signInWithEmailAndPassword(email, password)
  //       this.router.navigate(['admin/list']);
  //   } catch (e) {
  //       alert("Error!"  +  e.message);
  //   }
  //   }
  login(userName: string, password: string): void {
    if (userName ==='admin' && password ==='Avis'|| userName==='minds@mindtree.com'&& password==='Avis')
   {

      
    if (userName === 'admin' && password==='Avis') {
      this.currentUser = {
        id: 1,
        userName: userName,
        password:password,
        isAdmin: true,
       // role:

      };
    
      this.messageService.addMessage('Admin login');
      return;
     
     
    }
    
    this.currentUser = {
      id: 2,
      userName: userName,
      password:password,
      isAdmin: false
    };
    this.messageService.addMessage(`User: ${this.currentUser.userName} logged in`);
  }
    else {
    alert('Please enter valid userName and password');
      return;
    
    }
  }


//   async logout(){
//     await this.afAuth.auth.signOut();
//     localStorage.removeItem('user');
//     this.router.navigate(['admin/login']);
// }

  logout(): void {
    this.currentUser = null;
  }
}
