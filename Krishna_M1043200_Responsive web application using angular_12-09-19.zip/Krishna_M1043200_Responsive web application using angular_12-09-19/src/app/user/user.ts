export interface User1 {
    id: number;
    userName: string;
    isAdmin: boolean;
   password:string;
  // role:string;

  }
  