﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.BAL.Admin;

namespace TicketsHereDotnet.BAL.Admin
{
    public class AdminDelete
    {
        public int SoftDelete(AdminModelMapper amm)
        {
            Movies mov = new Movies();
            Entity.Model.Play p = new Entity.Model.Play();
            try
            {
                using (GenericUnitOfWork gen = new GenericUnitOfWork())
                {
                    try
                    {
                        if(amm.MovieId > 0)
                        {
                            IRepository<Movies> MovieRepo = new Repository<Movies>(gen.Context);
                            mov = MovieRepo.Query(dele => dele.MovieId == amm.MovieId).FirstOrDefault();
                            mov.IsDeleted = true;

                            gen.BeginTransaction();
                            gen.repositories.Add(mov.GetType(), MovieRepo);
                            MovieRepo.Edit(mov);
                        }
                        if (amm.PlayId > 0)
                        {
                            IRepository<Entity.Model.Play> PlayRepo = new Repository<Entity.Model.Play>(gen.Context);
                            p = PlayRepo.Query(dele => dele.PlayId == amm.PlayId).FirstOrDefault();
                            p.Isdeleted = true;

                            gen.BeginTransaction();
                            gen.repositories.Add(p.GetType(), PlayRepo);
                            PlayRepo.Edit(p);
                        }
                        gen.SaveChanges();
                        return 1;
                    }
                    catch (Exception)
                    {
                        gen.Rollback();
                        return 0;
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
