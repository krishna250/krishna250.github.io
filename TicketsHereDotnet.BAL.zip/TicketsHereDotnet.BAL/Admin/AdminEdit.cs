﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.Admin
{
    public class AdminEdit
    {
        public int EditMoviePlay(EditMoviePlayMapper amm)
        {
            Movies mov = new Movies();
            Entity.Model.Play p = new Entity.Model.Play();
            try
            {
                using (GenericUnitOfWork gen = new GenericUnitOfWork())
                {
                    try
                    {
                        if (amm.MovieId > 0)
                        {
                            IRepository<Movies> MovieRepo = new Repository<Movies>(gen.Context);
                            mov = MovieRepo.Query(dele => dele.MovieId == amm.MovieId).FirstOrDefault();

                            mov.ReleaseDate = amm.ReleaseDate;
                            mov.Description = amm.Description;
                            mov.Video = amm.VideoUrl;
                            mov.Language = amm.Language;
                            mov.Image = amm.Poster;
                            mov.Duration = amm.TimeDuration;
                            mov.Name = amm.Name;
                            mov.Rating = amm.Rating;
                            mov.ModifiedDate = amm.ModifiedDate;
                            mov.IsDeleted = false;
                            mov.UpdatedBy = amm.UpdatedBy;
                            mov.Genre = amm.Genre;

                            gen.BeginTransaction();
                            gen.repositories.Add(mov.GetType(), MovieRepo);
                            MovieRepo.Edit(mov);
                        }
                        if (amm.PlayId > 0)
                        {
                            IRepository<Entity.Model.Play> PlayRepo = new Repository<Entity.Model.Play>(gen.Context);
                            p = PlayRepo.Query(dele => dele.PlayId == amm.PlayId).FirstOrDefault();

                            p.PlayName = amm.PlayName;
                            p.Description = amm.Description;
                            p.Language = amm.Language;
                            p.TimeDuration = amm.TimeDuration;
                            p.Poster = amm.Poster;
                            p.VideoUrl = amm.VideoUrl;
                            p.Price = amm.Price;
                            p.ModifiedDate = amm.ModifiedDate;
                            p.CityId = amm.CityId;
                            p.UserPhoneno = amm.UserPhoneno;
                            p.Rating = amm.Rating;
                            p.StartDate = amm.StartDate;
                            p.EndDate = amm.EndDate;
                            p.Genre = amm.Genre;
                            p.Isdeleted = false;

                            gen.BeginTransaction();
                            gen.repositories.Add(p.GetType(), PlayRepo);
                            PlayRepo.Edit(p);
                        }
                        gen.SaveChanges();
                        return 1;
                    }
                    catch (Exception)
                    {
                        gen.Rollback();
                        return 0;
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
