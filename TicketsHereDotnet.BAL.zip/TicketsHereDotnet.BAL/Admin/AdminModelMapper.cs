﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.BAL.Admin
{
    public class AdminModelMapper
    {
        public int MovieId { get; set;}
        public int PlayId { get; set;}
    }
}
