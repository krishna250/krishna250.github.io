﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;

namespace TicketsHereDotnet.BAL.Admin
{
    public class CreateMoviesBAL
    {
        public void BusinessPost(TicketsHereDotnet.BAL.Admin.CMovies cm)
        {
            try
            {
                Entity.Model.Movies mv = new Entity.Model.Movies();
                mv.MovieId = cm.MovieId;
                mv.ReleaseDate = cm.ReleaseDate;
                mv.Description = cm.Description;
                mv.Video = cm.Video;
                mv.Language = cm.Language;
                mv.Image = cm.Image;
                mv.Duration = cm.Duration;
                mv.Name = cm.Name;
                mv.Rating = cm.Rating;
                mv.ModifiedDate = cm.ModifiedDate;
                mv.IsDeleted = cm.IsDeleted;
                mv.UpdatedBy = cm.UpdatedBy;
                mv.Genre = cm.Genre;
                using (GenericUnitOfWork uoW = new GenericUnitOfWork())
                {
                    uoW.repositories.Add(mv.GetType(), new Repository<Entity.Model.Movies>(uoW.Context));
                    try
                    {
                        uoW.BeginTransaction();
                        ((Repository<TicketsHereDotnet.Entity.Model.Movies>)uoW.repositories[mv.GetType()]).Insert(mv);
                        uoW.SaveChanges();
                    }
                    catch (Exception)
                    {
                        uoW.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
