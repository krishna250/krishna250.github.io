﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.BAL.Admin
{
    public class EditMoviePlayMapper
    {
        public int PlayId { get; set; }
        public string PlayName { get; set; }
        public string Description { get; set; }
        public string Language { get; set; }
        public string TimeDuration { get; set; }
        public string Poster { get; set; }
        public string VideoUrl { get; set; }
        public decimal Price { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int CityId { get; set; }
        public long UserPhoneno { get; set; }
        public int Rating { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Genre { get; set; }

        public int MovieId { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string Name { get; set; }
        public long UpdatedBy { get; set; }
    }
}
