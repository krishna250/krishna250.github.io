﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.BookingHistory
{
    public class BookHistoryBAL
    {
        public List<BookingHistor> GetBookingHistory(int UserId)
        {
            BookingHistoryRepository<BookingHistor> booking = new BookingHistoryRepository<BookingHistor>(new TicketsHereModel());
            return booking.GetBookingHistoryDetails(UserId);
        }

    }
}

