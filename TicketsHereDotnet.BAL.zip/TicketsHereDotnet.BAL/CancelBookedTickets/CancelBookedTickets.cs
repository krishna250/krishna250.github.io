﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.BAL.Model;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.CancelBookedTickets
{
    public class CancelBookedTickets
    {
        public int DeleteDetails(CancelTicket cancel)
        {
            Reservation RemoveSeats = new Reservation();
            Transaction TransactionSeats = new Transaction();
            try
            {
                using (GenericUnitOfWork genric = new GenericUnitOfWork())
                {
                    try
                    {

                        string s = cancel.SeatBooked;
                        int output;
                        if (int.TryParse(s, out  output))
                        {
                            IRepository<Transaction> TransRepo = new Repository<Transaction>(genric.Context);
                            TransactionSeats = TransRepo.Query(delete => delete.TrasactionId == cancel.ReservationId).FirstOrDefault();
                            genric.BeginTransaction();
                            TransRepo.Delete(TransactionSeats);

                        }
                        else
                        {
                            
                            IRepository<Reservation> ReserveRepo = new Repository<Reservation>(genric.Context);
                            RemoveSeats = ReserveRepo.Query(delete => delete.ReservationId == cancel.ReservationId).FirstOrDefault();
                            genric.BeginTransaction();
                            ReserveRepo.Delete(RemoveSeats);
                        }
                        genric.SaveChanges();
                        return 1;
                    }
                    catch(Exception)
                    {
                        genric.Rollback();
                        return 0;
                        throw;
                    }
                }
            }
            catch(Exception)
            {
                return 0;
            }   
        }
    }
}
