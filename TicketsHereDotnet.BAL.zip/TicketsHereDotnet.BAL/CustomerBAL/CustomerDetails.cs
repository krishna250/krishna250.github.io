﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.BAL.Customer;


namespace TicketsHereDotnet.BAL.CustomerBAL
{
    public class CustomerRegistrationBAL
    {
      
         int count = 1;

        public int BusinessPost(TicketsHereDotnet.BAL.Customer.CustomerRegistration det)
        {

            try
            {
                Repository<TicketsHereDotnet.Entity.Model.CustomerRegistration> aa = new Repository<TicketsHereDotnet.Entity.Model.CustomerRegistration>(new TicketsHereModel());
                foreach (var item in aa.GetAll())
                {
                    if (item.PhoneNumber == det.PhoneNumber)
                    {
                        count = 0;
                        break;
                    }
                }
                if (count == 1)
                {
                    Entity.Model.CustomerRegistration cr = new Entity.Model.CustomerRegistration();
                    cr.CustomerName = det.CustomerName;
                    cr.PhoneNumber = det.PhoneNumber;

                    cr.EmailId = det.EmailId;
                    cr.Password = det.Password;
                    cr.IsAdmin = det.IsAdmin;


                    using (GenericUnitOfWork gn = new GenericUnitOfWork())
                    {
                        gn.repositories.Add(cr.GetType(), new Repository<Entity.Model.CustomerRegistration>(gn.Context));
                        try
                        {
                            gn.BeginTransaction();
                            ((Repository<TicketsHereDotnet.Entity.Model.CustomerRegistration>)gn.repositories[cr.GetType()]).Insert(cr);
                            gn.SaveChanges();
                            return 1;
                        }
                        catch (Exception)
                        {
                            gn.Rollback();
                            throw;

                        }
                    }


                }
                else
                {
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;

            }

        }
    }
}
