﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.BAL.Model;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.Login
{
    public class LoginDetails
    {
        //public List<BAL.Model.CustomerRegistration> GetLoginDetails()
        //{
        //    List<DAL.Repository.Login> UserList;
        //    using (IRepository<CustomerRegistration> loginRepo = new Repository<CustomerRegistration>(new TicketsHereModel()))
        //    {
        //        UserList = loginRepo.GetAll().ToList();
        //    }

        //    DAL.Repository.LoginRepository<DAL.Repository.Login> repo1 = new LoginRepository<DAL.Repository.Login>(new TicketsHereModel());
        //    UserList = repo1.GetLoginDetails();


        //    List<BAL.Model.CustomerRegistration> user = new List<Model.CustomerRegistration>();
        //    foreach (var login in UserList)
        //    {
        //        Model.CustomerRegistration loginField = new Model.CustomerRegistration();

        //        loginField.CustomerId = login.CustomerId;
        //        loginField.PhoneNumber = login.PhoneNumber;
        //        loginField.Password = login.Password;

        //        user.Add(loginField);

        //    }
        //    return user;
        //}


        long Number;
        string password;
        public string GetLoginDetails(long number, string password)
        {
            string UserList;

            this.Number = number;
            this.password = password;
            DAL.Repository.LoginRepository<DAL.Repository.Login> repo1 = new LoginRepository<DAL.Repository.Login>(new TicketsHereModel());
            UserList = repo1.GetLoginDetails(number, password);


            //List<BAL.Model.CustomerRegistration> user = new List<Model.CustomerRegistration>();
            //foreach (var login in UserList)
            //{
            //    Model.CustomerRegistration loginField = new Model.CustomerRegistration();

            //    loginField.CustomerId = login.CustomerId;
            //    loginField.PhoneNumber = login.PhoneNumber;
            //    loginField.Password = login.Password;

            //    user.Add(loginField);

            //}
            return UserList;
        }
    }
}