﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.BAL.Model
{
    public class CancelTicket
    {
        //public int SeatReservedId { get; set; }
        //public int ScreeningId { get; set; }
        //public string SeatNo { get; set; }
        public int ReservationId { get; set; }
        public string SeatBooked { get; set; }
        //public int PlayId { get; set; }
        //public int MovieId { get; set; }
    }
}
