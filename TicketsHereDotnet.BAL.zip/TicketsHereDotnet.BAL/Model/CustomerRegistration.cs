﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.Customer
{
    public class CustomerRegistration
    {

        //public int CustomerId { get; set; }
        public string CustomerName { get; set; }

        public long PhoneNumber { get; set; }
        
        public string EmailId { get; set; } 
        public string Password { get; set; }
        public bool IsAdmin { get; set; }



    }
}


