﻿using System.Threading.Tasks;

namespace TicketsHereDotnet.BAL.Model
{
    public class CustomerRegistration
    {
        public int CustomerId { get; set; }
        public long PhoneNumber { get; set; }
        public string Password { get; set; }

    }
}
