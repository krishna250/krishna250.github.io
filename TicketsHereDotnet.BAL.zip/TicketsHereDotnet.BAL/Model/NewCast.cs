﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.BAL.Model
{
  public  class NewCast
    {
        public string CastType { get; set; }
        public string CastPhoto { get; set; }
        public string Name { get; set; }

    }
}
