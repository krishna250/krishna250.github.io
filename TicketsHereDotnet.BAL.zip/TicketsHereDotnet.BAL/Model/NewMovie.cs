﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.Model
{
   public  class NewMovie
    {
        public DateTime ReleaseDate { get; set; }
        public string Description { get; set; }
        public string Video { get; set; }
        public string Language { get; set; }
        public string Image { get; set; }
        public string Duration { get; set; }
        public string Name { get; set; }
        public int Rating { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }
        public long UpdatedBy { get; set; }
        public string Genre { get; set; }




    }
}
