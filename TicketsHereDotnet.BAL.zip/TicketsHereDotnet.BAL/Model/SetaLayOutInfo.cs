﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.BAL.Customer
{
   public  class SetaLayOutInfo
    {
        public string rowName { get; set; }
        public int  numberOfSeats { get; set; }
    }
}
