﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.Payment
{
   public class TicketDetails
    {
        public int PlayId { get; set; }
        public string PlayName { get; set; }
        public int MovieId { get; set; }
        public string MovieName { get; set; }
        public string SeatNumber { get; set; }
        public decimal TotalCost { get; set; }
        public string BankName { get; set; }
        public string PaymentType { get; set; }
        public int ReservationTypeId { get; set; }
        public int MovieDetailsId { get; set; }
        public int TotalBookedSeat { get; set; }
        public DateTime Date { get; set; }
        public int CustomerId { get; set; }
        public int ReservationId { get; set; }
        public int TransactionId { get; set; }
        public string Comments { get; set; }
        public int ScreeningId { get; set; }
    }
}