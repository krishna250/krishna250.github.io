﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.BAL.Customer;



namespace TicketsHereDotnet.BAL.Movie
{
    public class MSearch
    {
        /*public List<MovieSearchVar> GetMovie(int MovieId)
        {
            MovieSearchRepository<MovieSearchVar> movie = new MovieSearchRepository<MovieSearchVar>(new TicketsHereModel());

            return movie.GetMovie(MovieId);
        }*/

        public List<MovieSearch> GetAllMovies()
        {

            List<Movies> movieList;

            using (IRepository<Movies> movieRepo = new Repository<Movies>(new TicketsHereModel()))
            {
                movieList = movieRepo.Query(movie=>movie.IsDeleted == false).ToList<Movies>(); 
                
                
            }
            List<MovieSearch> searchResult = new List<MovieSearch>();
            foreach(var movie in movieList)
            {
                TicketsHereDotnet.BAL.Customer.MovieSearch movieItem = new Customer.MovieSearch();

                 movieItem.Name = movie.Name;
                    movieItem.MovieId = movie.MovieId;
                    movieItem.Rating = movie.Rating;
                    movieItem.Genre = movie.Genre;
                    movieItem.Image = movie.Image;
                    movieItem.Language = movie.Language;

                    searchResult.Add(movieItem);
                
               
            }
            return searchResult;
        }
        public List<MovieSearch> GetMovie(string name)
        {
            List<Movies> movieDetails;
            //Get the list of movies for movie name
            using (IRepository<Movies> movieRepo = new Repository<Movies>(new TicketsHereModel()))
            {
                movieDetails = movieRepo.Query(movie => movie.Name.StartsWith(name) && movie.IsDeleted == false).ToList<Movies>();
            }
            List<MovieSearch> moviesResult = new List<MovieSearch>();
     
            foreach (var item in movieDetails)
            {
                TicketsHereDotnet.BAL.Customer.MovieSearch movieItem = new Customer.MovieSearch();

                movieItem.Name = item.Name;
                movieItem.MovieId = item.MovieId;
                movieItem.Rating = item.Rating;
                movieItem.Genre = item.Genre;
                movieItem.Image = item.Image;
                movieItem.Language = item.Language;
                moviesResult.Add(movieItem);
            }
            return moviesResult;
        }
    }

}
