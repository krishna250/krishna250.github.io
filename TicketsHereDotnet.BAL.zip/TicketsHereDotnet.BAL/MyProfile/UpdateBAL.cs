﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.MyProfile
{
    public class UpdateBAL
    {
        public int EditProfile(Model.updateProfile amm)
        {
            CustomerRegistration cr = new CustomerRegistration();
            
            try
            {
                using (GenericUnitOfWork gen = new GenericUnitOfWork())
                {
                    try
                    {
                        if (amm.CustomerId > 0)
                        {
                            IRepository<CustomerRegistration> MovieRepo = new Repository<CustomerRegistration>(gen.Context);
                            cr = MovieRepo.Query(dele => dele.CustomerId == amm.CustomerId).FirstOrDefault();

                            cr.CustomerName = amm.CustomerName;
                            cr.PhoneNumber = amm.PhoneNumber;
                            cr.EmailId = amm.EmailId;
                            
                            cr.Password = amm.Password;
                  

                            gen.BeginTransaction();
                            gen.repositories.Add(cr.GetType(), MovieRepo);
                            MovieRepo.Edit(cr);
                        }
                       
                        gen.SaveChanges();
                        return 1;
                    }
                    catch (Exception)
                    {
                        gen.Rollback();
                        return 0;
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}

