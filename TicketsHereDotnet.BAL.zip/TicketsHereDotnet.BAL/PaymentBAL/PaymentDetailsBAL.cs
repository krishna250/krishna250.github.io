﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.DAL.Repository;
using System.Net.Http;
using TicketsHereDotnet.BAL.Payment;


//using TicketsHereDotnet.BAL.Payment;

namespace TicketsHereDotnet.BAL.PaymentBAL
{
    public class PaymentDetailsBAL
    {
        public int SaveTicketDetails(TicketDetails det)
        {
            try
            {
                Movies MovieDetails = new Movies();
                MovieDetails.MovieId = det.MovieId;
                MovieDetails.Name = det.MovieName;

                Reservation ReservationDetails = new Reservation();
                ReservationDetails.ReservationId = det.ReservationId;
                ReservationDetails.TotalBookedSeat = det.TotalBookedSeat;
                ReservationDetails.Date = DateTime.Now;
                ReservationDetails.CustomerId = det.CustomerId;
                ReservationDetails.MovieDetailsId = det.MovieDetailsId;
                ReservationDetails.Comments = det.Comments;
                ReservationDetails.Amount = det.TotalCost;
                ReservationDetails.PaymentType = det.PaymentType;
                ReservationDetails.BankName = det.BankName;

                ReservedSeat SeatDetails = new ReservedSeat();
                SeatDetails.SeatNo = det.SeatNumber;
                SeatDetails.ScreeningId = det.ScreeningId;
              
                TicketsHereDotnet.Entity.Model.Transaction transactionDetails = new TicketsHereDotnet.Entity.Model.Transaction();
                transactionDetails.TrasactionId = det.TransactionId;
                transactionDetails.CustomerId = det.CustomerId;
                transactionDetails.NoOfSeats = det.TotalBookedSeat;
                transactionDetails.Amount = det.TotalCost;
                transactionDetails.PlayId = det.PlayId;
                transactionDetails.Comments = det.Comments;
                transactionDetails.PaymentType = det.PaymentType;
                transactionDetails.BankName = det.BankName;

              
                using (GenericUnitOfWork uoW = new GenericUnitOfWork())
                {
                    if (det.PlayId > 0)
                    {
                        uoW.repositories.Add(transactionDetails.GetType(), new Repository<TicketsHereDotnet.Entity.Model.Transaction>(uoW.Context));
                    }
                    if (MovieDetails.MovieId > 0)
                    {
                        uoW.repositories.Add(ReservationDetails.GetType(), new Repository<Reservation>(uoW.Context));
                        uoW.repositories.Add(SeatDetails.GetType(), new Repository<ReservedSeat>(uoW.Context));
                    }
                    
                    try
                    {
                        uoW.BeginTransaction();
                        if (det.PlayId > 0)
                        {
                            ((Repository<TicketsHereDotnet.Entity.Model.Transaction>)uoW.repositories[transactionDetails.GetType()]).Insert(transactionDetails);
                        }

                        if (MovieDetails.MovieId > 0)
                        {
                            ((Repository<Reservation>)uoW.repositories[ReservationDetails.GetType()]).Insert(ReservationDetails);

                            ((Repository<ReservedSeat>)uoW.repositories[SeatDetails.GetType()]).Insert(SeatDetails);

                        }
                        uoW.SaveChanges();
                        return 1;
                    }
                    catch (Exception ex)
                    {
                        string message = ex.Message;
                        uoW.Rollback();
                        return 0;
                    }
                }

            }
            catch (Exception exe)
            {
                string message = exe.Message;
                return 0;
            }
        }
    }
}
