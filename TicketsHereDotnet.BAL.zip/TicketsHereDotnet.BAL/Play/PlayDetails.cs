﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.BAL.Play
{
   public  class PlayDetails
    {
        public List<PlayList> GetPlayDetails(int PlayID)
        {
            PlayRepository<PlayList> play = new PlayRepository<PlayList>(new TicketsHereModel());

            return play.GetPlayDetails(PlayID);
        }
    }
}
