﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.DAL.Repository;
using balmodel=TicketsHereDotnet.BAL.Customer;

namespace TicketsHereDotnet.BAL.Playsearch
{
    public class Playsearch1
    {
        public List<balmodel.PlaySearch> GetDetails()
        {
            List<TicketsHereDotnet.Entity.Model.Play> PlayList;
            using (IRepository<TicketsHereDotnet.Entity.Model.Play> PlayRepo = new Repository<TicketsHereDotnet.Entity.Model.Play>(new TicketsHereModel()))
            {
                //PlayList = PlayRepo.GetAll().ToList();
                PlayList = PlayRepo.Query(play => play.Isdeleted == false).ToList<TicketsHereDotnet.Entity.Model.Play>();
            }
            List<balmodel.PlaySearch> PlayGetList = new List<balmodel.PlaySearch>();
            foreach(var play in PlayList)
            {

                TicketsHereDotnet.BAL.Customer.PlaySearch PlayItem = new Customer.PlaySearch();

                
                    PlayItem.PlayId = play.PlayId;
                    PlayItem.PlayName = play.PlayName;
                    PlayItem.Genre = play.Genre;
                    PlayItem.Poster = play.Poster;
                    PlayItem.Language = play.Language;
                    PlayGetList.Add(PlayItem);
                
            }
            return PlayGetList;
        }
        public List<balmodel.PlaySearch> SearchName(string Name)
        {
            List<TicketsHereDotnet.Entity.Model.Play> PlayDetails;
            using (IRepository<TicketsHereDotnet.Entity.Model.Play> PlayRepo = new Repository<TicketsHereDotnet.Entity.Model.Play>(new TicketsHereModel()))
            {
                
                PlayDetails = PlayRepo.Query(play => play.PlayName.StartsWith(Name) && play.Isdeleted == false).ToList<TicketsHereDotnet.Entity.Model.Play>();
            }
            List<balmodel.PlaySearch> PlaySearchList = new List<balmodel.PlaySearch>();
            foreach (var play in PlayDetails)
            {
                TicketsHereDotnet.BAL.Customer.PlaySearch PlayItem = new Customer.PlaySearch();
                PlayItem.PlayId = play.PlayId;
                PlayItem.PlayName = play.PlayName;
                PlayItem.Genre = play.Genre;
                PlayItem.Poster = play.Poster;
                PlayItem.Language = play.Language;
                PlaySearchList.Add(PlayItem);
            }
            return PlaySearchList;
        }

    }
}
