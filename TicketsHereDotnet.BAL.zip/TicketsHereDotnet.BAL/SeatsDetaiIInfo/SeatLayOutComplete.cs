﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;//true
using TicketsHereDotnet.DAL.Repository;//true
using System.Net.Http;//ok
using TicketsHereDotnet.BAL.Payment;
using TicketsHereDotnet.BAL.Customer;


namespace TicketsHereDotnet.BAL.SeatsDetaiIInfo
{
   public  class SeatLayOutComplete
    {
        public List<string> GetRowDetails (int id)
        {
            List<ReservedSeat> res = new List<ReservedSeat>();
            RepositoryBooking<ReservedSeat> aa = new RepositoryBooking<ReservedSeat>(new TicketsHereModel());
        res =    aa.GetReservedSeat(id);
            List<string> seat = new List<string>();
            foreach (var item in res)
            {
                seat.Add(item.SeatNo);
            }
            return seat;
        }
        public List<TicketsHereDotnet.BAL.Customer.SetaLayOutInfo> GetNumberofSeat(int id)
        {
            List<RowDetails> res = new List<RowDetails>();
            RepositoryBooking<RowDetails> aa = new RepositoryBooking<RowDetails>(new TicketsHereModel());
            res = aa.GetRowDetails(id);
            List<TicketsHereDotnet.BAL.Customer.SetaLayOutInfo> am = new List<SetaLayOutInfo>();


            foreach (var item in res)
            {
                TicketsHereDotnet.BAL.Customer.SetaLayOutInfo ar = new SetaLayOutInfo();

                ar.numberOfSeats = item.NoOfSeats;
                ar.rowName = item.RowName;
                am.Add(ar);
            }
            return am;
        }





    }
}
