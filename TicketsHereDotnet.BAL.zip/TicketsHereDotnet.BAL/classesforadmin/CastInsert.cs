﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.BAL.Customer;
using TicketsHereDotnet.DAL.Repository;

namespace TicketsHereDotnet.BAL.classesforadmin
{
  public  class CastInsert
    {
        public void BusinessPost(TicketsHereDotnet.BAL.Model.NewCast  det)
        {
           
            try
            {
                Entity.Model.CastInfo  cr = new Entity.Model.CastInfo();

                cr.CastPhoto = det.CastPhoto;
                cr.CastType = det.CastType;
                cr.Name = det.Name;
                using (GenericUnitOfWork gn = new GenericUnitOfWork())
                {
                    gn.repositories.Add(cr.GetType(), new Repository<Entity.Model.CastInfo>(gn.Context));
                    try
                    {
                        gn.BeginTransaction();
                        ((Repository<TicketsHereDotnet.Entity.Model.CastInfo>)gn.repositories[cr.GetType()]).Insert(cr);
                        gn.SaveChanges();
                    }
                    catch (Exception)
                    {
                        gn.Rollback();
                        throw;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
