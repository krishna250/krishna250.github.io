﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.BAL.Customer;

namespace TicketsHereDotnet.BAL.classesforadmin
{
   public  class MovieInsert
    {
        public void BusinessPost(TicketsHereDotnet.BAL.Model.NewMovie  det)
        {
            //Repository<TicketsHereDotnet.DAL.Repository.Customerlist> customer = new Repository<TicketsHereDotnet.DAL.Repository.Customerlist>(new TicketsHereModel());
            //    customer.Insert(det);
            //customer.CustomerRegistration.Insert(det);
            //customer.SaveChanges();

            //repository ka onject
            //jo dikai hai wo method call karo
            // aur sava katrdo

            try
            {
                Entity.Model.Movies cr = new Entity.Model.Movies();

                cr.Description = det.Description;
                cr.Duration = det.Duration;
                cr.Genre = det.Genre;
                cr.Image = det.Image;
                cr.IsDeleted = det.IsDeleted;
                cr.Language = det.Language;
                cr.ModifiedDate = DateTime.Now;
                cr.Rating = det.Rating;
                cr.ReleaseDate = det.ReleaseDate;
                cr.Video = det.Video;
                cr.UpdatedBy = det.UpdatedBy;
                cr.Name = det.Name;
                using (GenericUnitOfWork gn = new GenericUnitOfWork())
                {
                    gn.repositories.Add(cr.GetType(), new Repository<Entity.Model.Movies>(gn.Context));
                    try
                    {
                        gn.BeginTransaction();
                        ((Repository<TicketsHereDotnet.Entity.Model.Movies>)gn.repositories[cr.GetType()]).Insert(cr);
                        gn.SaveChanges();
                    }
                    catch (Exception)
                    {
                        gn.Rollback();
                        throw;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
