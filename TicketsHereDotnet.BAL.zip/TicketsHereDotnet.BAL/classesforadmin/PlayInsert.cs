﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.BAL.Customer;

namespace TicketsHereDotnet.BAL.classesforadmin
{
   public  class PlayInsert
    {
        public void BusinessPost(TicketsHereDotnet.BAL.Model.NewPlay det)
        {
            //Repository<TicketsHereDotnet.DAL.Repository.Customerlist> customer = new Repository<TicketsHereDotnet.DAL.Repository.Customerlist>(new TicketsHereModel());
            //    customer.Insert(det);
            //customer.CustomerRegistration.Insert(det);
            //customer.SaveChanges();

            //repository ka onject
            //jo dikai hai wo method call karo
            // aur sava katrdo

            try
            {
                Entity.Model.Play  cr = new Entity.Model.Play();

                cr.PlayName = det.PlayName;
                cr.ModifiedDate = DateTime.Now;
                cr.Poster = det.Poster;
                cr.Price = det.Price;
                cr.StartDate = det.StartDate;
                cr.TimeDuration = det.TimeDuration;
                cr.VideoUrl = det.VideoUrl;
                cr.Language = det.Language;
                cr.Genre = det.Genre;
                cr.EndDate = det.EndDate;
                cr.Description = det.Description;
                cr.CityId = det.CityId;
                cr.Isdeleted = false;
                cr.Rating = det.Rating;
                cr.UserPhoneno = det.UserPhoneno;
                using (GenericUnitOfWork gn = new GenericUnitOfWork())
                {
                    gn.repositories.Add(cr.GetType(), new Repository<Entity.Model.Play>(gn.Context));
                    try
                    {
                        gn.BeginTransaction();
                        ((Repository<TicketsHereDotnet.Entity.Model.Play>)gn.repositories[cr.GetType()]).Insert(cr);
                        gn.SaveChanges();
                    }
                    catch (Exception)
                    {
                        gn.Rollback();
                        throw;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
