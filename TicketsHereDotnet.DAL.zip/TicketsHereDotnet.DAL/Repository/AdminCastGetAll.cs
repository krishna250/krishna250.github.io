﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{
    public class AdminCastGetAll
    {
        TicketsHereModel t = new TicketsHereModel();

        public List<AdminCast> AdmingetAll()
        {
            Repository<CastInfo> r = new Repository<CastInfo>(t);

            List<AdminCast> castList = new List<AdminCast>();
            //Movies mv = new Movies();
            // mv.MovieId = id;            
            var castDisplay = (from cast in t.CastInfo
                                  select new AdminCast()
                                  {
                                      CastPhoto = cast.CastPhoto,
                                      CastType=cast.CastType,
                                      Name=cast.Name
                                  }
                                   ).ToList();
            foreach (AdminCast cast in castDisplay)
            {
                castList.Add((AdminCast)cast);
            }
            return castList;
        }
    }
}

