﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{
    public class AdminCount
    {
        TicketsHereModel t = new TicketsHereModel();

        public int AdmingetAll()
        {
            Repository<Play> r = new Repository<Play>(t);

            List<Adminget> playList = new List<Adminget>();
            //Movies mv = new Movies();
            // mv.MovieId = id;            
            var Admin = (from customer in t.CustomerRegistration
                         where customer.IsAdmin == true
                         select new Adminget()
                         {
                             // CustomerId = customer.CustomerId,
                             CustomerName = customer.CustomerName,
                             EmailId = customer.EmailId,
                             IsAdmin = customer.IsAdmin,
                             Password = customer.Password,
                             PhoneNumber = customer.PhoneNumber
                         }
                                   ).Count();

            return Admin;
        }
    }
}
