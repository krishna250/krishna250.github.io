﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{

    public class AdminMovieGetAll
    {
        TicketsHereModel t = new TicketsHereModel();

        public List<AdminGetMovie> AdmingetAll()
        {
            Repository<Movies> r = new Repository<Movies>(t);

            List<AdminGetMovie> m = new List<AdminGetMovie>();
            //Movies mv = new Movies();
            // mv.MovieId = id;            
            var moviesNotDeleted = (from movie in t.Movies
                                    where movie.IsDeleted == false
                                    select new AdminGetMovie()
                                    {
                                        MovieId = movie.MovieId,
                                        Description = movie.Description,
                                        Genre = movie.Genre,
                                        Image = movie.Image,
                                        Duration = movie.Duration,
                                        IsDeleted = movie.IsDeleted,
                                        Language = movie.Language,
                                        ModifiedDate = movie.ModifiedDate,
                                        Name = movie.Name,
                                        Rating = movie.Rating,
                                        ReleaseDate = movie.ReleaseDate,
                                        UpdatedBy = movie.UpdatedBy,
                                        Video = movie.Video
                                    }
                                   ).ToList();
            foreach (AdminGetMovie movie in moviesNotDeleted)
            {
                m.Add((AdminGetMovie)movie);
            }
            return m;
        }
    }
}
