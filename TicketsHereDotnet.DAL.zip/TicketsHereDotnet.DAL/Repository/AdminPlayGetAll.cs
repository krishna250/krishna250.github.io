﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{
    public class AdminPlayGetAll
    {
        TicketsHereModel t = new TicketsHereModel();

        public List<AdminGetPlay> AdmingetAll()
        {
            Repository<Play> r = new Repository<Play>(t);

            List<AdminGetPlay> playList = new List<AdminGetPlay>();
            //Movies mv = new Movies();
            // mv.MovieId = id;            
            var playNotDeleted = (from play in t.Play
                                    where play.Isdeleted == false
                                    select new AdminGetPlay()
                                    {
                                        CityId=play.CityId,
                                        Description=play.Description,
                                        EndDate=play.EndDate,
                                        Genre=play.Genre,
                                        Isdeleted=play.Isdeleted,
                                        Language=play.Language,
                                        ModifiedDate=play.ModifiedDate,
                                        PlayId=play.PlayId,
                                        PlayName=play.PlayName,
                                        Poster=play.Poster,
                                        Price=play.Price,
                                        Rating=play.Rating,
                                        StartDate=play.StartDate,
                                        TimeDuration=play.TimeDuration,
                                        UserPhoneno=play.UserPhoneno,
                                        VideoUrl=play.VideoUrl
                                    }
                                   ).ToList();
            foreach (AdminGetPlay play in playNotDeleted)
            {
                playList.Add((AdminGetPlay)play);
            }
            return playList;
        }
}
}