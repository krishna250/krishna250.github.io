﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.DAL.Repository
{
    public class BookingHistor
    {
        public string MovieName { get; set; }
        public string Poster { get; set; }
        public int ReservationId { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime BookingDate { get; set; }
        public decimal PricePaid { get; set; }
        public string SeatsBooked { get; set; }
        public string StartTime { get; set; }
    }
}