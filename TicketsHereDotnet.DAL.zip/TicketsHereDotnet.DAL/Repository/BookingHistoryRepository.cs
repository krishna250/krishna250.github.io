﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity.Model;


namespace TicketsHereDotnet.DAL.Repository
{
    public class BookingHistoryRepository<T> : Repository<T> where T : class
    {
        public BookingHistoryRepository(TicketsHereModel context)
        {
            this.context = context;
        }
        public List<BookingHistor> GetBookingHistoryDetails(int id)
        {
            List<BookingHistor> BHDetails = new List<BookingHistor>();
            BHDetails = (from R in ((TicketsHereModel)context).Reservation
                         join md in ((TicketsHereModel)context).MovieDetails on R.MovieDetailsId equals md.MovieDetailsId
                         join m in ((TicketsHereModel)context).Movies on md.MovieId equals m.MovieId
                         join s in ((TicketsHereModel)context).Screening on md.MovieDetailsId equals s.MovieDetailsId
                         join Rs in ((TicketsHereModel)context).ReservedSeat on R.ReservationId equals Rs.ReservationId
                         where R.CustomerId == id
                         orderby R.ReservationId descending
                         select new BookingHistor()
                         {

                             MovieName = m.Name,
                             Poster = m.Image,
                             ReservationId = R.ReservationId,
                             PaymentMethod = R.PaymentType,
                             BookingDate = R.Date,
                             PricePaid = R.Amount,
                             SeatsBooked = Rs.SeatNo,
                             StartTime = s.Starttime
                         }).ToList<BookingHistor>();
            List<BookingHistor> playBook = new List<BookingHistor>();
            playBook = (from transaction in ((TicketsHereModel)context).Transaction
                        join playDetails in ((TicketsHereModel)context).Play on transaction.PlayId equals playDetails.PlayId
                        where transaction.CustomerId == id
                        orderby transaction.TrasactionId descending
                        select new BookingHistor()
                        {

                            MovieName = playDetails.PlayName,
                            Poster = playDetails.Poster,
                            ReservationId = transaction.TrasactionId,
                            PaymentMethod = transaction.PaymentType,
                            BookingDate = playDetails.StartDate,
                            PricePaid = transaction.Amount,
                            SeatsBooked = transaction.NoOfSeats + "",
                            StartTime = playDetails.StartDate.ToString(),
                        }).ToList<BookingHistor>();

            BHDetails.AddRange(playBook);
            return BHDetails;
        }
    }
}