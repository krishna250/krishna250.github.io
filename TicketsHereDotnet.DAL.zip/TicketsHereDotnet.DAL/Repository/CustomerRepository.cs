﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using TicketsHereDotnet.DAL.Repository;
//using TicketsHereDotnet.Entity.Model;

//namespace TicketsHereDotnet.DAL.Repository
//{
 
//        public class CustomerRepository<T> : Repository<T> where T : class
//        {
//            public CustomerRepository(TicketsHereModel context)
//            {
//                this.context = context;

//            }

//            //public int Price { get; private set; }

//            public List<Customerlist> GetCustomerDetails(int customerID)
//            {
//                //try
//                //{
//                List<Customerlist> customerList = new List<Customerlist>();

//                customerList = (from customer in ((TicketsHereModel)context).CustomerRegistration
                             
//                            where customer.CustomerId == customerID
//                             select new Customerlist()
//                             {



//                        PhoneNumber=customer.PhoneNumber,
//                        CustomerName =customer.CustomerName,
//                        EmailId =customer.CustomerName,
//                        Password= customer.Password
        
                                


//                             }).ToList<Customerlist>();

//                return customerList;

//                //}
//                //catch (Exception)
//                //{

//                //    return null;
//                //}
//            }

//        }
//}
