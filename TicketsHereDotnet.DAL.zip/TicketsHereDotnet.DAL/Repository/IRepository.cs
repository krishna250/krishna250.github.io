﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.DAL.Repository
{
    //class IRepository
    //{

    //}
    public interface IRepository<T>:IDisposable
    {
        T GetById(int id);
        IQueryable<T> GetAll();
        void Edit(T entity);
        void Insert(T entity);
        void Delete(T entity);
        IQueryable<T> Query(System.Linq.Expressions.Expression<Func<T, bool>> whereCondition);
    }
}
