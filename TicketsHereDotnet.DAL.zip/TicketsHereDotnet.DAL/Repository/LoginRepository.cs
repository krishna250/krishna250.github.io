﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{
    public class LoginRepository<T> : Repository<T> where T : class
    {


        public LoginRepository(TicketsHereModel context)
        {
            this.context = context;

        }
        //public List<Login> GetLoginDetails()
        //{
        //    List<Login> UserList = new List<Login>();

        //    UserList = (from login in ((TicketsHereModel)context).CustomerRegistration
        //                select new Login()
        //                {
        //                    CustomerId = login.CustomerId,
        //                    PhoneNumber=login.PhoneNumber,
        //                    Password=login.Password

        //}).ToList();


        //    return UserList;
        //}






        public string GetLoginDetails(long number, string password)
        {
            string i = "None";
            try
            {
                var a = (from login in ((TicketsHereModel)context).CustomerRegistration
                         where login.PhoneNumber == number && login.Password == password
                         select new Login()
                         {
                             CustomerId = login.CustomerId,
                             Isadmin = login.IsAdmin,
                             Password = login.Password,
                             PhoneNumber = login.PhoneNumber
                         }).ToList();


                foreach(Login l in a)
                {
                    if(l.Isadmin==true)
                    {
                        i = l.CustomerId + "A";
                    }
                    else
                    {
                        i = l.CustomerId + "C";
                    }
                }
                return i;
            }
            catch (Exception ex)
            {
                string str = ex.Message;
                return "true";
            }
            
        }


    }
}

