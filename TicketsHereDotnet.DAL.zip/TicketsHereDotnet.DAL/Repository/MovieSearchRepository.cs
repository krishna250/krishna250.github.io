﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{
    public class MovieSearchRepository<T> : Repository<T> where T : class
    {
        public MovieSearchRepository(TicketsHereModel context)
        {
            this.context = context;

        }
        public List<MovieSearchVar> GetMovie(int id)
        {
            //TicketsHereModel obj = new TicketsHereModel();
            List<MovieSearchVar> msearch = new List<MovieSearchVar>();
            //List<MovieSearchVar> lm = obj.Movies.ToList<MovieSearchVar>();

            var result = (from pr in ((TicketsHereModel)context).Movies
                          where pr.MovieId==id
                          select new MovieSearchVar()
                          {
                              Name = pr.Name,
                              Image = pr.Image,
                              Genre = pr.Genre,
                              Rating = pr.Rating

                          }).ToList();
            return result;

            /*foreach (var x in result)
            {
                msearch.Add(x);
            }
            return msearch;*/


        }
        //public List<MovieSearchVar> GetAllMo(int id)
        //{
        //    List<Movies> m = new List<Movies>();
        //}
    }
    }
