﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.Entity.RequiredFeildsFolderEntity;

using System.Data.Entity;

namespace TicketsHereDotnet.DAL.Repository
{
    public class MoviesRepository<T> : Repository<T> where T : class
    {
        TicketsHereModel t = new TicketsHereModel();
        public Movies getMovieDetails(int id)
        {
            Repository<Movies> r = new Repository<Movies>(t);

            Movies mv = new Movies();
            // mv.MovieId = id;            
            mv = r.GetById(id);
            return mv;
            //return DbSet<Movies>.GetById(id);
        }
        public Movies get(int id)
        {
            TicketsHereModel t = new TicketsHereModel();
            Movies m = t.Movies.Find(id);
            return m;
        }
        
        public MoviePageDisplay getDetails(int id)
        {
            var moviePageDisplay = (from movie in t.Movies
                                   where movie.MovieId == id
                                   select new MoviePageDisplay()
                                   {
                                       Name = movie.Name,
                                       Description = movie.Description,
                                       Video = movie.Video,
                                       Rating = movie.Rating,
                                       ReleaseDate = movie.ReleaseDate,
                                       Duration = movie.Duration,
                                       Genre = movie.Genre,
                                       Image = movie.Image,
                                       Language = movie.Language,
                                       cast =
                                      (
                                      from cast in t.CastInfo
                                      join moviecast in t.MovieCast
                                      on cast.CastId equals moviecast.CastId
                                      where moviecast.MovieId == movie.MovieId
                                      select new Cast()
                                      {
                                          CastName = cast.Name,
                                          CastType = cast.CastType,
                                          CastPhoto = cast.CastPhoto
                                      }
                                      ).ToList(),
                                       theatre =
                                       (
                                       from movietheatreLink in t.MovieDetails
                                       join moviehalldetails in t.MovieHallInfo
                                       on movietheatreLink.MovieHallId equals moviehalldetails.MovieHallId
                                       where movietheatreLink.MovieId == movie.MovieId && moviehalldetails.CityId==1
                                       select new Theatre()
                                       {
                                           theatreName = moviehalldetails.MovieHallName,
                                           auditorium = (
                                           from auditorium in t.Auditorium
                                           join screening in t.Screening
                                           on auditorium.AudiId equals screening.AudiId /*into r*/
                                          // from p in r.DefaultIfEmpty()
                                           join moviedetails in  t.MovieDetails on screening.MovieDetailsId equals moviedetails.MovieDetailsId into r1
                                           //from q in r1.DefaultIfEmpty()
                                           where auditorium.MovieHallId == moviehalldetails.MovieHallId
                                           group auditorium by new {auditorium.AudiId,auditorium.AudiName,auditorium.MovieHallId} into g
                                           select new TicketsHereDotnet.Entity.RequiredFeildsFolderEntity.Auditorium()
                                           {
                                               AudiId = g.Key.AudiId,
                                               Name = g.Key.AudiName,
                                               screening = (
                                               from screeningtime in t.Screening join moviedet in t.MovieDetails
                                               on screeningtime.MovieDetailsId equals moviedet.MovieDetailsId
                                               where screeningtime.AudiId == g.Key.AudiId && screeningtime.MovieDetailsId== movietheatreLink.MovieDetailsId   //&& movietheatreLink.MovieHallId == g.Key.MovieHallId
                                               select new Entity.RequiredFeildsFolderEntity.Screening()
                                               {
                                                   MovieDetailsId=screeningtime.MovieDetailsId,
                                                   ScreeningId= screeningtime.ScreeningId,
                                                   AudiId = screeningtime.AudiId,
                                                   Starttime = screeningtime.Starttime
                                               }
                                               ).ToList()
                                           }
                                           ).ToList()
                                       }
                                       ).ToList()
                                   }).FirstOrDefault();
            MoviePageDisplay m = (MoviePageDisplay)moviePageDisplay;
            return m;
        }
    }
}
