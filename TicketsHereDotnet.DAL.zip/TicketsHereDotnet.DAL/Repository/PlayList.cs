﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsHereDotnet.DAL.Repository
{
    public class PlayList
    {
        public string PlayName { get; set; }
        public string Description { get; set; }
        public string Language { get; set; }
        public string TimeDuration { get; set; }
        public string Poster { get; set; }
        public decimal Price { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Genre { get; set; }
        public string CityName { get; set; }
    }
}
