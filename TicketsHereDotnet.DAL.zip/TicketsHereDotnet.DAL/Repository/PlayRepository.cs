﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;


namespace TicketsHereDotnet.DAL.Repository
{
    public class PlayRepository<T>:Repository<T> where T: class
    {
        public PlayRepository(TicketsHereModel context)
        {
            this.context = context;

        }

        public int Price { get; private set; }

        public List<PlayList> GetPlayDetails(int PlayID)
        {
            //try
            //{
                List<PlayList> PlaysList = new List<PlayList>();

                PlaysList = (from play in ((TicketsHereModel)context).Play
                             join citydetails in ((TicketsHereModel)context).City on play.CityId equals citydetails.CityId
                             where play.PlayId == PlayID
                             select new PlayList()
                             {

                                 PlayName = play.PlayName,
                                 Poster = play.Poster,
                                 Description=play.Description,
                                 StartDate = play.StartDate,
                                 EndDate = play.EndDate,
                                 TimeDuration = play.TimeDuration,
                                 Genre = play.Genre,
                                 CityName = citydetails.CityName,
                                 Language = play.Language,
                                 Price = play.Price
                                

                             }).ToList<PlayList>();

                return PlaysList;

            //}
            //catch (Exception)
            //{

            //    return null;
            //}
        }

    }


}
