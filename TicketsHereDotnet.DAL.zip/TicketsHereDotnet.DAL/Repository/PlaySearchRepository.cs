﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.DAL.Repository;

namespace TicketsHereDotnet.DAL.Repository
{
    public class PlaySearchRepository<T>:Repository<T> where T:class
    {
        public PlaySearchRepository(TicketsHereModel context)
        {
            this.context = context;
        }
        public List<playSearch> GetPlayDetails(int id)
        {
            List<playSearch> PlayDetails = new List<playSearch>();
            PlayDetails = (from play in ((TicketsHereModel)context).Play
                           where play.PlayId == id
                           select new playSearch()
                           {
                               PlayId = play.PlayId,
                               PlayName = play.PlayName,
                               Genre = play.Genre,
                               Poster = play.Poster,
                               Language = play.Language
                           }).ToList<playSearch>();

            return PlayDetails;
        }
    }
}
