﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketsHereDotnet.Entity.Model;

namespace TicketsHereDotnet.DAL.Repository
{

    public class RepositoryBooking<T> : Repository<T> where T : class
    {

        public RepositoryBooking(TicketsHereModel context)
        {
            this.context = context;
            dbset = context.Set<T>();
        }

        //method to get the number of reserved  seats here 
        public List<ReservedSeat> GetReservedSeat(int ScreeningId)
        {
            try
            {
                List<ReservedSeat> reservedSeat = new List<ReservedSeat>();
                reservedSeat = (from a in ((TicketsHereModel)context).ReservedSeat
                                where a.ScreeningId == ScreeningId
                                select a
                                
                                    

                    


                                ).ToList<ReservedSeat>();
                return reservedSeat;
            }
            catch(Exception )
            {
                return null;
            }


        }
        //to get the row details 
        public List<RowDetails> GetRowDetails(int AudiId)
        {
            List<RowDetails> rowList = new List<RowDetails>();
            rowList = (from row in ((TicketsHereModel)context).RowDetails
                             where row.AudiId == AudiId
                             select row
                             ).ToList<RowDetails>();

            return rowList;
        }
       
      

    }
}