﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using mod = TicketsHereDotnet.BAL.Customer;
using TicketsHereDotnet.BAL.CustomerBAL;

namespace TicketsHereDotnet.Services.Controllers
{
    public class AddMovieController : ApiController
    {
        BAL.classesforadmin.MovieInsert b1 = null;
        [HttpPost]
        // POST: api/CustomerRegistration
        public int Post(TicketsHereDotnet.BAL.Model.NewMovie std)
        {
            try
            {
                b1 = new BAL.classesforadmin.MovieInsert();
                b1.BusinessPost(std);
                return 1;
            }
            catch(Exception ee)
            {
                return 2;
            }
        }

    }
}
