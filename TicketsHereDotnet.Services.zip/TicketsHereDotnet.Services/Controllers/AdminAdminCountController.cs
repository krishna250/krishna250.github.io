﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.DAL.Repository;

namespace TicketsHereDotnet.Services.Controllers
{
    public class AdminAdminCountController : ApiController
    {
        // GET: api/AdminAdminCount
        // GET: api/AdminAdminCount
        public int Get()
        {
            AdminCount a = new AdminCount();
            return a.AdmingetAll();
        }

    }
}
