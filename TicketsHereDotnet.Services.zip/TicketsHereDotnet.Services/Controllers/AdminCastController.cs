﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.DAL.Repository;


namespace TicketsHereDotnet.Services.Controllers
{
    public class AdminCastController : ApiController
    {
        // GET: api/AdminCast
            public List<AdminCast> Get()
            {
            AdminCastGetAll a = new AdminCastGetAll();
                return a.AdmingetAll();
            }
    }
}
