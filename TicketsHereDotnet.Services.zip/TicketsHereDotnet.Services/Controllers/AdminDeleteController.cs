﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.BAL.Admin;


namespace TicketsHereDotnet.Services.Controllers
{
    public class AdminDeleteController : ApiController
    {
        public HttpResponseMessage Post(AdminModelMapper mpp)   
        {
            AdminDelete ad = new AdminDelete();
            int ret = ad.SoftDelete(mpp);
            if(ret == 1)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Deleted");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Data cant be deleted");
            }
        }
    }
}
