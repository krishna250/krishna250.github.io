﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace TicketsHereDotnet.Services.Controllers
{
    public class AdminEditController : ApiController
    {
        public HttpResponseMessage Post(BAL.Admin.EditMoviePlayMapper empm)
        {
            BAL.Admin.AdminEdit ae = new BAL.Admin.AdminEdit();
            int ret = ae.EditMoviePlay(empm);
            if(ret == 1)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Data is Updated");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Not Updated");
            }
        }
    }
}
