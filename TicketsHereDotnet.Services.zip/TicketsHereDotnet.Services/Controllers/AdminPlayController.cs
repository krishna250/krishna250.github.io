﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.Entity.Model;
using TicketsHereDotnet.DAL.Repository;

namespace TicketsHereDotnet.Services.Controllers
{
    public class AdminPlayController : ApiController
    {
        // GET: api/AdminPlay
        public List<AdminGetPlay> Get()
        {
            AdminPlayGetAll a = new AdminPlayGetAll();
            return a.AdmingetAll();
        }
    }
}
