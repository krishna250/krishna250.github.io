﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.BAL.BookingHistory;
using TicketsHereDotnet.DAL.Repository;

namespace TicketsHereDotnet.Services.Controllers
{
    public class BookingHistoryController : ApiController
    {
        

        // GET: api/BookingHistory/5
        public HttpResponseMessage Get(int id)
        {
            try
            {


                BAL.BookingHistory.BookHistoryBAL BHvalue = new BookHistoryBAL();
                List<BookingHistor> list = BHvalue.GetBookingHistory(id);

                if (BHvalue.GetBookingHistory(id) != null && list.Count>0)
                {
                    return Request.CreateResponse<List<BookingHistor>>(HttpStatusCode.OK, list );
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No Booking History Found");
                }
            }
            catch (Exception)
            {
                // Log exception code goes here  
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Error occured while executing GetBookingHistory");
   }



        }

    }
}


