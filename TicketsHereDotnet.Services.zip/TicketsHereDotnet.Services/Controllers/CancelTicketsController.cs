﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.BAL.CancelBookedTickets;
using TicketsHereDotnet.BAL.Model;

namespace TicketsHereDotnet.Services.Controllers
{
    public class CancelTicketsController : ApiController
    {
        // DELETE: api/CancelTickets/5
        public HttpResponseMessage Post(CancelTicket canceldetails)
        {
            CancelBookedTickets cbt = new CancelBookedTickets();
            int ReturnValue = cbt.DeleteDetails(canceldetails);
            if (ReturnValue == 1)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Data is deleted");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Data is not found");
            }
        }
    }
}
