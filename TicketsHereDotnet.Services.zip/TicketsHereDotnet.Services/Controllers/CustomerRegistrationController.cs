﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using mod = TicketsHereDotnet.BAL.Customer;
using TicketsHereDotnet.BAL.CustomerBAL;


namespace TicketsHereDotnet.Services.Controllers
{
    public class CustomerRegistrationController : ApiController
    {
        BAL.CustomerBAL.CustomerRegistrationBAL b1 = null;
        

       

        [HttpPost]
        // POST: api/CustomerRegistration
        public HttpResponseMessage Post(mod.CustomerRegistration std)
        {

            
            
                b1 = new BAL.CustomerBAL.CustomerRegistrationBAL();
                int i = b1.BusinessPost(std);
                if (i == 1)
                {
                    return Request.CreateResponse(HttpStatusCode.Created, 1);
                }
                else
                {
                    // return Request.CreateErrorResponse(HttpStatusCode.Forbidden, "Mobile number already exsists ");
                    return Request.CreateResponse(HttpStatusCode.Created, 2);

                }
            
          

        }

      
    }
}
