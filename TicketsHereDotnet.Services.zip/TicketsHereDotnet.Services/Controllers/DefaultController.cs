﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.BAL.SeatsDetaiIInfo;

namespace TicketsHereDotnet.Services.Controllers
{
    public class DefaultController : ApiController
    {
        
            public List<string> Get (int id)
            {
            BAL.SeatsDetaiIInfo.SeatLayOutComplete playValue = new BAL.SeatsDetaiIInfo.SeatLayOutComplete();
           return  playValue.GetRowDetails(id);
            }


        }
    }


