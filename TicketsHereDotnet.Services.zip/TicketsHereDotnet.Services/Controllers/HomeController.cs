﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TicketsHereDotnet.Entity;

namespace TicketsHereDotnet.Services.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";



            //using (var context = new Entity.Model.TicketsHereModel())
            //{
            //    var City = new Entity.Model.City();
            //    City.CityId = 102;
            //    City.CityName = "Mumbai";
            //    context.City.Add(City);
            //    context.SaveChanges();

            //}
            return View();
        }
    }
}
