﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace TicketsHereDotnet.Services.Controllers
{
    public class LoginController : ApiController
    {
        public string Get(string input)
        {
            string[] s = input.Split('(');
            long Number;
            long.TryParse(s[0], out Number);
            string password = "";
            for (int i = 1; i < s.Length; i++)
            {
                password = password + " " + s[i];
            }
            password = password.Substring(1);
 
            BAL.Login.LoginDetails logindetails = new BAL.Login.LoginDetails();
            string variable = logindetails.GetLoginDetails(Number, password);
            
            return variable;
        }
    }
}