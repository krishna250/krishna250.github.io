﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using balmodel=TicketsHereDotnet.BAL.Customer;
using entity = TicketsHereDotnet.Entity.Model.Movies;

using TicketsHereDotnet.DAL.Repository;
using TicketsHereDotnet.Entity;

namespace TicketsHereDotnet.Services.Controllers
{
    public class MovieSearchController : ApiController
    {
        // GET: api/MovieSearch
        public List<balmodel.MovieSearch> Get()
        {
            BAL.Movie.MSearch movieSearchBAL = new BAL.Movie.MSearch();
            return movieSearchBAL.GetAllMovies();


        }

        // GET: api/MovieSearch/5
        /* public List<MovieSearchVar> Get(int id)
         {
             BAL.Movie.MSearch movieValue = new BAL.Movie.MSearch();
             return movieValue.GetMovie(id);
             //return "value";
         }*/

        [Route("api/MovieSearch/{name}")]
        [HttpGet]
        public List<balmodel.MovieSearch> Get(string name)
        {
            BAL.Movie.MSearch movieValue = new BAL.Movie.MSearch();
            return  movieValue.GetMovie(name);
            
            //return "value";
        }

        
       
    }
}
