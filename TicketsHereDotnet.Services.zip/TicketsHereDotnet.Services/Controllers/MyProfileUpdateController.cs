﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace TicketsHereDotnet.Services.Controllers
{
    public class MyProfileUpdateController : ApiController
    {
        
        public HttpResponseMessage Put(BAL.Model.updateProfile upr)
        {
            BAL.MyProfile.UpdateBAL ae = new BAL.MyProfile.UpdateBAL();
            int ret = ae.EditProfile(upr);
            if (ret == 1)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Data is Updated");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Not Updated");
            }
        }
    }
}
