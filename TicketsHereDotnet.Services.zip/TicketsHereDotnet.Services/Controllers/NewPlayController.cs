﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace TicketsHereDotnet.Services.Controllers
{
    public class NewPlayController : ApiController
    {
        BAL.classesforadmin.PlayInsert  b1 = null;
        

        // POST: api/NewPlay
        [HttpPost]
        // POST: api/CustomerRegistration
        public void Post(TicketsHereDotnet.BAL.Model.NewPlay  std)
        {
            b1 = new BAL.classesforadmin.PlayInsert();
            b1.BusinessPost(std);
        }
        
    }
}
