﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.BAL.Payment;
using TicketsHereDotnet.BAL.PaymentBAL;
using EntityModel = TicketsHereDotnet.Entity.Model;
using mod = TicketsHereDotnet.BAL.Payment;


namespace TicketsHereDotnet.Services.Controllers
{
    public class PaymentController : ApiController
    {
        public HttpResponseMessage Post(mod.TicketDetails details)
        {
            PaymentDetailsBAL objBAL = new PaymentDetailsBAL();
            int ret = objBAL.SaveTicketDetails(details);
            if(ret == 1)
            {
                return Request.CreateResponse(HttpStatusCode.Created, "Data is stored");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Data is not stored");
            }
        }
    }
}
