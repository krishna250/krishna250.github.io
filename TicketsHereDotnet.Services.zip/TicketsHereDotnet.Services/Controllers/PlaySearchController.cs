﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using balmodel=TicketsHereDotnet.BAL.Customer;
namespace TicketsHereDotnet.Services.Controllers
{
   
        public class PlaySearchController : ApiController
        {
            public List<balmodel.PlaySearch> Get()
            {
                BAL.Playsearch.Playsearch1 search = new BAL.Playsearch.Playsearch1();
                return search.GetDetails();
            }

            [Route("api/PlaySearch/{name}")]
            [HttpGet]
            public List<balmodel.PlaySearch> Get(string name)
            {
                BAL.Playsearch.Playsearch1 search = new BAL.Playsearch.Playsearch1();
                return search.SearchName(name);
            }
        }
    
}