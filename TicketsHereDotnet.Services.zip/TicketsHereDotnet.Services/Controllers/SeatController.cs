﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Text.RegularExpressions;
using TicketsHereDotnet.BAL.SeatsDetaiIInfo;

namespace TicketsHereDotnet.Services.Controllers
{
    public class SeatController : ApiController
    {
      

        // GET: api/Seat/5
        public List<string> Get(int id)   
        {
           
            SeatLayOutComplete seatBL = new SeatLayOutComplete();
            List<string> all = new List<string>();
          //  int i = 0;
            foreach (var item in seatBL.GetRowDetails(id))
            {
               if(item.Length == 2)
                {
                    all.Add(item);
                }
                else
                {
                    char[] splitchar = { ',' };
                    string[] strArr = item.Split(splitchar);
                    for ( int count = 0; count <= strArr.Length - 1; count++)
                    {
                       all.Add( strArr[count]);
                    }
                }
                

            }
            return all;
        }

        // POST: api/Seat
       
    }
}
