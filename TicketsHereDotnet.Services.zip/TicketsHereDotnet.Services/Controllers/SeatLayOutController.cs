﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketsHereDotnet.BAL.SeatsDetaiIInfo;

using EntityModel = TicketsHereDotnet.Entity.Model;


namespace TicketsHereDotnet.Services.Controllers
{
    public class SeatLayOutController : ApiController
    {
        
        public List<TicketsHereDotnet.BAL.Customer.SetaLayOutInfo> Get(int id)
        {
            SeatLayOutComplete cc = new SeatLayOutComplete();
           return  cc.GetNumberofSeat(id);

        }
    

      
    }
}
