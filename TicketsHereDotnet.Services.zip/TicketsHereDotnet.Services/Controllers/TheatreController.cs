﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EntityModel=TicketsHereDotnet.Entity.Model;
//using TicketsHereDotnet.BAL.MovieTheatreDisplay.BAL;
//using TicketsHereDotnet.BAL.MapperClassFolder;
//using required= TicketsHereDotnet.BAL.MovieTheatreDisplay.BAL.RequiredFeildsFolder;
using TicketsHereDotnet.DAL.Repository;
using DalRepo = TicketsHereDotnet.DAL.Repository;
using required = TicketsHereDotnet.Entity.RequiredFeildsFolderEntity;

//using System.Web.Http.Cors;

namespace TicketsHereDotnet.Services.Controllers
{
    //[EnableCors(origins: "https://ticketshereapidotnetnov2017.azurewebsites.net/api/Theatre", headers: "*", methods: "*")]
    public class TheatreController : ApiController
    {
        // GET: api/Theatre
        //public Movies Get()
        //{
        //    TheatreBusinessLogic b = new TheatreBusinessLogic();
        //    return b.GetMovie(1);
        //}

        // GET: api/Theatre/5
        public required.MoviePageDisplay Get(int id)
        {
            DalRepo.MoviesRepository<TicketsHereDotnet.Entity.RequiredFeildsFolderEntity.MoviePageDisplay> d = new DalRepo.MoviesRepository<Entity.RequiredFeildsFolderEntity.MoviePageDisplay>();
            return d.getDetails(id);
            //TheatreBusinessLogic b = new TheatreBusinessLogic();

            //return b.
            //TheatreBusinessLogic b = new TheatreBusinessLogic();
            //return b.getdetails(id);

        }

       
    }
}
