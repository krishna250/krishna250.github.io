export class Standing {

    team_name: String;
    overall_league_position: String;
    overall_league_payed: String;
    overall_league_W: String;
    overall_league_D: String;
    overall_league_L: String;
    overall_league_GF: String;
    overall_league_GA: String;
    overall_league_PTS: String;
  
}
