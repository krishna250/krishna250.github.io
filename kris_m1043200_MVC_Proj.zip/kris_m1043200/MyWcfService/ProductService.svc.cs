﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace MyWcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ProductService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ProductService.svc or ProductService.svc.cs at the Solution Explorer and start debugging.
    public class ProductService : IProductService

    {

        private MyDemoEntities md = new MyDemoEntities();
        public List<Member> findall()
        {
            // return mdeqq.ProductEntities.ToList();
            return md.Members.ToList();
        }

        public List<Member> find(int id)
        {
            return md.Members.Where(p => p.MemberId == id).ToList();
        }

        public List<Member> findByDate(DateTime CreationDate)
        {
            return md.Members
                .Where(p => p.DOB.Value==CreationDate).ToList();
        }

       
    }
}
