﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using  kris_m1043200.Models;


namespace kris_m1043200.Controllers
{
    public class CreateAppController : Controller
    {
        //HomeModel1Entities HME1 = new HomeModel1Entities();
        HomeModel2Entities HME = new HomeModel2Entities();
        // GET: CreateApp
        //public ActionResult CreateApp(Member1 me)
        //{
        //    //using (HME1)
        //    //{
        //    //    HME1.Member1.Add(me);
        //    //    HME1.SaveChanges();
        //    //}
        //    return RedirectToAction("Home","Index");
        //}


        //[HttpPost]
        //public ActionResult CreateApp1(Member1 me)
        //{
        //    using (HME)
        //    {
        //        HME.Member1.Add(me);
        //        HME.SaveChanges();
        //    }
        //    return RedirectToAction("Home", "Index");
        //}
    }
}