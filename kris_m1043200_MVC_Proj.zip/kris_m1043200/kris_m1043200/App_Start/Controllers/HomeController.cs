﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kris_m1043200.Models;
    using System.Data.Entity;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using iTextSharp.text.html.simpleparser;


namespace kris_m1043200.Controllers
{
  //  [Authorize(Roles = "Admin")]
    public class HomeController : Controller
    {

        HomeModel2Entities HME =  new HomeModel2Entities();
      
        User uv = new User();
        //HomeModelEntities HME = new HomeModelEntities();
        // HomeModel1Entities HME1 = new HomeModel1Entities();
       // [Authorize(Roles = "Admin")]
        public ActionResult Home()
        {

            return View();
        }

        public ActionResult Unauthorize()
        {

            return View();
        }

        // [Authorize(Roles ="Admin")]
        public ActionResult Index()
        {
            var admin = Session["IsAdmin"];
            //Session["IsAdmin"] = userdatails.IsAdmin;


           ///if (admin.Equals(1))
           // {
                return View(HME.Members.ToList());
         // }
      // else
             
              //ViewBag.DuplicateMessage = "no access";
           // return View("Contact");

        }

        public ActionResult GetApplicationnum(int id = 0)
        {
            Member mem = new Member();
            //SampleDbEntities sde = new SampleDbEntities();
            using (HME)
            {
                // bool s1 = model.Users.Any(X => X.UserName);


                if (HME.Members.Any(x => x.Relationship == null) || HME.Members.Any(x => x.ApplicationNumber == null)

                    || HME.Members.Any(x => x.FirstName == null) 
                    || HME.Members.Any(x => x.Gender == null) || HME.Members.Any(x => x.MemberId.Equals(0))
                   )
                {
                    ViewBag.DuplicateMessage = "please add member details inorder to satisfy validation & exit";
                    //  ViewBag.Success
                    return View("Index", "Home");
                }
                else
                //{
                //    //   return View(HME.Members.)


                //    var member = HME.Members.OrderByDescending(x => x.MemberId).FirstOrDefault();
                //    // return View(HME.Members.ToList());
                //    if (id != 0)
                //    {
                //        mem = HME.Members.Where(x => x.MemberId == id).FirstOrDefault<Member>();
                //    }
                //    else if (member == null)
                //    {
                //        mem.ApplicationNumber = "00000 0001";
                //    }
                //    else
                //    {
                //        mem.ApplicationNumber = "00000 00" +
                //            (Convert.ToInt32(member.ApplicationNumber.Substring(9, member.ApplicationNumber.Length - 9) + 1).ToString("01"));
                //    }
                //    return View(mem);


                    return View(HME.Members.ToList());
                    // return RedirectToAction("Index");
                }
            }
        

        //[HttpPost]
        //public ActionResult GetApplicationnum(Member me)
        //{
        //    using (HME)
        //    {
        //        HME.Members.Add(me);
        //        HME.SaveChanges();
        //    }
        //    return RedirectToAction("Index");
        //}
        public ActionResult Create(int id=0)
        {
            Member mem = new Member();
            var member = HME.Members.OrderByDescending(x => x.MemberId).FirstOrDefault();
           // return View(HME.Members.ToList());
           if(id != 0)
            {
                mem = HME.Members.Where(x => x.MemberId == id).FirstOrDefault<Member> ();
            }
           else if (member==null)
            {
                mem.ApplicationNumber = "00000 0001";
            }
            else {
                mem.ApplicationNumber = "00000 00" + 
                    (Convert.ToInt32(member.ApplicationNumber.Substring(9, member.ApplicationNumber.Length-9)+1).ToString("01"));
            }
            return View(mem);
        }
        [HttpPost]
        public ActionResult Create(Member me)
        {
            using (HME)
            {
                HME.Members.Add(me);
                HME.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        //[HttpPost]
        //public ActionResult crte(Member1 me)
        //{
        //    using (HME)
        //    {
        //        HME.Member1.Add(me);
        //        //HME.Users.Add(me);
        //        HME.SaveChanges();
        //    }
        //    return RedirectToAction("Index");
        //}

        //public ActionResult Search(FormCollection fc)
        //{
        //    string condition = fc["condition"];
        //    string keyword = fc["keyword"];
        //    if (condition.Equals("applicationid"))
        //        ViewBag.listproducts = ps.find(Convert.ToInt32(keyword));
        //    else
        //        ViewBag.listproducts = ps.findByDate(Convert.ToDateTime(keyword));
        //    // Service1 ps = new Service1
        //    //ProductService ps = new ProductService();
        //    //ViewBag.listProducts = ps.findAll();
        //    return View("Index");
        //}

        public ActionResult Edit(int id)
        {
            using (HME)
            {
                // HME.Members.Add(me);
                // HME.SaveChanges();
                //HME.Members.Attach()
                return View(HME.Members.Where(x => x.MemberId == id).FirstOrDefault());
            }
            // return RedirectToAction("Index");
            //return View();
        }

        [HttpPost]
        public ActionResult Edit(int id, Member memb)
        {
           // int nid;
            
           // var chan= new Member { nid=memb.MemberId}
            try
            {
                using (HME)
                {
                    //HME.Members.Add(me);
                    // HME.SaveChanges();

                    // HME.Entry(memb).State= .IsModified 
                    HME.Entry(memb).State = EntityState.Modified;

                    //HME.Entry(memb).Property(x=>x.Relationship).IsModified = true;
                    HME.SaveChanges();
                }
                 return RedirectToAction("Index","Home");
                //return View();
            }
            catch
            {
                return View();

            }
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        [HttpGet]
        public ActionResult pdfexport()
        {
            //NorthwindEntities entities = new NorthwindEntities();
            return View(from customer in HME.Members.Take(10)
                       select customer);

            //return View(HME.Members.Where(x => x.MemberId == id).FirstOrDefault());
        }

        [HttpPost]
        [ValidateInput(false)]
        public FileResult Export(string GridHtml)
        {

            using (MemoryStream stream = new System.IO.MemoryStream())
            {
                StringReader sr = new StringReader(GridHtml);
                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
                pdfDoc.Close();
                return File(stream.ToArray(), "application/pdf", "Grid.pdf");
            }
        }

        public ActionResult Delete(int id)
        {
            using (HME)
            {
                // HME.Members.Add(me);
                // HME.SaveChanges();
                //HME.Members.Attach()
                return View(HME.Members.Where(x => x.MemberId == id).FirstOrDefault());
            }
            // return RedirectToAction("Index");
            //return View();
        }

        [HttpPost]
        public ActionResult Delete(int id, FormCollection memb)
        {
            // int nid;

            // var chan= new Member { nid=memb.MemberId}
            try
            {
                using (HME)
                {
                    Member meb =
                         HME.Members.Where(x => x.MemberId == id).FirstOrDefault();
                    HME.Members.Remove(meb);
                    //HME.Entry(memb).Property(x => x.Relationship).IsModified = true;
                    HME.SaveChanges();
                    //  HME.SaveChanges();
                }
                return RedirectToAction("Index","Home");
                //return View();
            }
            catch
            {
                return View();

            }
        }


        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public enum Gender
        {
            Male,
            Female
        }
    }
}