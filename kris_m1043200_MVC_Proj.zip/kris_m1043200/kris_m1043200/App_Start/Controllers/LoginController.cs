﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kris_m1043200.Models;
using MyWcfService;
namespace kris_m1043200.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Authorize(kris_m1043200.Models.User usermodel)
        {

            //DbModel model = new DbModel()
            using ( SampleDbEntities model = new SampleDbEntities())
            {
                var userdatails = model.Users.Where
                    (x => x.UserName == usermodel.UserName && x.Password== usermodel.Password).FirstOrDefault();
                if (userdatails == null)
                {
                    ViewBag.DuplicateMessage = "wrong username or password";
                    //  ViewBag.Success
                   // return View("Login", usermodel);
                   // usermodel.LoginErrorMessage = "wrong username or password";
                    return View("Index", usermodel);

                }
                else
                {
                    Session["UserId"] = userdatails.UserId;
                    Session["Username"] = userdatails.UserName;
                    Session["Email"] = userdatails.Email;
                    Session["IsAdmin"] = userdatails.Admin;
                    return RedirectToAction("Home", "Home");
                }


               // return View();
            }
            
        }

        public ActionResult LogOut()
        {
            Session.Abandon();
            return RedirectToAction("Index","Login");
        }

        public ActionResult Register()
        {
            Session.Abandon();
            return RedirectToAction("Login", "User");
        }
    }
}