﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kris_m1043200.Models;
using kris_m1043200.Viewmodel;
//using kris_m1043200.ProductService;
using WcfService  ;
using MyWcfService;



namespace kris_m1043200.Controllers
{
    public class ProductController : Controller
    {
      //  private ProductServiceClient ps = new ProductServiceClient();
        // Product 
        // GET: Product
        ProdService1 psp = new ProdService1();
           
        //IService1 psc = new IService1();
       // ser
      // pro
        //ProductService ps = new ProductService();
        public ActionResult Index()
        {
           // Service1 ps = new Service1
           
            ViewBag.listProducts = psp.findall();
            return View();
        }

        public ActionResult Search( FormCollection fc)
        {
            string condition = fc["condition"];
            string keyword = fc["keyword"];
            if (condition.Equals("applicationid"))
                ViewBag.listproducts = psp.find(Convert.ToInt32(keyword));
            else
                ViewBag.listproducts = psp.findByDate(Convert.ToDateTime(keyword));
            // Service1 ps = new Service1
            //ProductService ps = new ProductService();
            //ViewBag.listProducts = ps.findAll();
            return View("Index");
        }

        [HttpGet]
        public ActionResult Create()
        {
            //ProductService ps = new ProductService();
            //ViewBag.listProducts = ps.findAll();
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(ProductViewmodel pvm)
        {
            WcfService.ProdService1  ps = new ProdService1();
            //ViewBag.listProducts = ps.findAll();
           // ps.Create(pvm.Product);
            //Session["UserId"] = userdatails.UserId;
           // Session["Username"] = userdatails.UserName;
            //Session["Email"] = userdatails.Email;
           // Product.
            return RedirectToAction("Index");
        }

        //public ActionResult Delete(ProductViewmodel pvm)
        //{
        //    ProductService ps = new ProductService();
        //    //ViewBag.listProducts = ps.findAll();
        //    ps.create(pvm.Product);
        //    return View("Index");
        //}

    }
}