﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kris_m1043200.Models;
//using MyWcfService;

//using kris_m1043200.Models;

namespace kris_m1043200.Controllers
{
    public class UserController : Controller
    {
       // User 
        // GET: User
        [HttpGet]
        public ActionResult Login(int id=0)
        {
            User usermodel = new User();
            return View(usermodel);
        }

        [HttpPost]
        public ActionResult Login(User usermodel)
        {
            // model
            //  MyWcfService.MyDemoEntities model = new MyWcfService.MyDemoEntities();
          //  HomeModel2Entities model = new HomeModel2Entities();
            SampleDbEntities sde = new SampleDbEntities();
            using (sde)
            {
                // bool s1 = model.Users.Any(X => X.UserName);
                if (ModelState.IsValid)
                {

                    if (sde.Users.Any(x => x.UserName == usermodel.UserName))
                    {
                        ViewBag.DuplicateMessage = "user already exists";
                        //  ViewBag.Success
                        return View("Login", usermodel);
                    }
                    sde.Users.Add(usermodel);
                    sde.SaveChanges();
                }
            }
            ModelState.Clear();
          //  ViewBag.SuccessMessage
   ViewBag.SuccessMessage = "Registration successfull";
                return View("Login", new User());

        }
    }
}