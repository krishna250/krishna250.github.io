﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kris_m1043200.Models;
using System.Data.Entity;
using  kris_m1043200.Controllers;
using PagedList.Mvc;
using PagedList;

namespace kris_m1043200.Controllers
{
    public class searchController : Controller
    {
        // GET: search
        HomeModel2Entities HME = new HomeModel2Entities();
        //public ActionResult Index()
        //{
        //    return View(HME.Members.ToList());
        //}

        //public ActionResult Index(string searchBy, string search)
        //{
        //    if (searchBy == "Gender")
        //    {
        //        return View(HME.Members.Where(x => x.Gender == search || search == null).ToList());
        //    }
        //    else
        //    {
        //        return View(HME.Members.Where(x => x.FirstName.StartsWith(search) || search == null).ToList());
        //    }
        //}


        public ActionResult Index(string searchBy, string search, int? pagesize, int? page, string sortBy)
        {
            int pageIndex = 1;
            pageIndex = page.HasValue ? Convert.ToInt32(page) : 1;
            int defaSize = (pagesize ?? 5);
            ViewBag.psize = defaSize;

            ViewBag.NameSort = String.IsNullOrEmpty(sortBy) ? "Name desc" : "";
            ViewBag.GenderSort = sortBy == "Gender" ? "Gender desc" : "Gender";
            ViewBag.NameSort = String.IsNullOrEmpty(sortBy) ? "LName desc" : "";
            
            ViewBag.NameSort = String.IsNullOrEmpty(sortBy) ? "appnum desc" : "";
           

            // ViewBag.psize = defaSize;
            // ViewBag.PageSize = new SelectListItem() { Value = "5", Text = "5" };
            //{
            //    new SelectListItem() { Value="5", Text= "5" },
            //    //new SelectListItem() { Value="10", Text= "10" },
            //    //new SelectListItem() { Value="15", Text= "15" },
            //    //new SelectListItem() { Value="25", Text= "25" },
            //    //new SelectListItem() { Value="50", Text= "50" },
            //};

            //IPagedList<Member> involst = null;

            var employees = HME.Members.AsQueryable();
           if (searchBy == "appnum")
            {
                employees = employees.Where(x => x.ApplicationNumber == search || search == null);
            }

             else if (searchBy == "Gender")
            {
                employees = employees.Where(x => x.Gender == search || search == null);
            }

            else if (searchBy == "DOB")
            {
                employees = employees.Where(x => x.DOB.Equals (search));
            }

            

            else if (searchBy == "LName")
            {
                employees = employees.Where(x => x.LastName.StartsWith(search) || search == null);
            }
            else
            {
                employees = employees.Where(x => x.FirstName.StartsWith(search) || search == null);
            }

            switch (sortBy)
            {
                case "Name desc":
                    employees = employees.OrderByDescending(x => x.FirstName);
                    break;
                case "LName desc":
                    employees = employees.OrderByDescending(x => x.FirstName);
                    break;
                case "appnum desc":
                    employees = employees.OrderByDescending(x => x.FirstName);
                    break;
                case "Gender desc":
                    employees = employees.OrderByDescending(x => x.Gender);
                    break;
                case "Gender":
                    employees = employees.OrderBy(x => x.Gender);
                    break;
                default:
                    employees = employees.OrderBy(x => x.FirstName);
                    break;
            }
            
            return View(employees.ToPagedList(page ?? 1, 5));

           // return View(employees.ToPagedList(pageIndex, defaSize));

          //  involst = HME.Members.OrderBy(x => x.MemberId).ToPagedList(pageIndex, defaSize);

          //  return View(involst);
        }


        public ActionResult Edit(int id)
        {
            using (HME)
            {
                // HME.Members.Add(me);
                // HME.SaveChanges();
                //HME.Members.Attach()
                return View(HME.Members.Where(x => x.MemberId == id).FirstOrDefault());
            }
            // return RedirectToAction("Index");
            //return View();
        }

        public ActionResult Details(int id)
        {
            using (HME)
            {
                // HME.Members.Add(me);
                // HME.SaveChanges();
                //HME.Members.Attach()
                return View(HME.Members.Where(x => x.MemberId == id).FirstOrDefault());
            }
            // return RedirectToAction("Index");
            //return View();
        }

        [HttpPost]
        public ActionResult Edit(int id, Member memb)
        {
            // int nid;

            // var chan= new Member { nid=memb.MemberId}
            try
            {
                using (HME)
                {
                    //HME.Members.Add(me);
                    // HME.SaveChanges();

                    HME.Entry(memb).State = EntityState.Modified;
                
                    //HME.Entry(memb).Property(x => x.Relationship).IsModified = true;
                    HME.SaveChanges();
                }
                return RedirectToAction("Index","search");
                //return View();
            }
            catch
            {
                return View();

            }
        }

        public ActionResult Delete(int id)
        {
            using (HME)
            {
                // HME.Members.Add(me);
                // HME.SaveChanges();
                //HME.Members.Attach()
                return View(HME.Members.Where(x => x.MemberId == id).FirstOrDefault());
            }
            // return RedirectToAction("Index");
            //return View();
        }

        [HttpPost]
        public ActionResult Delete(int id, FormCollection memb)
        {
            // int nid;

            // var chan= new Member { nid=memb.MemberId}
            try
            {
                using (HME)
                {
                    Member meb =
                         HME.Members.Where(x => x.MemberId == id).FirstOrDefault();
                    HME.Members.Remove(meb);
                    //HME.Entry(memb).Property(x => x.Relationship).IsModified = true;
                    HME.SaveChanges();
                  //  HME.SaveChanges();
                }
                return RedirectToAction("Index","search");
                //return View();
            }
            catch
            {
                return View();

            }
        }

    }
}