﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
namespace kris_m1043200.Models
{
    public class NewMember
    {
        public int MemberId { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("FirstName")]
        [RegularExpression("^[-, *.A-Za-z]*$", ErrorMessageResourceType = typeof(string), ErrorMessageResourceName = "NoQuote")]
        [StringLength(maximumLength: 32, MinimumLength = 4, ErrorMessage = "Length must be between 4 to 32")]
        public string FirstName { get; set; }

        public string MI { get; set; }

        [Required(ErrorMessage = "This field is required")]
        [DisplayName("LastName")]
        public string LastName { get; set; }
        public string Suffix { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("DOB")]
        public System.DateTime DOB { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("Gender")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("Relationship")]
        public string Relationship { get; set; }
        public string ApplicationNumber { get; set; }
    }
}