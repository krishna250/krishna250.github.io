﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace kris_m1043200.Models
{
    public class Product
    {
        //[Display(Name ="FirstName")]
       // public int MemberId { get; set; }
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }

        [Display(Name = "MI")]
        public string MI { get; set; }
        [Display(Name = "LastName")]
        public string LastName { get; set; }
        [Display(Name = "Sufffix")]
        public string Suffix { get; set; }

        [Display(Name = "DOB")]
        public System.DateTime DOB { get; set; }
        [Display(Name = "Gender")]
        public string Gender { get; set; }
        public string Relationship { get; set; }
        public string ApplicationNumber { get; set; }
    }
}