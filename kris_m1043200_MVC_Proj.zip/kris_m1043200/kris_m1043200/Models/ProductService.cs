﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kris_m1043200.Models;
using System.Net;
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;


namespace kris_m1043200.Models
{
    public class ProductServi
    {
       // private ProductEntities mde = new ProductEntities();
        private string BASE_URL = "http://localhost:2696/ProductService.svc/";

        public List<Product> findall()
        {
            try
            {
                var webClient = new WebClient();
                var json = webClient.DownloadString(BASE_URL + "findall");
                var js = new JavaScriptSerializer();


                return js.Deserialize<List<Product>>(json);

            }
            catch
            {
                return null;
            }
        }

        public Product find(string id)
        {
            try
            {
                var webClient = new WebClient();
                string url = string.Format(BASE_URL + "find{0}");
                var json = webClient.DownloadString(BASE_URL + "findall");
                var js = new JavaScriptSerializer();
                return js.Deserialize<Product>(json);


                // return js.Deserialize<List<Product>>(json);

            }
            catch
            {
                return null;
            }
        }

        //public List<Product> findall()
        //{
        //    // return mdeqq.ProductEntities.ToList();
        //    return mde.Products.ToList();
        //}

        //public Product find(int id)
        //{
        //    return mde.Products.Single(p => p.MemberId == id);
        //}

        //public List<Product> findByDate(DateTime CreationDate)
        //{
        //    return mde.Products.Where(p => p.DOB.Equals(CreationDate)).ToList();
        //}

        public bool Create(Product product)
        {
            try
            {
DataContractJsonSerializer ser =new DataContractJsonSerializer(typeof(Product));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, product);
                String data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

 WebClient webclient = new WebClient();
                webclient.Headers["Content-type"] = "applicaton/json";
                webclient.Encoding = Encoding.UTF8;
                webclient.UploadString(BASE_URL + "Create", "POST", data);
               // webclient.UploadValues(BASE_URL + "Create", "POST");
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool edit(Product product)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Product));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, product);
                String data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                WebClient webclient = new WebClient();
                webclient.Headers["Content-type"] = "applicaton/json";
                webclient.Encoding = Encoding.UTF8;
                webclient.UploadString(BASE_URL + "edit", "PUT", data);
                return true;
            }
            catch
            {
                return false;
            }
        }


        public bool delete(Product product)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Product));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, product);
                String data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                WebClient webclient = new WebClient();
                webclient.Headers["Content-type"] = "applicaton/json";
                webclient.Encoding = Encoding.UTF8;
                webclient.UploadString(BASE_URL + "delete", "DELETE", data);
                return true;
            }
            catch
            {
                return false;
            }
        }


    }
}

    
    
