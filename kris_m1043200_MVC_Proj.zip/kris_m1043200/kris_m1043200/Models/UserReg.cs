﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace kris_m1043200.Models
{
    public class UserReg
    {
        public int UserId { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("UserName")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [DisplayName("ConfirmPassword")]
        [Compare("Password", ErrorMessage = "Password doesn't match.")]
        [DataType(DataType.Password)]

        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "This field is required")]
        [DisplayName("Email")]
        public string Email { get; set; }
        public bool IsAdmin { get; set; }
    }
}