﻿$(function () {
    $('.datepicker').datetimepicker();
});