﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kris_m1043200.Models;

namespace kris_m1043200.Viewmodel
{
    public class ProductViewmodel
    {
        public  Product Product
        {
            get;
            set;
        }

    }
}