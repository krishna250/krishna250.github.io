## Guestbook application example

This example shows how to build a simple, multi-tier web application using Kubernetes and [Docker](https://www.docker.com/).

Please follow the tutorial at https://cloud.google.com/kubernetes-engine/docs/tutorials/guestbook.
