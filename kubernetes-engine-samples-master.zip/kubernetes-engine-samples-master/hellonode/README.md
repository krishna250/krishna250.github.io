# Hello Node example

**This example has been replaced with `hello-app`. See [here](../hello-app) to
follow the tutorial with the new sample application.**
