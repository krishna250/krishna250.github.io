# Using Persistent Disks with WordPress and MySQL

Follow this tutorial at https://cloud.google.com/kubernetes-engine/docs/tutorials/persistent-disk/


