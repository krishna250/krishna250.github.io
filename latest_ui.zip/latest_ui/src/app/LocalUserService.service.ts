import { Injectable } from '@angular/core';

// Import Observable Dependencies
import { Observable } from 'rxjs';

export interface LocalUserObject {
     PlayId:number,
     Name:string,
     MovieId:number,
     SeatNumber:string,
     TotalCost:number,
     BankName:string,
     PaymentType:string,
     ReservationTypeId :number, 
     TicketCost:number,
     MovieDetailsId:number,
     TotalBookedSeats:number,
     CustomerId:number,
     ScreeningId:number,
     type:string,
     AudiId:number,
     ScreeningTime:string, 
}

@Injectable()
export class LocalUserService {

    constructor() { 

    }

    // Get Local User Object from Local Storage
    getLocalUserObject(): LocalUserObject {
        return JSON.parse(localStorage.getItem('KEY_MOVIEID') || null);
    }

    // Set Local User Object using the given value.
    setLocalUserObject(localUserObject: LocalUserObject) {
    
        localStorage.setItem('KEY_MOVIEID', JSON.stringify(localUserObject));
    }
}