export interface AddAdmin {
    Name: string,
    emailid: string,
    PhoneNumber: Number
    Password:string
}