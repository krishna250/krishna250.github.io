import { Component, OnInit } from '@angular/core';
import { Adding } from './Adding';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { AddAdminService } from './admin-add.service';

@Component({
  selector: 'app-admin-add',
  templateUrl: './admin-add.component.html',
  styleUrls: ['./admin-add.component.css']
})
export class AdminAddComponent implements OnInit {

    constructor(private router: Router, private service: AddAdminService) { }
  AddList: Adding[] = [];
  form: FormGroup;
  flag = false;
  str = "";
  admin = {
    CustomerName: "",
    PhoneNumber: 0,
    EmailId: "",
    Password: '0',
    IsAdmin: false,
  };
  abc: any;
  toAdd(form) {
    this.AddList.push(this.form.value);
    console.log(this.AddList);
    //console.log(form.value);
    // console.log(this.AddList[0].CustomerName);
    this.admin.CustomerName = this.AddList[0].CustomerName;
    this.admin.EmailId = this.AddList[0].EmailId;
    this.admin.IsAdmin = true;

    this.admin.Password = this.AddList[0].Password;
    this.admin.PhoneNumber = this.AddList[0].PhoneNumber;
    // console.log("this.admin");
    console.log(this.admin);
    this.service.AddAdmin(this.admin)
      .subscribe(
      // data =>{
      //   this.abc=data;

      data => {
        console.log(data);
        //     this.values=data,

        if (data == 1) {
          //alert('Congratulation! you Successfully Registered');
          this.str = "Credentials Granted";
          console.log ("hi");
          // this.router.navigate(['/login']);
        }
        else 
        {
          //   alert('User already exists');
          this.str = "Credentials Cannot be granted as user already exists";
        }
         

      });

    this.flag = true;
    setTimeout(() => { this.ngOnInit();
        this.admin = {
    CustomerName: "",
    PhoneNumber: 0,
    EmailId: "",
    Password: '0',
    IsAdmin: false,
  };
  this.AddList= [];
  this.str="";
   this.flag = false; }, 3000);

  }


  Adminredirect() :  void  {

    this.router.navigate(['/Admin']);
  }

  ngOnInit() {
    // this.form = new FormGroup({
    //   name: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.maxLength(16), Validators.minLength(16)]),
    //   name_on_the_card: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+')]),
    //   exp_month: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.min(1), Validators.max(12), Validators.maxLength(2), Validators.maxLength(2)]),
    //   exp_year: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.min(2018), Validators.max(2030), Validators.maxLength(4), Validators.maxLength(4)]),
    //   cvv: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.maxLength(3), Validators.minLength(3)])
    // })
    this.form = new FormGroup({
      CustomerName: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z]+')]),
      EmailId:  new  FormControl('', [Validators.required,  Validators.email, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9]+.[a-z][a-z][a-z]')]),
      PhoneNumber: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern('[6-9][0-9]+')]),
      Password: new FormControl('Helloimme@1', [Validators.required])
    })
  }

}
