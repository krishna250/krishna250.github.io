import { Injectable } from '@angular/core';

import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs';

@Injectable()
export class AddAdminService
{
      constructor(private http: HttpClient) 
      {
            
      }
      AddAdmin(adminDetails):Observable<any>
      {
         return this.http.post('https://ticketshereapidotnetnov2017.azurewebsites.net/api/Registration',adminDetails);
      }
        
}
