import { Component ,OnInit} from '@angular/core';
import {MoviesService} from './movies.service';
import{movieAdd} from './movie';
import {Observable} from 'rxjs'
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'admin-create-movie-root',
  templateUrl: './admin-create-movie.component.html',
  styleUrls: ['./admin-create-movie.component.css'],
  providers:[MoviesService]
})
export class AdminCreateMovieComponent  implements OnInit
 {
  info1={ 
   Image: '',
  Description:'',
  Language:'',
  Video:'',
  ModifiedDate : "" ,
  Genre: '',
  ReleaseDate : "2018-01-29T06:38:48.644Z",
  Name:'',
  UpdatedBy:9415732787,
  Rating: 0, 
 Duration: "",
 IsDeleted: false
   
 };
 info:movieAdd;

  constructor(private ser:MoviesService ) { }
  ngOnInit() {

  
  }

getMovie(event:any){
  console.log(event.target.value);
this.info1.Name=event.target.value;
console.log(this.info1.Name);

  }
   getGenere (event:any){
this.info1.Genre=event.target.value;

  }

       getRating(event:any){
this.info1.Rating =event.target.value;
console.log (this.info1.Rating);

  }
   getTime(event:any){
this.info1.Duration =event.target.value+ "Minutes";

  }
  getImageUrl(event:any){
this.info1.Image =event.target.value;

  }
   getLanguage(event:any){
this.info1.Language =event.target.value;
//console.log(this.info.Language );
  }
  getvideo(event:any){
this.info1.Video =event.target.value;
  }
  getDesc(event:any)
  {   
this.info1.Description=event.target.value;
  }
getReleaseDate(event:any){
this.info1.ReleaseDate=event.target.value;
console.log(this.info1.ReleaseDate)
  }


Savesubmit():void 
{
 if  (this.info1.Name != "" && this.info1.Description!=""&&this.info1.Duration!=""&& this.info1.Genre!="" && this.info1.Image!="" && this.info1.Rating!=0 && this.info1.Language!="")
 {
this.ser.AddMovieInfo(this.info1).subscribe();
 alert("Added Sucessfully !!");

 }
 else 
 {
       alert("Missed Some Field !!")
 }

}


 }
