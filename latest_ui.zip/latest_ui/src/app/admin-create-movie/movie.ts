export class movieAdd
{
  Image: string;
  Description:string;
  Language:string;
  Video:string;
  ModifiedDate=new Date();
  Genre:string;
  ReleaseDate=new Date();
  Name:string;
  UpdatedBy:number = 9415732787;
  Rating: number; 
 Duration: string;
}
 
  
 

  
 
