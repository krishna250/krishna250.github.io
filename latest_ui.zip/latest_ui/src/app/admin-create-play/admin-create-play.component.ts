import { Component, OnInit } from '@angular/core';
import { PlayService } from "./play.service";

@Component({
  selector: 'app-admin-create-play',
  templateUrl: './admin-create-play.component.html',
  styleUrls: ['./admin-create-play.component.css'],
   providers:[PlayService]
})
export class AdminCreatePlayComponent implements OnInit {

 info1={ 
   PlayName: "",
  Description: "",
  Language: "",
  TimeDuration: "",
  Poster: "",
  VideoUrl: "",
  Price: 150,
  ModifiedDate: "2018-01-29T06:38:48.834Z",
  Isdeleted: false ,
  CityId: 1,
  UserPhoneno: 9415732787,
  Rating: 0,
  StartDate: "2018-01-29T06:38:48.834Z",
  EndDate: "2018-01-29T06:38:48.834Z",
  Genre: ""
   
 };
  constructor(private ser: PlayService ) { }
  
 
  ngOnInit() {

  
  }


getMovie(event:any){
this.info1.PlayName=event.target.value;
  }
   getGenere (event:any){
this.info1.Genre=event.target.value;

  }

       getRating(event:any){
this.info1.Rating =event.target.value;

  }
   getTime(event:any){
this.info1.TimeDuration =event.target.value +"Minutes";

  }
  getImageUrl(event:any){
this.info1.Poster =event.target.value;

  }
   getLanguage(event:any){
this.info1.Language =event.target.value;
//console.log(this.info.Language );
  }
  getvideo(event:any){
this.info1.VideoUrl =event.target.value;

  }
getDescription(event : any)
{
  this.info1.Description =event.target.value;
}
getStartDate(event : any)
{
  this.info1.StartDate =event.target.value;
}
getReleaseDate(event : any)
{
  this.info1.EndDate =event.target.value;
}




Savesubmit():void 
{
  if(this.info1.PlayName != '' && this.info1.Description != "" &&  this.info1.Language != " " &&  this.info1.Poster != "" &&  this.info1.Rating !=0 && this.info1.Genre !="")
  {
  console.log (this.info1);
this.ser.AddMovieInfo(this.info1).subscribe();
 alert("Added Sucessfully!!")

  }
  else{
    alert("Missed Some Field !!")
  }


}
}
