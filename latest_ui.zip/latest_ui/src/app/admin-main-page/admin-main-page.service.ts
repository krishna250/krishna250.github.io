import { Injectable } from '@angular/core';

import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs';

@Injectable()
export class AdminMainPageService
{
      constructor(private http: HttpClient) 
      {
            
      }
      getMovieCount():Observable<any>
      {
         return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminMovie');
      }
        getPlayCount():Observable<any>
      {
         return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminPlay');
      }
       getCastCount():Observable<any>
      {
         return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminCast');
      }
       getAdminCount():Observable<any>
      {
         return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminAdminCount');
      }
}
