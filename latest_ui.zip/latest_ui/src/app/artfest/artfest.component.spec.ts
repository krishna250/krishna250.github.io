import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtfestComponent } from './artfest.component';

describe('ArtfestComponent', () => {
  let component: ArtfestComponent;
  let fixture: ComponentFixture<ArtfestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArtfestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtfestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
