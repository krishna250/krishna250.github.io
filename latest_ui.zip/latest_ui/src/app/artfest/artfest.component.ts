import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artfest',
  templateUrl: './artfest.component.html',
  styleUrls: ['./artfest.component.css']
})
export class ArtfestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
