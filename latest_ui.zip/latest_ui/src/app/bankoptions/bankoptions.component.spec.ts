import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import {RouterModule,Routes} from '@angular/router';
import { FormsModule } from '@angular/forms';

//import { appRoutes} from '../app.module';
import { BankoptionsComponent } from './bankoptions.component';

describe('BankoptionsComponent', () => {
  let component: BankoptionsComponent;
  let fixture: ComponentFixture<BankoptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule,FormsModule],
    declarations: [ BankoptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankoptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  // it('should show state bank ',()=>{
  //   expect(
  // })
  
});
