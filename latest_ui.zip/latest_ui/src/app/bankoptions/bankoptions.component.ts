import { Component, OnInit } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-bankoptions',
  templateUrl: './bankoptions.component.html',
  styleUrls: ['./bankoptions.component.css']
})
export class BankoptionsComponent implements OnInit {
  Kotak:any;
  citi:any;
  icici:any;
  idbi:any;
  hdfc:any;
  axis:any;
  standard:any;
  punjab:any;
  state:any;
  bank : any ;
  constructor() { }
  selectedstate(){
  this.bank="state";
  }
  
selectedkotak()
{
  this.bank = "kotak";
}
selectedciti(){
   this.bank = "citi";
}
selectedhdfc(){
   this.bank = "hdfc";
 
}
selectedicici(){
 this.bank = "icici";
}
selectedpunjab(){
   this.bank = "punjab";
}

selectedstandard(){
  this.bank = "standard";
}
selectedidbi(){
  this.bank = "idbi";
}
selectedaxis(){
  this.bank = "axis";
}
  ngOnInit() {
  }

}
