import { Component, OnInit } from '@angular/core';
import  { Router } from '@angular/router';
import{DetailsComponent} from '../details/details.component';
import{ LocalUserService, LocalUserObject } from '../LocalUserService.service';
@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css'],
  

  
})
export class BookComponent implements OnInit {
    
LocalUserObject: LocalUserObject;

  constructor(private router: Router,private LocalService: LocalUserService) { 
    
  }
  
  

  ngOnInit() {
 
    this.LocalUserObject=this.LocalService.getLocalUserObject();
    this.LocalUserObject.TotalCost=this.totalcost(this.seatcost(),this.ihf(this.bookingfees(),this.gst_calc (this.bookingfees())));
    this.LocalService.setLocalUserObject(this.LocalUserObject);
  }
  // seats : number = 4 ;
  // cost_of_each_ticket = 150;
   gst :  number = 18 ;
  // movie_name: string="Tiger Zinda hai";
seatcost():number
{
return (this.LocalUserObject.TotalBookedSeats * this.LocalUserObject.TicketCost) ;
}
bookingfees():number
{
return this.LocalUserObject.TotalBookedSeats *25;
}
gst_calc (bookfees : number) : number
{
  return ((bookfees*this.gst)/100 );
}
ihf (bookfees : number,gstfees :number) : number
{
  return (bookfees+gstfees );
}
totalcost(seatcal:number,ihfcalc:number):number
{
  return (seatcal+ihfcalc);
}

redirect() : void {
console.log ("ishan");
this.router.navigate(['/pay']);
} 
}
