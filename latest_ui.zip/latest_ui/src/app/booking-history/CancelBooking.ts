export class CancelBooking{
    ReservationId:number;
    SeatBooked:string;
}