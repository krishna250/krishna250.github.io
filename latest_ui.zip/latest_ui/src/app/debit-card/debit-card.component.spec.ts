import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebitCardComponent } from './debit-card.component';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';


describe('DebitCardComponent', () => {
  let component : DebitCardComponent;
  let fixture :  ComponentFixture<DebitCardComponent>;
  
  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [DebitCardComponent],
      imports: [ReactiveFormsModule, FormsModule]
    }).compileComponents();
  })
  
  beforeEach(() => {
    fixture = TestBed.createComponent(DebitCardComponent);
    component = fixture.componentInstance;
  })
  

  it('is debit-card component is defined', () =>{
    expect(component).toBeDefined(); 
  });
  it('is form invalid when empty', () => {
    let DebitCardPayment = component.form.controls["card_number"];
  });



});
