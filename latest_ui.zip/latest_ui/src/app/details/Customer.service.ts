import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable()
export class CustomerService {

  constructor(private http: HttpClient) { }



private Url = 'https://ticketshereapidotnetnov2017.azurewebsites.net/api/play';

// private Url = 'http://localhost:52654/api/Play/';

getPlayInfo():Observable <any> {
const url = `${this.Url}`;
return this.http.get(url);
//.catch(this.handleError);
}
getPlayInfos(id:number ):Observable <any> {
const url = `${this.Url}/${id}`;
return this.http.get(url)
//.catch(this.handleError);
}
}

