import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import{DebugElement} from '@angular/core';
import { DetailsComponent } from './details.component';
import {By} from '@angular/platform-browser';
describe('DetailsComponent', () => {
  let component: DetailsComponent;
  let fixture: ComponentFixture<DetailsComponent>;
  let debugElement:DebugElement;
  let htmlElement:HTMLElement;
  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsComponent);
    component = fixture.componentInstance;
 //  debugElement=fixture.debugElement.query(By.css('p'));
  });
// debugElement=fixture.debugElement.query(By.css('h1'));
// htmlElement=debugElement.nativeElement;
// });


  it('should create', () => {
   expect(component).toBeTruthy();   });
 });
