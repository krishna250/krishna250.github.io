


import{ LocalUserService, LocalUserObject } from '../LocalUserService.service';
 
import { Component, OnInit } from '@angular/core';
import {CustomerService} from './Customer.service';
import{HttpClient}from '@angular/common/http';
import{info} from './Show.component';
import { Router } from '@angular/router';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map'; 
import { PlaysComponent } from '../plays/plays.component';

//import {LocalUserService,LocalUserObject } from '../localuserservice.service';



declare const $;


//import $ = require("jquery");
 
    function show() { 
        if(document.getElementById('i').style.display=='none') { 
            document.getElementById('h').style.display='block'; 
        } 
        return false;
    } 
    function hide() { 
        if(document.getElementById('i').style.display=='block') { 
            document.getElementById('h').style.display='none'; 
        } 
        return false;
    }   



@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css'],
  providers:[CustomerService,LocalUserService]
})
export class DetailsComponent implements OnInit {

     a : number ;
     b:number;
     play : info [] =[];
  selected: string[] = [];
  public obj:LocalUserObject;
  
Localobj:LocalUserObject;
constructor(private ser:CustomerService,private router:Router,private LocalService: LocalUserService) {
    
 

 }   
   showSelected (aa:number,bb:number):void {
    this.a = 0;
    this.selected = [];
    this.a =  aa;
    this.b= bb;
   // alert( "no of ticket selected is "+" "+ this.a.valueOf()+" "+"total amt is "+ " "+this.a.valueOf()*bb);
   this.obj=this.LocalService.getLocalUserObject();
    this.obj.TotalBookedSeats=this.a;
    this.obj.TicketCost=this.b;
    this.obj.type ="Play Name";
    this.obj.Name=this.play[0].PlayName;
    
   // alert(this.Localobj.Name);
    this.LocalService.setLocalUserObject(this.obj);
    this.router.navigate(['/book']);
             
  }
  

 ngOnInit() {
  
  // console.log('krishna');
  this.Localobj=this.LocalService.getLocalUserObject();
this.ser.getPlayInfos(this.Localobj.PlayId).subscribe(data =>{

console.log(data);
this.play = data}); 


 
 
  
   //this.obj.SeatNumber=this.a;
  // this.LocalService.setLocalUserObject(this.Localobj);
   
 }
direct() : void {
this.router.navigate(['/book']);
} 

 

}


