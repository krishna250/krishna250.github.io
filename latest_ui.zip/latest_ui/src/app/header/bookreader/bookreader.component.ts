import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookreader',
  templateUrl: './bookreader.component.html',
  styleUrls: ['./bookreader.component.css']
})
export class BookreaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
