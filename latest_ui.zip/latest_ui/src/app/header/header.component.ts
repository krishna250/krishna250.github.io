import { Component, OnInit } from '@angular/core';
import {MatMenuModule} from '@angular/material/menu'; 
//{MatMenuModule} from '@angular/material/menu'; 
import{MatButtonModule,MatInputModule} from '@angular/material'; 
import {Router,RouterModule} from '@angular/router';
//import {DataService} from '../data.service';
//import {  LocalUserService,  LocalUserObject  }  from  '../LocalUserService.service';
import { LoginComponent } from '../login/login.component';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
 
})
export class HeaderComponent implements OnInit {
CustomerId:number=0;
  
  constructor(private router:Router) {

    
   }

  ngOnInit() {
  }
isactive(){
 
  //  console.log(LoginComponent.abc);
  if(0==LoginComponent.abc){
  console.log(this.CustomerId);
  return true;
  }
  else
  return false;

}
isdeactive(){
  if(0<LoginComponent.abc)
  return true;
  else
  return false;
}
update(){
  this.router.navigate(["/updateprofile"]);
}
updatehome(){
 // this.CustomerId=this.ser1.CustomerId;
LoginComponent.abc = 0;
this.router.navigate(["/header"]);
}
updatehistory(){
  this.router.navigate(["/bookinghistory"]);
}
}
