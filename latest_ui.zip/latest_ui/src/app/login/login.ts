export interface Login{
    MobileNumber:number;
    PassWord:string;
} 
