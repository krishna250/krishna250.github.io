export class InfoShow {
public movieId:number;
public PlayId:number;
}
