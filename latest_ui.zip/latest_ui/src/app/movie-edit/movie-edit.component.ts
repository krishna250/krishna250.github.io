import { Component, OnInit } from '@angular/core';
import{MovieService} from './movie.service';
//import{movie} from './movie.interface';
import{InfoShow} from './info-show';
import  { Router } from '@angular/router';

@Component({
  selector: 'app-movie-edit',
  templateUrl: './movie-edit.component.html',
  styleUrls: ['./movie-edit.component.css']
})
export class MovieEditComponent implements OnInit {
 movie : any [] =[];
 public Id:InfoShow;
 abc:any;
 
  constructor(private show:MovieService,private router:Router) {
    this.Id=new InfoShow();

   }

  ngOnInit() {
    this.show.getMovieInfo().subscribe(data=>{
    console.log(data);
this.movie=data });
  }

  
movieDelete(MovieId:number,PlayId:number)
{
  this.Id.movieId= MovieId;
  this.Id.PlayId=PlayId;
  console.log(this.Id.movieId);
  console.log(this.Id.PlayId);
  console.log("aaaaaa");
  this.show.deleteMovieInfo(this.Id).subscribe(data=>{
    console.log(data);
this.abc=data });

  
  alert("Deleted successfully");
  this.router.navigate(['/Admin']);
}
redirect(id:number) : void {
         console.log("qwer");
this.router.navigate(['/Admin/Movie/Update',id]);
} 
  
direct(){
this.router.navigate(['/Admin']);
} 
 

}
