 export interface movie{
    movieId:number;
     PlayId:number;
}
