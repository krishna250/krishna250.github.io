import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//import{movie} from './movie';


@Injectable()
export class MovieService {
  //   movieInfo:movie;
  constructor(private http: HttpClient) { }

  getMovieInfo(): Observable<any> {
    return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminMovie');

  }
  deleteMovieInfo(Id: any) {
    return this.http.post('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminDelete', Id);
  }
}