import { Component, OnInit } from '@angular/core';
import  { Router } from '@angular/router';

import { DomSanitizer } from '@angular/platform-browser';
import { MovieTheatreDetailsService } from './MovieTheatreDetails.service';
import{ LocalUserService, LocalUserObject } from '../LocalUserService.service';


@Component({
  selector: 'app-movie-theatre-details',
  templateUrl: './movie-theatre-details.component.html',
  styleUrls: ['./movie-theatre-details.component.css'],
  providers:[MovieTheatreDetailsService]
})
export class MovieTheatreDetailsComponent implements OnInit {

   date:string=Date();
  date2=this.date.substring(4, 10);
  url:any;
  index:any;
 
  
  getcast:any[]=[];
    public detailsToBePassed:LocalUserObject;
    

  constructor(private ser:MovieTheatreDetailsService,private sanitizer:DomSanitizer,private router: Router,private localUserServiceObj:LocalUserService) 
  {
   
  }
   ngOnInit()
  {
   // this.PostProfile();
    console.log('asdfghj');
  this.detailsToBePassed=this.localUserServiceObj.getLocalUserObject();
    
    this.ser.getMovieDetails(this.detailsToBePassed.MovieId)
    .subscribe(
      data =>{
        this.index=data;
       console.log(data);
      //alert(this.date)
//this.url= this.sanitizer.bypassSecurityTrustResourceUrl(" https://www.youtube.com/embed/P1e216iQI3o");
      })
     
}
setdetails(target):void {
  
  this.detailsToBePassed=this.localUserServiceObj.getLocalUserObject();

       
    this.detailsToBePassed.Name=this.index.Name;
   var str=target.id;
   var res=str.split(" ");
   //alert(res[0]+" "+res[1]);
   this.detailsToBePassed.AudiId=res[1]; 
   this.detailsToBePassed.ScreeningId=res[0];
   this.detailsToBePassed.MovieDetailsId=res[2];
   this.detailsToBePassed.ScreeningTime=res[3]+" "+res[4];
 
  //  alert(this.detailsToBePassed.AudiId);
  //  alert(this.detailsToBePassed.ScreeningId);
  //  alert(this.detailsToBePassed.MovieDetailsId);
   
    // alert(this.index.theatre.auditorium.AudiId);
  this.localUserServiceObj.setLocalUserObject(this.detailsToBePassed); 
}
redirect() : void {
         
this.router.navigate(['/seat']);
} 

}
