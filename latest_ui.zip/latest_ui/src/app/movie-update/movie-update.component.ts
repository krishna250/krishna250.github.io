import { Component, OnInit } from '@angular/core';
import { MovieUpdateService } from './movie-update.service';
import { MovieInfo } from './movie-update';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute,Router } from "@angular/router";

@Component({
  selector: 'app-movie-update',
  templateUrl: './movie-update.component.html',
  styleUrls: ['./movie-update.component.css']
})
export class MovieUpdateComponent implements OnInit {
  Movie: any;
  EditInfo: MovieInfo;
  Mid: Number;
  // MovieForm=new FormGroup({

  // });
  // Name:any;
  qwe: any[] = [];
  abc: any;
  constructor(private ser: MovieUpdateService, private fb: FormBuilder, private activeRoute: ActivatedRoute,private router:Router) {
    this.EditInfo = new MovieInfo();
  }
  MovieForm: FormGroup;
  ngOnInit() {

    this.activeRoute.params
      .subscribe((data1) => {
        this.Mid = data1.id;
        this.ser.getMovieInfo(data1.id)
          .subscribe(
          data => {
            this.Movie = data;
            console.log(this.Movie),
              this.MovieForm = new FormGroup({
                Mid: new FormControl(this.Mid),
                name: new FormControl(this.Movie.Name),
                Image: new FormControl(this.Movie.Image),
                Duration: new FormControl(this.Movie.Duration),
                Genre: new FormControl(this.Movie.Genre),
                Language: new FormControl(this.Movie.Language),
                Rating: new FormControl(this.Movie.Rating),
                Video: new FormControl(this.Movie.Video),
                ReleaseDate: new FormControl(this.Movie.ReleaseDate),

                // name_on_the_card: new FormControl(),
                // exp_month: new FormControl(),
                // exp_year: new FormControl(),
                // cvv: new FormControl()
              })
          }
          )
      });

  }


  ubmit(qwe) {

    console.log(qwe);
    this.EditInfo.MovieId = qwe.Mid;
    this.EditInfo.CityId = 0;
    this.EditInfo.Description = this.Movie.Description;
    this.EditInfo.Genre = qwe.Genre;
    this.EditInfo.Language = qwe.Language;
    this.EditInfo.PlayId = 0;
    this.EditInfo.TimeDuration = qwe.Duration;
    this.EditInfo.Poster = qwe.Image;
    this.EditInfo.VideoUrl = qwe.Video;
    this.EditInfo.Price = 0;
   // this.EditInfo.ModifiedDate = Date();
    this.EditInfo.Isdeleted = false;
    this.EditInfo.Rating = qwe.Rating;
    // this.EditInfo.StartDate=Date();
    //EndDate:Date;
    this.EditInfo.ReleaseDate = qwe.ReleaseDate;
    this.EditInfo.Name = qwe.name;
    this.EditInfo.UpdatedBy = 0;
    console.log(this.EditInfo);
   
    this.ser.EditMovieInfo(this.EditInfo)
      .subscribe(data => {
        console.log(data);
        this.abc = data;
        alert("Updated Successfully");
        this.router.navigate(['/Admin']);
      })
  }
  direct(){
    this.router.navigate(['/Admin']);
  }

}
