import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
//import{movie} from './movie';


@Injectable()
export class MovieUpdateService {
 //   movieInfo:movie;
  constructor(private http: HttpClient) { }
//   private Pid:Number;
// getMovieId(id:Number)
// {
//   this.Pid=id;
// }
   private Url ='https://ticketshereapidotnetnov2017.azurewebsites.net/api/Theatre';
 
getMovieInfo(id:number ):Observable <any> {
    
 const url:string = `${this.Url}/${id}`;
console.log(url);
console.log(this.Url);
//let options = new RequestOptions({ headers: this.headers });
return this.http.get(url);//, { headers: this.headers });
//.catch(this.handleError);
}
// getMovieInfo():Observable <any> {
// return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/Theatre/3');

//   }
  
  EditMovieInfo(Id:any)
  {
      return this.http.post('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminEdit',Id);
  }
}