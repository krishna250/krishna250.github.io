import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response} from '@angular/http';
import { Observable } from 'rxjs';
import {movie} from './movie';
import 'rxjs/add/operator/map';

@Injectable()
export class MovieService {

  Url:string;
  constructor(private http: HttpClient) 
  { 
    this.Url = "https://ticketshereapidotnetnov2017.azurewebsites.net/api/MovieSearch/";
    //this.Url = "http://localhost:52654/api/MovieSearch";
    
  }
  
  // search(term: string): Observable<any> 
  // {
  //   var ClientList = this.httpClient.get(this.url + term).map((r: Response) => { return (<info[]> r.json() ) as any[] });
  //  return ClientList;
  // } 
  getPlayInfos(name:string ):Observable<any> {
const url = `${this.Url}/${name}`;
return this.http.get(url);
//.catch(this.handleError);
} 


getAllMovies( ):Observable<any> {
const url = `${this.Url}`;
return this.http.get(url);
//.catch(this.handleError);
} 
}



