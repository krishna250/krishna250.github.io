import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MovieService } from '../movies/movie.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { movie } from './movie';
import { LocalUserService, LocalUserObject } from '../LocalUserService.service';
@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css'],
  providers: [MovieService]
})
export class MoviesComponent implements OnInit {
  filter = {
    language: ["Hindi", "English", "Telugu"],
    genre: ["Action", "Comedy", "Horror"],
    languageStart: 0,
    genreStart: 0
  }

  moviesList: any;
  temp: string;
  searchObj: LocalUserObject = {
    PlayId: 0,
    MovieId: 0,
    Name: "",
    SeatNumber: "A1",
    TotalCost: 0,
    BankName: "HDFC",
    PaymentType: "Card",
    ReservationTypeId: 123,
    TicketCost: 100,
    MovieDetailsId: 0,
    TotalBookedSeats: 0,
    CustomerId: 0,
    ScreeningId: 0,
    type: "Movie",
    AudiId: 0,
    ScreeningTime: "time"
  };

  constructor(private router: Router, private ser: MovieService, private local: LocalUserService) {


  }
  // ngOnInit() {
  //   }
  redirect(): void {
    //console.log ("ishan");

    this.router.navigate(['/movie-theatre-details']);
  }

  // movieSearch(mov:string)
  // {
  //   this.movieservice.search(mov).subscribe();
  // }

  applyFilterByLanguage(language) {
    for (let fLanguage of this.filter.language) {
      if (language == fLanguage) {
        return true;
      }
    }
    return false;
  }

  applyFilterByGenre(genre) {
    for (let fGenre of this.filter.genre) {
      if (genre == fGenre) {
        return true;
      }
    }
    return false;
  }


  ngOnInit() {

    this.ser.getAllMovies().subscribe
      (
      MovieData => {
        // console.log("abc");
        // console.log(MovieData);
        this.moviesList = MovieData;
        console.log(this.moviesList.length);
      }
      )

  }
  s:  string;
  res: string;
  res1: string;
  getDetails(event) {
    // alert("abc");
    this.res = event.target.value;
    this.res1 = this.res.trim();
    //alert(this.res1);
    // alert(event.target.value);
    this.ser.getPlayInfos(this.res1).subscribe(
      MovieData => {
        //   console.log("abc");
        // console.log(MovieData);
        this.moviesList = MovieData;

        //console.log(this.moviesList.length);
        if (this.moviesList.length == 0) {
          // this.moviesList = null;


         // alert("No Results Found");
        }
      })
  }
  setMovieId(target): void {


    // this.searchObj=this.local.getLocalUserObject();

    // alert(target.id);
    this.searchObj.MovieId = target.id;

    this.local.setLocalUserObject(this.searchObj);


  }
  checkExistOrNot(array = [], value: string): number {
    for (let item in array) {
      if (value == array[item]) {
        return parseInt(item);
      }
    }
    return -1;
  }

  updateGenre(event) {
    if (this.filter.genreStart == 0) {
      this.filter.genreStart = 1;
      this.filter.genre = [];
    }
    if (event.target.checked) {
      if (this.checkExistOrNot(this.filter.genre, event.target.value) == -1)
        this.filter.genre.push(event.target.value);
    } else {
      if (this.checkExistOrNot(this.filter.genre, event.target.value) != -1)
        this.filter.genre.splice(this.checkExistOrNot(this.filter.genre, event.target.value), 1);
    }
    if (this.filter.genre.length == 0) {
      this.filter.genre.push("Action");
      this.filter.genre.push("Horror");
      this.filter.genre.push("Comedy");
      this.filter.genreStart = 0;
    }
    console.log(this.filter.genre);
  }

  updateLanguage(event) {
    if (this.filter.languageStart == 0) {
      this.filter.languageStart = 1;
      this.filter.language = [];
    }
    if (event.target.checked) {
      if (this.checkExistOrNot(this.filter.language, event.target.value) == -1)
        this.filter.language.push(event.target.value);
    } else {
      if (this.checkExistOrNot(this.filter.language, event.target.value) != -1)
        this.filter.language.splice(this.checkExistOrNot(this.filter.language, event.target.value), 1);
    }
    if (this.filter.language.length == 0) {
      this.filter.language.push("English");
      this.filter.language.push("Hindi");
      //this.filter.language.push("Telugu");
      this.filter.languageStart = 0;
    }
    console.log(this.filter.language);
  }
}

