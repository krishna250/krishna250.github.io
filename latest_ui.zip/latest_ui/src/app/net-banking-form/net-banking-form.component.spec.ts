import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgModule } from '@angular/core';
import {ActivatedRoute,Params} from '@angular/router';
import {Observable,Subscription} from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NetBankingFormComponent } from './net-banking-form.component';
import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';



fdescribe('NetBankingFormComponent', () => {
  let component: NetBankingFormComponent;
  let fixture: ComponentFixture<NetBankingFormComponent>;
  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[ActivatedRoute,Observable,Subscription,RouterTestingModule,FormsModule,NgModule,ReactiveFormsModule],

      declarations: [ NetBankingFormComponent]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NetBankingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();

  });

});
