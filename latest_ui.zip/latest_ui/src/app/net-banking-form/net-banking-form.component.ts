import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {DataService} from '../data.service';

import {ActivatedRoute,Params} from '@angular/router';
import {Observable,Subscription} from 'rxjs';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-net-banking-form',
  templateUrl: './net-banking-form.component.html',
  styleUrls: ['./net-banking-form.component.css']
})
export class NetBankingFormComponent implements OnInit {
  abc : string   ;
 val:string;
 val2:string;

// user={
//   id:'',
//   password:''
// }
private route$ : Subscription;
bank:any;
  constructor(private route : ActivatedRoute,private ser1:DataService) {  
    this.route$ = this.route.params.subscribe(

   (params : Params) => {
     
      let bank = params['bank'];
    
      this.val=bank;
       localStorage.setItem('val1',JSON.stringify(this.val));
 var val1=JSON.parse(localStorage.getItem('val1'));
       console.log(val1);
this.val2=val1;
this.abc = '../../assets/'+bank+'.png';
console.log(val1);

 
   });
   
  }
    
 form: FormGroup;

  ngOnInit() {
 this.form=new FormGroup({
   UserId:new FormControl('', [Validators.required, Validators.pattern('[0-9a-zA-Z]*'), Validators.maxLength(6), Validators.minLength(6)]),
   Password:new FormControl('', [Validators.required, Validators.maxLength(15), Validators.minLength(8)]),
 })

  }
  ngOnDestroy(){
    this.ser1.bank=this.val2;
    console.log(this.val2);
  }
  }
