export class Custom{
     PlayId: number;
  PlayName: string;
  MovieId: number;
  MovieName: string;
  SeatNumber: string;
  TotalCost: number;
  BankName: string;
  PaymentType: string;
  ReservationTypeId: number;
  MovieDetailsId: number
  TotalBookedSeat: number;
  Date: string;
  CustomerId: number;
  ReservationId: number;
  TransactionId: number;
  Comments: string;
}