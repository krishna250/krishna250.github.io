import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient,HttpResponse} from '@angular/common/http';
import {Custom} from './pay';
@Injectable()
export class paymentserService {
    constructor(private http:HttpClient){
    }
   
    postmethod(obj:Custom){
        console.log(obj);
        console.log(obj);
       return this.http.post('https://ticketshereapidotnetnov2017.azurewebsites.net/api/Payment',obj);
       
    }

}