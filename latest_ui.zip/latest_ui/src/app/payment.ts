export interface payment{
    card_number: string,
    name_on_the_card: string,
    exp_month: string,
    exp_year: string,
    cvv: string
}