import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//import{movie} from './movie';


@Injectable()
export class PlayService {
  //   movieInfo:movie;
  constructor(private http: HttpClient) { }

  getPlayInfo(): Observable<any> {
    return this.http.get('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminPlay');

  }
  deletePlayInfo(Id: any) {
    return this.http.post('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminDelete', Id);
  }
}