import { Component, OnInit } from '@angular/core';
import { PlayUpdateService } from './play-update.service';
import { PlayInfo } from './play-update';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-play-update',
  templateUrl: './play-update.component.html',
  styleUrls: ['./play-update.component.css'],
  providers: [PlayUpdateService]
})

export class PlayUpdateComponent implements OnInit {
  qwe: any[] = [];
  Play: any;
  EditInfo: PlayInfo;
  Mid: Number;
  abc: any;

  constructor(private ser: PlayUpdateService, private fb: FormBuilder, private activeRoute: ActivatedRoute, private router: Router) {
    this.EditInfo = new PlayInfo();

  }
  MovieForm: FormGroup;
  ngOnInit() {
    this.activeRoute.params
      .subscribe(data1 => {
        this.Mid = data1.id;
        this.ser.getPlayInfo(data1.id)
          .subscribe(
          data => {
            this.Play = data;
            console.log(data);
            console.log(this.Play);

            console.log(this.Play[0].PlayName);
            this.MovieForm = new FormGroup({
              Mid: new FormControl(this.Mid),
              Name: new FormControl(this.Play[0].PlayName),
              Image: new FormControl(this.Play[0].Poster),
              Duration: new FormControl(this.Play[0].TimeDuration),
              Genre: new FormControl(this.Play[0].Genre),
              Language: new FormControl(this.Play[0].Language),
              // Rating: new FormControl(this.Play.Rating),
              // Video: new FormControl(this.Play.Video),
              ReleaseDate: new FormControl(this.Play[0].StartDate)
            })
          }
          )
      });
  }

  submit(qwe) {

    console.log(qwe.value);
    this.EditInfo.PlayId = qwe.Mid;    
    this.EditInfo.Description = this.Play[0].Description;    
    this.EditInfo.Language = qwe.Language;
    this.EditInfo.TimeDuration = qwe.Duration;
    this.EditInfo.Poster = qwe.Image;
    this.EditInfo.VideoUrl = null;
    this.EditInfo.Price = 0;
   // this.EditInfo.ModifiedDate = qwe.ModifiedDate;
    this.EditInfo.CityId = 1;
    this.EditInfo.UpdatedBy = 0;
    this.EditInfo.Rating = 0;
    this.EditInfo.StartDate = qwe.ReleaseDate;
    //this.EditInfo.EndDate = qwe.EndDate;
    this.EditInfo.Genre = qwe.Genre;
    this.EditInfo.Isdeleted = false;
    this.EditInfo.Name = qwe.Name;
    this.EditInfo.PlayName = qwe.Name;
    this.EditInfo.MovieId = 0;    
    //this.EditInfo.ReleaseDate = qwe.ReleaseDate;
        

    console.log(this.EditInfo);
    
    this.ser.EditMovieInfo(this.EditInfo)
      .subscribe(data => {
        console.log(data);
        this.abc = data;
        console.log(this.EditInfo);

        alert("Updated Successfully");
        this.router.navigate(['/Admin']);

      })
  }
  direct(){
this.router.navigate(['/Admin']);
} 
}
