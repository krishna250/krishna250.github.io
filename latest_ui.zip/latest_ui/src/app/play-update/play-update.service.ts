import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';


@Injectable()
export class PlayUpdateService {

  constructor(private http: HttpClient) { }

   private Url ='https://ticketshereapidotnetnov2017.azurewebsites.net/api/Play';
 
getPlayInfo(id:number ):Observable <any> {
    
 const url:string = `${this.Url}/${id}`;

return this.http.get(url);

}

  
  EditMovieInfo(Id:any)
  {
      return this.http.post('https://ticketshereapidotnetnov2017.azurewebsites.net/api/AdminEdit',Id);
  }
}