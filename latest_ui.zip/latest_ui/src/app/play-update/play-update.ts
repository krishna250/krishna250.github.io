export class PlayInfo {
  PlayId:Number;
  Description:string;
  Language:string;
  TimeDuration:string;
  Poster:string;
  VideoUrl:string;
  Price:Number;
  ModifiedDate=new Date();
  CityId:Number;
  Rating:Number;
  StartDate=new Date();
  EndDate=new Date();
  Genre:string;
  Isdeleted:boolean;
  MovieId:Number;
  ReleaseDate=new Date();
  Name:string;
  UpdatedBy:number;
  PlayName:string;
}