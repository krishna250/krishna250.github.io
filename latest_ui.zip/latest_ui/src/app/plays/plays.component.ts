import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
import {  LocalUserService,  LocalUserObject  }  from  '../LocalUserService.service';
import { PlayService } from "./play.service";
@Component({
  selector: 'app-plays',
  templateUrl: './plays.component.html',
  styleUrls: ['./plays.component.css']
})
export class PlaysComponent implements OnInit {

  filter = {
    language: ["Hindi", "English"],
    
    languageStart: 0,
    
  }
  
a:number;
b:number;
selected: string[] = [];
playlist:any;

  constructor(private router: Router,private LocalService: LocalUserService,private PlayService:PlayService) { }
  
public obj:LocalUserObject={
  PlayId:0,
     MovieId:0,
     Name:"",
     SeatNumber:"A1",
     TotalCost:0,
     BankName:"HDFC",
     PaymentType:"Card",
     ReservationTypeId:123,
     TicketCost:100,
     MovieDetailsId:0,
     TotalBookedSeats:0,
     CustomerId:0,
     ScreeningId:0,
     type:"Movie",
     AudiId:0,
     ScreeningTime:"time"
};
ngOnInit() {

this.PlayService.getAllPlays().subscribe
(
  PlayData=>{
    this.playlist=PlayData;
  }

)
}
s: string;
result:string;
result1:string;
getDetails(event) {

this.result=event.target.value;
this.result1=this.result.trim();

this.PlayService.getPlayInfos(this.result1).subscribe(
      PlayData => {
     //   
        this.playlist = PlayData;
        
        
        if(this.playlist.length==0)
        {
       
        
          
       // alert("No Results Found");
        }
      })
  }
redirect() : void {
console.log ("ishan");
this.router.navigate(['/details']);
}


applyFilterByLanguage(language) {
    for (let fLanguage of this.filter.language) {
      if (language == fLanguage) {
        return true;
      }
    }
    return false;
  }

checkExistOrNot(array = [], value: string): number {
    for (let item in array) {
      if (value == array[item]) {
        return parseInt(item);
      }
    }
    return -1;
  }

  updateLanguage(event) {
    if (this.filter.languageStart == 0) {
      this.filter.languageStart = 1;
      this.filter.language = [];
    }
    if (event.target.checked) {
      if (this.checkExistOrNot(this.filter.language, event.target.value) == -1)
        this.filter.language.push(event.target.value);
    } else {
      if (this.checkExistOrNot(this.filter.language, event.target.value) != -1)
        this.filter.language.splice(this.checkExistOrNot(this.filter.language, event.target.value), 1);
    }
    if (this.filter.language.length == 0) {
      this.filter.language.push("English");
      this.filter.language.push("Hindi");
      //this.filter.language.push("Telugu");
      this.filter.languageStart = 0;
    }
    console.log(this.filter.language);
  }

setPlayId(target):void
  {


     // this.searchObj=this.local.getLocalUserObject();

   // alert(target.id);
       this.obj.PlayId=target.id;
  
    this.LocalService.setLocalUserObject(this.obj); 
this.router.navigate(['/details']);
    
  }



  }


