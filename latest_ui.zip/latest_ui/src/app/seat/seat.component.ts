import{ LocalUserService, LocalUserObject } from '../LocalUserService.service';
import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {SeatService} from './seat.service';
import {PlayInfo} from './seat';
//Component decorator

@Component({
    selector: 'seat-list',
    templateUrl: './seat.component.html',
    styleUrls: ['./seat.component.css'],
     providers:[SeatService] 

})
export class SeatComponent {
 
public MovieObj:LocalUserObject;
static  total_number_of_seats : number ;
static  total_cost : number;


 play:PlayInfo[]=[];
reserved:string[]=[];
ish:any []=[]; 
    constructor(private router:Router,private LocalService: LocalUserService,private ser:SeatService) {
       this.MovieObj= this.LocalService.getLocalUserObject();
     } 
      
ngOnInit() {
this.ser.getPlayInfos(this.MovieObj.ScreeningId).subscribe(data =>{
    console.log("jh");
    console.log(this.MovieObj.ScreeningId);

console.log(data);
this.reserved = data});
this.ser.getPlayInfos1(this.MovieObj.AudiId).subscribe(data =>{
//console.log('krish');
console.log(data);
this.play = data}); 

SeatComponent.movieTitle = this.MovieObj.Name;

    
}



    static a : number ;
    static b : number ;
    //variable declarations
  static  movieTitle:string = "awarapan";

    screen: string = " CINEMAS";
    time: string = "FRI, 6:45PM"

    rows: string[] = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H','I'];
    cols: number[]  = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  // reserved: string[] = ['A1', 'A2', 'A3', 'A4', 'A5'];
    selected: string[] = [];

    ticketPrice: number = 120;
    convFee: number = 30;
    totalPrice: number = 0;
    currency: string = "Rs";

    //return status of each seat
    getStatus = function(seatPos: string) {
        if(this.reserved.indexOf(seatPos) !== -1) {
            return 'reserved';
        } else if(this.selected.indexOf(seatPos) !== -1) {
            return 'selected';
        }
    }
    //clear handler
    clearSelected = function() {
        SeatComponent.a = 0;
        this.selected = [];
    }
    //click handler
    seatClicked = function(seatPos: string) {
      if ( SeatComponent.a > 0)
      {
        
        var index = this.selected.indexOf(seatPos);
      
        if(index !== -1) {
            // seat already selected, remove
            this.selected.splice(index, 1)
        } else {
            //push to selected array only if it is not reserved
            if(this.reserved.indexOf(seatPos) === -1)
            {
                this.selected.push(seatPos);
            SeatComponent.a =   SeatComponent.b -this.selected.length;
            }
        }
      
    
      }
    }
    //Buy button handler
 
    apple (aa:number) :void
    {
         SeatComponent.a = 0;
        this.selected = [];
       SeatComponent .a =  aa;
       SeatComponent.b = aa;
    
    }
   


   showSelected () : void{
        if(this.selected.length == SeatComponent.b)
        {
             
        //   alert("Selected Seats: " + this.selected + "\nTotal: "+(this.ticketPrice * this.selected.length ));
    
           SeatComponent.total_number_of_seats = this.selected.length;
          SeatComponent.total_cost = this.ticketPrice;
          this.MovieObj.type = "Movie Name";
           
           this.MovieObj.TotalBookedSeats=SeatComponent.total_number_of_seats;
           this.MovieObj.TicketCost=SeatComponent.total_cost;
         this.MovieObj.SeatNumber=this.selected.toString();
this.LocalService.setLocalUserObject(this.MovieObj);
//this.selected.toString(); // no of seats
            this.router.navigate(['/book']);
        }
        
        else{
             this.selected = [];
          //  alert("Lesser no of seat selected")
        }
    }

direct() : void {
this.router.navigate(['/book']);
}
}