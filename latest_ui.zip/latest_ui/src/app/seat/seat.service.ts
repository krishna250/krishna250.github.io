import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';
import {Observable} from 'rxjs';

// import { Class in which variables are stored} from './playinfo';
@Injectable()
export class SeatService  {
  constructor(private http: HttpClient) {

  }
  private  Url = 'https://ticketshereapidotnetnov2017.azurewebsites.net/api/seat';
//private  Url =  'http://localhost:52654/api/seat';
private  Url1 =  'https://ticketshereapidotnetnov2017.azurewebsites.net/api/seatlayout/';
getPlayInfo():Observable <any> {
    const url = `${this.Url}`;
    return this.http.get(url)
      //.catch(this.handleError);
  }
getPlayInfos(id:number ):Observable <any> {
    const url = `${this.Url}/${id}`;
    return this.http.get(url)
      //.catch(this.handleError);
  }

getPlayInfos1(id:number ):Observable <any> {
    const url1 = `${this.Url1}/${id}`;
    return this.http.get(url1)
    
  
      //.catch(this.handleError);
  }

}
   



