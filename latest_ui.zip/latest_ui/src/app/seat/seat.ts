export interface PlayInfo
{
rowname : string;
noofseats : number;

} 