import { Component,Inject, OnInit } from '@angular/core';
import {FormControl, Validators,FormGroup,FormBuilder} from '@angular/forms';
import {signup1} from './signup1';
import{SignupService} from './signupservice';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
declare const $;
import{ LocalUserService, LocalUserObject } from '../LocalUserService.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers:[SignupService]
})
export class SignupComponent implements OnInit {
     private errorMessage:any = '';

  hide=true;
  
  
    play:signup1[]=[];
     register:signup1

        form: FormGroup;
     
 values={   
      CustomerName:"",
   PhoneNumber:"",
   
  
  EmailId:"",
  Password:0
 };

  selected: string[] = [];
  public obj:LocalUserObject;
  newcontact:signup1;
Localobj:LocalUserObject;
   constructor(private fb:FormBuilder,private LocalService: LocalUserService,private ser:SignupService,private router:Router) {
     
   }

// rForm:FormGroup;
// post:any;
// Name:string='';
// Mobile_Number:number=null;
// Email:number=null;
// Password:string='';
// city:string='';
msg:any;


   
  getmobilenubl(event){
  this.values.PhoneNumber=event.target.value;
}
getename(event){
  this.values.CustomerName=event.target.value;  

}
getcity(event){
 // this.values.city=event.target.value;  

}
getemail(event){
  this.values.EmailId=event.target.value;
  //alert(this.email1);
}

 getpassword(event){
   this.values.Password=event.target.value;

 }
 
  ngOnInit(){
      
    
  }

 
   getinfo()
{
  if(this.mobile_number.valid && this.name_on_the_card.valid && this.email.valid && this.password1.valid)
  {
  
  this.ser.getPlayInfo(this.values).subscribe(
    data=>{console.log(data);
  //     this.values=data,
    

    if(data==1)
   {
    alert('Congratulation! you Successfully Registered');
    
    this.router.navigate(['/login']);
   }
   else if(data==2)
        alert('User already exists');

   
    });

  
  
  }


   else 
   {

 alert('enter valid inputs')

   

   }


}
         email = new FormControl('', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9]+.[a-z][a-z][a-z]+.com')]);
name_on_the_card= new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+')]);
mobile_number = new FormControl('', [Validators.required, Validators.pattern('[7-9][0-9]*'), Validators.maxLength(10), Validators.minLength(10)]);
password1=new FormControl('', [Validators.required,Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,15}$$')])
   
  getErrorMessage() { 
    //SignupComponent.abc ++;
    
    return this.email.hasError('required') ? 'please enter valid email' :
        this.email.hasError('email') ? 'please enter valid email' :'Enter valid email';
            

  }

   getpasswor() {
     //SignupComponent.abc ++;
    return this.password1.hasError('required') ? 'please enter valid password ' :
   this.password1.hasError('password1') ? 'password should contain one lower case letter, one upper case letter, one digit,one special character & 8-15 length':'password should contain one lower case letter, one upper case letter, one digit,one special character & 8-15 length'; 
  }
   getErrorMessage2() {
    // SignupComponent.abc ++;
    return this.mobile_number.hasError('required') ? 'please enter valid mobile number' :
        this.mobile_number.hasError('mobile_number') ? 'Not a valid email' : 'please enter valid mobile number';
  }
   getErrorMessage1() {
    
  
    
    return this.name_on_the_card.hasError('required') ? 'please enter valid name' :
        this.name_on_the_card.hasError('name_on_the_card') ? 'Not a valid Name' :
            'please enter valid name';
  }





}


