export class updateprofilevar
{
    // public id
    // public Name1:string;
    // public mobile:number;
    // public email1:string;
    // public password:string;

     public  CustomerId:number;
     
        public CustomerName:string;

        public PhoneNumber:number;
                public EmailId :string;
        public Password:string; 
}